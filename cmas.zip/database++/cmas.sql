-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: localhost    Database: cmas
-- ------------------------------------------------------
-- Server version	5.6.26-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `a`
--

DROP TABLE IF EXISTS `a`;
/*!50001 DROP VIEW IF EXISTS `a`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `a` AS SELECT 
 1 AS `id`,
 1 AS `value`,
 1 AS `createdAt`,
 1 AS `updatedAt`,
 1 AS `channel_definition_id`,
 1 AS `number_of_sample`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `acs_log`
--

DROP TABLE IF EXISTS `acs_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `acs_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acs_time` datetime NOT NULL,
  `acs_username` varchar(255) DEFAULT NULL,
  `acs_reader` varchar(255) DEFAULT NULL,
  `acs_event` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acs_log`
--

LOCK TABLES `acs_log` WRITE;
/*!40000 ALTER TABLE `acs_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `acs_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `actions`
--

DROP TABLE IF EXISTS `actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  `type` varchar(512) NOT NULL,
  `content` varchar(512) DEFAULT NULL,
  `options` text,
  `status` varchar(512) NOT NULL,
  `createdAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actions`
--

LOCK TABLES `actions` WRITE;
/*!40000 ALTER TABLE `actions` DISABLE KEYS */;
/*!40000 ALTER TABLE `actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activity`
--

DROP TABLE IF EXISTS `activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `activityCode` int(11) NOT NULL,
  `detail` text NOT NULL,
  `status` varchar(512) NOT NULL,
  `options` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity`
--

LOCK TABLES `activity` WRITE;
/*!40000 ALTER TABLE `activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alarm_log`
--

DROP TABLE IF EXISTS `alarm_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alarm_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alarmWatcherID` int(11) NOT NULL,
  `alarmAt` datetime NOT NULL,
  `resetAt` datetime NOT NULL,
  `acknowledgeAt` datetime NOT NULL,
  `acknowledgeBy` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alarm_log`
--

LOCK TABLES `alarm_log` WRITE;
/*!40000 ALTER TABLE `alarm_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `alarm_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alarm_watcher`
--

DROP TABLE IF EXISTS `alarm_watcher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alarm_watcher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channelID` int(11) NOT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `type` varchar(512) NOT NULL,
  `status` varchar(512) DEFAULT NULL,
  `alarmCondition` varchar(512) NOT NULL,
  `alarmThreshold` int(11) NOT NULL,
  `resetCondition` varchar(512) NOT NULL,
  `resetThreshold` int(11) NOT NULL,
  `notificationMethod` text,
  `alarmAt` datetime DEFAULT NULL,
  `resetAt` datetime DEFAULT NULL,
  `acknowledgeAt` datetime DEFAULT NULL,
  `lastEscalationAt` datetime DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `escalationProfileID` int(11) NOT NULL,
  `msg` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alarm_watcher`
--

LOCK TABLES `alarm_watcher` WRITE;
/*!40000 ALTER TABLE `alarm_watcher` DISABLE KEYS */;
/*!40000 ALTER TABLE `alarm_watcher` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_buffer`
--

DROP TABLE IF EXISTS `channel_buffer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel_buffer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` float DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `channel_definition_id` int(11) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`channel_definition_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_buffer`
--

LOCK TABLES `channel_buffer` WRITE;
/*!40000 ALTER TABLE `channel_buffer` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel_buffer` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `channel_buffer_BEFORE_UPDATE` BEFORE UPDATE ON `channel_buffer` FOR EACH ROW begin
	Declare TimeInterval int;
    Set TimeInterval = 3600;
	if (New.updatedAt - Old.createdAt > TimeInterval) then
		set New.createdAt = SUBDATE(New.updatedAt, interval 1 hour);
    end if;   
    
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `channel_buffer_AFTER_UPDATE` AFTER UPDATE ON `channel_buffer` FOR EACH ROW begin
	Declare TimeInterval int;
    Set TimeInterval = 3600;
    
	DELETE FROM `channel_buffer` WHERE `updatedAt` < current_timestamp(3) - TimeInterval;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `channel_data`
--

DROP TABLE IF EXISTS `channel_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channelName` varchar(255) NOT NULL,
  `value` double DEFAULT NULL,
  `channel_definition_id` int(11) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `controllable` tinyint(1) NOT NULL,
  `channelHistoryID` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`,`channel_definition_id`,`channelName`),
  UNIQUE KEY `id_UNIQUE` (`id`) USING HASH,
  UNIQUE KEY `channelName_UNIQUE` (`channelName`) USING HASH,
  KEY `updatedAt` (`channel_definition_id`,`value`,`updatedAt`) USING BTREE
) ENGINE=MEMORY DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_data`
--

LOCK TABLES `channel_data` WRITE;
/*!40000 ALTER TABLE `channel_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `channel_data_BEFORE_INSERT` BEFORE INSERT ON `channel_data` FOR EACH ROW begin	
    set New.createdAt = current_timestamp(3);
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `channel_data_BEFORE_UPDATE` BEFORE UPDATE ON `channel_data` FOR EACH ROW BEGIN
	if NEW.value != OLD.value then        
		set New.updatedAt = current_timestamp(3);
    else		
		set New.updatedAt = current_timestamp(3);
	end if;
    
    if (SELECT @alarmMode IS NULL) then
		set @alarmMode = (select `value`= 'true' from `config` where `name` = "alarmMode");
    end if;
  
	if (NEW.value = OLD.value) and (NEW.updatedAt > OLD.updatedAt) and (OLD.channelHistoryID != null) then 
		update 
			`channel_history` 
		set 
			`channel_history`.`updatedAt` = NEW.updatedAt 
        where 
			`channel_history`.`id` = OLD.channelHistoryID;
			        
        # Update buffer table
        
/*
        if (@alarmMode) then 
			update 
				`channel_issue_snapshot` 
			set 
				`channel_issue_snapshot`.`updatedAt` = NEW.updatedAt 
			where 
				`channel_issue_snapshot`.`channel_definition_id` = NEW.channel_definition_id 
				and 
				`channel_issue_snapshot`.`value` = NEW.value
				and
				`channel_issue_snapshot`.`updatedAt` = OLD.updatedAt;
        else
        
			update 
				`channel_buffer` 
			set 
				`channel_buffer`.`updatedAt` = NEW.updatedAt 
			where 
				`channel_buffer`.`channel_definition_id` = NEW.channel_definition_id 
				and 
				`channel_buffer`.`value` = NEW.value
				and
				`channel_buffer`.`updatedAt` = OLD.updatedAt;
        
        end if; */       
    elseif (NEW.value != OLD.value) then
		insert 
			`channel_history`(`value`, `createdAt`, `updatedAt`, `channel_definition_id`) 
        values (new.value, old.updatedAt, new.updatedAt, new.channel_definition_id);
        
        set new.channelHistoryID = (select last_insert_ID());
        /*if (@alarmMode) then 
			insert 
				`channel_issue_snapshot`(`value`, `createdAt`, `updatedAt`, `channel_definition_id`) 
			values (new.value, new.lastChangedAt, new.updatedAt, new.channel_definition_id);        
        else        
			insert 
				`channel_buffer`(`value`, `createdAt`, `updatedAt`, `channel_definition_id`) 
			values (new.value, new.lastChangedAt, new.updatedAt, new.channel_definition_id);
        end if;*/
    end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `cmas`.`channel_data_AFTER_UPDATE` AFTER UPDATE ON `channel_data` FOR EACH ROW
Begin
	
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `channel_definition`
--

DROP TABLE IF EXISTS `channel_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel_definition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `historyInterval` int(11) NOT NULL,
  `updatedAt` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `createdAt` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `unitID` int(11) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `displayName` varchar(255) DEFAULT NULL,
  `controllable` tinyint(1) NOT NULL,
  `unit` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1280 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_definition`
--

LOCK TABLES `channel_definition` WRITE;
/*!40000 ALTER TABLE `channel_definition` DISABLE KEYS */;
INSERT INTO `channel_definition` VALUES (1,'UPS1_EstimatedMinutesRemaining','UPS1: Estimated Minutes Remaining',1,'2015-08-18 07:40:29.426','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Estimated Minutes Remaining',0,'min'),(2,'UPS1_EstimatedChargeRemaining','UPS1: Estimated Charge Remaining',1,'2015-08-18 07:40:29.457','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Estimated Charge Remaining',0,'min'),(3,'UPS1_OutputSource','UPS1: Output Source',1,'2015-08-18 07:40:29.473','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Output Source',0,'---'),(4,'UPS1_InputFrequency01','UPS1: Input Frequency L1',1,'2015-08-18 07:40:29.504','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Input Frequency L1',0,'Hz'),(5,'UPS1_InputFrequency02','UPS1: Input Frequency L2',1,'2015-08-18 07:40:29.520','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Input Frequency L2',0,'Hz'),(6,'UPS1_InputFrequency03','UPS1: Input Frequency L3',1,'2015-08-18 07:40:29.535','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Input Frequency L3',0,'Hz'),(7,'UPS1_InputVoltage01','UPS1: Input Voltage L1',1,'2015-08-18 07:40:29.551','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Input Voltage L1',0,'V'),(8,'UPS1_InputVoltage02','UPS1: Input Voltage L2',1,'2015-08-18 07:40:29.566','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Input Voltage L2',0,'V'),(9,'UPS1_InputVoltage03','UPS1: Input Voltage L3',1,'2015-08-18 07:40:29.582','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Input Voltage L3',0,'V'),(10,'UPS1_InputCurrent01','UPS1: Input Current L1',1,'2015-08-18 07:40:29.582','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Input Current L1',0,'A'),(11,'UPS1_InputCurrent02','UPS1: Input Current L2',1,'2015-08-18 07:40:29.598','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Input Current L2',0,'A'),(12,'UPS1_InputCurrent03','UPS1: Input Current L3',1,'2015-08-18 07:40:29.613','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Input Current L3',0,'A'),(13,'UPS1_InputTruePower01','UPS1: Input True Power L1',1,'2015-08-18 07:40:29.629','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Input True Power L1',0,'W'),(14,'UPS1_InputTruePower02','UPS1: Input True Power L2',1,'2015-08-18 07:40:29.645','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Input True Power L2',0,'W'),(15,'UPS1_InputTruePower03','UPS1: Input True Power L3',1,'2015-08-18 07:40:29.645','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Input True Power L3',0,'W'),(16,'UPS1_BypassFrequency','UPS1: Bypass Frequency ',1,'2015-08-18 07:40:29.660','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Bypass Frequency ',0,'Hz'),(17,'UPS1_BypassVoltage01','UPS1: Bypass Voltage L1',1,'2015-08-18 07:40:29.676','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Bypass Voltage L1',0,'V'),(18,'UPS1_BypassVoltage02','UPS1: Bypass Voltage L2',1,'2015-08-18 07:40:29.691','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Bypass Voltage L2',0,'V'),(19,'UPS1_BypassVoltage03','UPS1: Bypass Voltage L3',1,'2015-08-18 07:40:29.707','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Bypass Voltage L3',0,'V'),(20,'UPS1_BypassCurrent01','UPS1: Bypass Current L1',1,'2015-08-18 07:40:29.723','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Bypass Current L1',0,'A'),(21,'UPS1_BypassCurrent02','UPS1: Bypass Current L2',1,'2015-08-18 07:40:29.723','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Bypass Current L2',0,'A'),(22,'UPS1_BypassCurrent03','UPS1: Bypass Current L3',1,'2015-08-18 07:40:29.738','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Bypass Current L3',0,'A'),(23,'UPS1_BypassPower01','UPS1: Bypass Power L1',1,'2015-08-18 07:40:29.754','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Bypass Power L1',0,'kW'),(24,'UPS1_BypassPower02','UPS1: Bypass Power L2',1,'2015-08-18 07:40:29.770','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Bypass Power L2',0,'kW'),(25,'UPS1_BypassPower03','UPS1: Bypass Power L3',1,'2015-08-18 07:40:29.785','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Bypass Power L3',0,'kW'),(26,'UPS1_OutputFrequency','UPS1: Output Frequency ',1,'2015-08-18 07:40:29.785','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Output Frequency ',0,'Hz'),(27,'UPS1_OutputVoltage01','UPS1: Output Voltage L1',1,'2015-08-18 07:40:29.801','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Output Voltage L1',0,'V'),(28,'UPS1_OutputVoltage02','UPS1: Output Voltage L2',1,'2015-08-18 07:40:29.816','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Output Voltage L2',0,'V'),(29,'UPS1_OutputVoltage03','UPS1: Output Voltage L3',1,'2015-08-18 07:40:29.832','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Output Voltage L3',0,'V'),(30,'UPS1_OutputCurrent01','UPS1: Output Current L1',1,'2015-08-18 07:40:29.848','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Output Current L1',0,'A'),(31,'UPS1_OutputCurrent02','UPS1: Output Current L2',1,'2015-08-18 07:40:29.848','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Output Current L2',0,'A'),(32,'UPS1_OutputCurrent03','UPS1: Output Current L3',1,'2015-08-18 07:40:29.863','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Output Current L3',0,'A'),(33,'UPS1_OutputPower01','UPS1: Output Power L1',1,'2015-08-18 07:40:29.879','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Output Power L1',0,'kW'),(34,'UPS1_OutputPower02','UPS1: Output Power L2',1,'2015-08-18 07:40:29.895','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Output Power L2',0,'kW'),(35,'UPS1_OutputPower03','UPS1: Output Power L3',1,'2015-08-18 07:40:29.910','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Output Power L3',0,'kW'),(36,'UPS1_OutputPercentLoad01','UPS1: Output Percent Load L1',1,'2015-08-18 07:40:29.910','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Output Percent Load L1',0,'%'),(37,'UPS1_OutputPercentLoad02','UPS1: Output Percent Load L2',1,'2015-08-18 07:40:29.926','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Output Percent Load L2',0,'%'),(38,'UPS1_OutputPercentLoad03','UPS1: Output Percent Load L3',1,'2015-08-18 07:40:29.941','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Output Percent Load L3',0,'%'),(39,'UPS1_BatteryStatus','UPS1: Battery Status',1,'2015-08-18 07:40:29.957','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Battery Status',0,'---'),(40,'UPS1_BatteryTemperature','UPS1: Battery Temperature',1,'2015-08-18 07:40:29.973','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Battery Temperature',0,'°C'),(41,'UPS1_BatteryVoltage','UPS1: Battery Voltage ',1,'2015-08-18 07:40:29.988','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Battery Voltage ',0,'V'),(42,'UPS1_BatteryCurrent','UPS1: Battery Current ',1,'2015-08-18 07:40:29.988','2015-07-17 22:12:00.000',10,'Analogue','UPS1: Battery Current ',0,'A'),(43,'UPS2_EstimatedMinutesRemaining','UPS2: Estimated Minutes Remaining',1,'2015-08-18 07:40:30.004','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Estimated Minutes Remaining',0,'min'),(44,'UPS2_EstimatedChargeRemaining','UPS2: Estimated Charge Remaining',1,'2015-08-18 07:40:30.020','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Estimated Charge Remaining',0,'min'),(45,'UPS2_OutputSource','UPS2: Output Source',1,'2015-08-18 07:40:30.035','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Output Source',0,'---'),(46,'UPS2_InputFrequency01','UPS2: Input Frequency L1',1,'2015-08-18 07:40:30.051','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Input Frequency L1',0,'Hz'),(47,'UPS2_InputFrequency02','UPS2: Input Frequency L2',1,'2015-08-18 07:40:30.051','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Input Frequency L2',0,'Hz'),(48,'UPS2_InputFrequency03','UPS2: Input Frequency L3',1,'2015-08-18 07:40:30.066','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Input Frequency L3',0,'Hz'),(49,'UPS2_InputVoltage01','UPS2: Input Voltage L1',1,'2015-08-18 07:40:30.082','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Input Voltage L1',0,'V'),(50,'UPS2_InputVoltage02','UPS2: Input Voltage L2',1,'2015-08-18 07:40:30.098','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Input Voltage L2',0,'V'),(51,'UPS2_InputVoltage03','UPS2: Input Voltage L3',1,'2015-08-18 07:40:30.113','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Input Voltage L3',0,'V'),(52,'UPS2_InputCurrent01','UPS2: Input Current L1',1,'2015-08-18 07:40:30.113','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Input Current L1',0,'A'),(53,'UPS2_InputCurrent02','UPS2: Input Current L2',1,'2015-08-18 07:40:30.129','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Input Current L2',0,'A'),(54,'UPS2_InputCurrent03','UPS2: Input Current L3',1,'2015-08-18 07:40:30.145','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Input Current L3',0,'A'),(55,'UPS2_InputTruePower01','UPS2: Input True Power L1',1,'2015-08-18 07:40:30.160','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Input True Power L1',0,'W'),(56,'UPS2_InputTruePower02','UPS2: Input True Power L2',1,'2015-08-18 07:40:30.176','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Input True Power L2',0,'W'),(57,'UPS2_InputTruePower03','UPS2: Input True Power L3',1,'2015-08-18 07:40:30.176','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Input True Power L3',0,'W'),(58,'UPS2_BypassFrequency','UPS2: Bypass Frequency ',1,'2015-08-18 07:40:30.191','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Bypass Frequency ',0,'Hz'),(59,'UPS2_BypassVoltage01','UPS2: Bypass Voltage L1',1,'2015-08-18 07:40:30.207','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Bypass Voltage L1',0,'V'),(60,'UPS2_BypassVoltage02','UPS2: Bypass Voltage L2',1,'2015-08-18 07:40:30.223','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Bypass Voltage L2',0,'V'),(61,'UPS2_BypassVoltage03','UPS2: Bypass Voltage L3',1,'2015-08-18 07:40:30.238','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Bypass Voltage L3',0,'V'),(62,'UPS2_BypassCurrent01','UPS2: Bypass Current L1',1,'2015-08-18 07:40:30.238','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Bypass Current L1',0,'A'),(63,'UPS2_BypassCurrent02','UPS2: Bypass Current L2',1,'2015-08-18 07:40:30.254','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Bypass Current L2',0,'A'),(64,'UPS2_BypassCurrent03','UPS2: Bypass Current L3',1,'2015-08-18 07:40:30.270','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Bypass Current L3',0,'A'),(65,'UPS2_BypassPower01','UPS2: Bypass Power L1',1,'2015-08-18 07:40:30.285','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Bypass Power L1',0,'kW'),(66,'UPS2_BypassPower02','UPS2: Bypass Power L2',1,'2015-08-18 07:40:30.301','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Bypass Power L2',0,'kW'),(67,'UPS2_BypassPower03','UPS2: Bypass Power L3',1,'2015-08-18 07:40:30.301','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Bypass Power L3',0,'kW'),(68,'UPS2_OutputFrequency','UPS2: Output Frequency ',1,'2015-08-18 07:40:30.316','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Output Frequency ',0,'Hz'),(69,'UPS2_OutputVoltage01','UPS2: Output Voltage L1',1,'2015-08-18 07:40:30.332','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Output Voltage L1',0,'V'),(70,'UPS2_OutputVoltage02','UPS2: Output Voltage L2',1,'2015-08-18 07:40:30.348','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Output Voltage L2',0,'V'),(71,'UPS2_OutputVoltage03','UPS2: Output Voltage L3',1,'2015-08-18 07:40:30.363','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Output Voltage L3',0,'V'),(72,'UPS2_OutputCurrent01','UPS2: Output Current L1',1,'2015-08-18 07:40:30.379','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Output Current L1',0,'A'),(73,'UPS2_OutputCurrent02','UPS2: Output Current L2',1,'2015-08-18 07:40:30.379','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Output Current L2',0,'A'),(74,'UPS2_OutputCurrent03','UPS2: Output Current L3',1,'2015-08-18 07:40:30.395','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Output Current L3',0,'A'),(75,'UPS2_OutputPower01','UPS2: Output Power L1',1,'2015-08-18 07:40:30.410','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Output Power L1',0,'kW'),(76,'UPS2_OutputPower02','UPS2: Output Power L2',1,'2015-08-18 07:40:30.426','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Output Power L2',0,'kW'),(77,'UPS2_OutputPower03','UPS2: Output Power L3',1,'2015-08-18 07:40:30.441','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Output Power L3',0,'kW'),(78,'UPS2_OutputPercentLoad01','UPS2: Output Percent Load L1',1,'2015-08-18 07:40:30.441','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Output Percent Load L1',0,'%'),(79,'UPS2_OutputPercentLoad02','UPS2: Output Percent Load L2',1,'2015-08-18 07:40:30.457','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Output Percent Load L2',0,'%'),(80,'UPS2_OutputPercentLoad03','UPS2: Output Percent Load L3',1,'2015-08-18 07:40:30.473','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Output Percent Load L3',0,'%'),(81,'UPS2_BatteryStatus','UPS2: Battery Status',1,'2015-08-18 07:40:30.488','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Battery Status',0,'---'),(82,'UPS2_BatteryTemperature','UPS2: Battery Temperature',1,'2015-08-18 07:40:30.504','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Battery Temperature',0,'°C'),(83,'UPS2_BatteryVoltage','UPS2: Battery Voltage ',1,'2015-08-18 07:40:30.520','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Battery Voltage ',0,'V'),(84,'UPS2_BatteryCurrent','UPS2: Battery Current ',1,'2015-08-18 07:40:30.520','2015-07-17 22:12:00.000',11,'Analogue','UPS2: Battery Current ',0,'A'),(85,'UPS3_EstimatedMinutesRemaining','UPS3: Estimated Minutes Remaining',1,'2015-08-18 07:40:30.535','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Estimated Minutes Remaining',0,'min'),(86,'UPS3_EstimatedChargeRemaining','UPS3: Estimated Charge Remaining',1,'2015-08-18 07:40:30.551','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Estimated Charge Remaining',0,'min'),(87,'UPS3_OutputSource','UPS3: Output Source',1,'2015-08-18 07:40:30.566','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Output Source',0,'---'),(88,'UPS3_InputFrequency01','UPS3: Input Frequency L1',1,'2015-08-18 07:40:30.582','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Input Frequency L1',0,'Hz'),(89,'UPS3_InputFrequency02','UPS3: Input Frequency L2',1,'2015-08-18 07:40:30.582','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Input Frequency L2',0,'Hz'),(90,'UPS3_InputFrequency03','UPS3: Input Frequency L3',1,'2015-08-18 07:40:30.598','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Input Frequency L3',0,'Hz'),(91,'UPS3_InputVoltage01','UPS3: Input Voltage L1',1,'2015-08-18 07:40:30.613','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Input Voltage L1',0,'V'),(92,'UPS3_InputVoltage02','UPS3: Input Voltage L2',1,'2015-08-18 07:40:30.629','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Input Voltage L2',0,'V'),(93,'UPS3_InputVoltage03','UPS3: Input Voltage L3',1,'2015-08-18 07:40:30.645','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Input Voltage L3',0,'V'),(94,'UPS3_InputCurrent01','UPS3: Input Current L1',1,'2015-08-18 07:40:30.645','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Input Current L1',0,'A'),(95,'UPS3_InputCurrent02','UPS3: Input Current L2',1,'2015-08-18 07:40:30.660','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Input Current L2',0,'A'),(96,'UPS3_InputCurrent03','UPS3: Input Current L3',1,'2015-08-18 07:40:30.676','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Input Current L3',0,'A'),(97,'UPS3_InputTruePower01','UPS3: Input True Power L1',1,'2015-08-18 07:40:30.691','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Input True Power L1',0,'W'),(98,'UPS3_InputTruePower02','UPS3: Input True Power L2',1,'2015-08-18 07:40:30.707','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Input True Power L2',0,'W'),(99,'UPS3_InputTruePower03','UPS3: Input True Power L3',1,'2015-08-18 07:40:30.723','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Input True Power L3',0,'W'),(100,'UPS3_BypassFrequency','UPS3: Bypass Frequency ',1,'2015-08-18 07:40:30.723','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Bypass Frequency ',0,'Hz'),(101,'UPS3_BypassVoltage01','UPS3: Bypass Voltage L1',1,'2015-08-18 07:40:30.738','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Bypass Voltage L1',0,'V'),(102,'UPS3_BypassVoltage02','UPS3: Bypass Voltage L2',1,'2015-08-18 07:40:30.770','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Bypass Voltage L2',0,'V'),(103,'UPS3_BypassVoltage03','UPS3: Bypass Voltage L3',1,'2015-08-18 07:40:30.785','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Bypass Voltage L3',0,'V'),(104,'UPS3_BypassCurrent01','UPS3: Bypass Current L1',1,'2015-08-18 07:40:30.801','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Bypass Current L1',0,'A'),(105,'UPS3_BypassCurrent02','UPS3: Bypass Current L2',1,'2015-08-18 07:40:30.816','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Bypass Current L2',0,'A'),(106,'UPS3_BypassCurrent03','UPS3: Bypass Current L3',1,'2015-08-18 07:40:30.832','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Bypass Current L3',0,'A'),(107,'UPS3_BypassPower01','UPS3: Bypass Power L1',1,'2015-08-18 07:40:30.848','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Bypass Power L1',0,'kW'),(108,'UPS3_BypassPower02','UPS3: Bypass Power L2',1,'2015-08-18 07:40:30.848','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Bypass Power L2',0,'kW'),(109,'UPS3_BypassPower03','UPS3: Bypass Power L3',1,'2015-08-18 07:40:30.863','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Bypass Power L3',0,'kW'),(110,'UPS3_OutputFrequency','UPS3: Output Frequency ',1,'2015-08-18 07:40:30.879','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Output Frequency ',0,'Hz'),(111,'UPS3_OutputVoltage01','UPS3: Output Voltage L1',1,'2015-08-18 07:40:30.895','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Output Voltage L1',0,'V'),(112,'UPS3_OutputVoltage02','UPS3: Output Voltage L2',1,'2015-08-18 07:40:30.910','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Output Voltage L2',0,'V'),(113,'UPS3_OutputVoltage03','UPS3: Output Voltage L3',1,'2015-08-18 07:40:30.910','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Output Voltage L3',0,'V'),(114,'UPS3_OutputCurrent01','UPS3: Output Current L1',1,'2015-08-18 07:40:30.926','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Output Current L1',0,'A'),(115,'UPS3_OutputCurrent02','UPS3: Output Current L2',1,'2015-08-18 07:40:30.941','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Output Current L2',0,'A'),(116,'UPS3_OutputCurrent03','UPS3: Output Current L3',1,'2015-08-18 07:40:30.957','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Output Current L3',0,'A'),(117,'UPS3_OutputPower01','UPS3: Output Power L1',1,'2015-08-18 07:40:30.973','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Output Power L1',0,'kW'),(118,'UPS3_OutputPower02','UPS3: Output Power L2',1,'2015-08-18 07:40:30.988','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Output Power L2',0,'kW'),(119,'UPS3_OutputPower03','UPS3: Output Power L3',1,'2015-08-18 07:40:30.988','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Output Power L3',0,'kW'),(120,'UPS3_OutputPercentLoad01','UPS3: Output Percent Load L1',1,'2015-08-18 07:40:31.004','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Output Percent Load L1',0,'%'),(121,'UPS3_OutputPercentLoad02','UPS3: Output Percent Load L2',1,'2015-08-18 07:40:31.020','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Output Percent Load L2',0,'%'),(122,'UPS3_OutputPercentLoad03','UPS3: Output Percent Load L3',1,'2015-08-18 07:40:31.035','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Output Percent Load L3',0,'%'),(123,'UPS3_BatteryStatus','UPS3: Battery Status',1,'2015-08-18 07:40:31.051','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Battery Status',0,'---'),(124,'UPS3_BatteryTemperature','UPS3: Battery Temperature',1,'2015-08-18 07:40:31.051','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Battery Temperature',0,'°C'),(125,'UPS3_BatteryVoltage','UPS3: Battery Voltage ',1,'2015-08-18 07:40:31.066','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Battery Voltage ',0,'V'),(126,'UPS3_BatteryCurrent','UPS3: Battery Current ',1,'2015-08-18 07:40:31.082','2015-07-17 22:12:00.000',12,'Analogue','UPS3: Battery Current ',0,'A'),(127,'UPS4_EstimatedMinutesRemaining','UPS4: Estimated Minutes Remaining',1,'2015-08-18 07:40:31.098','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Estimated Minutes Remaining',0,'min'),(128,'UPS4_EstimatedChargeRemaining','UPS4: Estimated Charge Remaining',1,'2015-08-18 07:40:31.113','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Estimated Charge Remaining',0,'min'),(129,'UPS4_OutputSource','UPS4: Output Source',1,'2015-08-18 07:40:31.129','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Output Source',0,'---'),(130,'UPS4_InputFrequency01','UPS4: Input Frequency L1',1,'2015-08-18 07:40:31.129','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Input Frequency L1',0,'Hz'),(131,'UPS4_InputFrequency02','UPS4: Input Frequency L2',1,'2015-08-18 07:40:31.145','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Input Frequency L2',0,'Hz'),(132,'UPS4_InputFrequency03','UPS4: Input Frequency L3',1,'2015-08-18 07:40:31.160','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Input Frequency L3',0,'Hz'),(133,'UPS4_InputVoltage01','UPS4: Input Voltage L1',1,'2015-08-18 07:40:31.176','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Input Voltage L1',0,'V'),(134,'UPS4_InputVoltage02','UPS4: Input Voltage L2',1,'2015-08-18 07:40:31.191','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Input Voltage L2',0,'V'),(135,'UPS4_InputVoltage03','UPS4: Input Voltage L3',1,'2015-08-18 07:40:31.191','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Input Voltage L3',0,'V'),(136,'UPS4_InputCurrent01','UPS4: Input Current L1',1,'2015-08-18 07:40:31.207','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Input Current L1',0,'A'),(137,'UPS4_InputCurrent02','UPS4: Input Current L2',1,'2015-08-18 07:40:31.223','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Input Current L2',0,'A'),(138,'UPS4_InputCurrent03','UPS4: Input Current L3',1,'2015-08-18 07:40:31.238','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Input Current L3',0,'A'),(139,'UPS4_InputTruePower01','UPS4: Input True Power L1',1,'2015-08-18 07:40:31.254','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Input True Power L1',0,'W'),(140,'UPS4_InputTruePower02','UPS4: Input True Power L2',1,'2015-08-18 07:40:31.254','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Input True Power L2',0,'W'),(141,'UPS4_InputTruePower03','UPS4: Input True Power L3',1,'2015-08-18 07:40:31.270','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Input True Power L3',0,'W'),(142,'UPS4_BypassFrequency','UPS4: Bypass Frequency ',1,'2015-08-18 07:40:31.285','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Bypass Frequency ',0,'Hz'),(143,'UPS4_BypassVoltage01','UPS4: Bypass Voltage L1',1,'2015-08-18 07:40:31.301','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Bypass Voltage L1',0,'V'),(144,'UPS4_BypassVoltage02','UPS4: Bypass Voltage L2',1,'2015-08-18 07:40:31.316','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Bypass Voltage L2',0,'V'),(145,'UPS4_BypassVoltage03','UPS4: Bypass Voltage L3',1,'2015-08-18 07:40:31.332','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Bypass Voltage L3',0,'V'),(146,'UPS4_BypassCurrent01','UPS4: Bypass Current L1',1,'2015-08-18 07:40:31.332','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Bypass Current L1',0,'A'),(147,'UPS4_BypassCurrent02','UPS4: Bypass Current L2',1,'2015-08-18 07:40:31.348','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Bypass Current L2',0,'A'),(148,'UPS4_BypassCurrent03','UPS4: Bypass Current L3',1,'2015-08-18 07:40:31.363','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Bypass Current L3',0,'A'),(149,'UPS4_BypassPower01','UPS4: Bypass Power L1',1,'2015-08-18 07:40:31.379','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Bypass Power L1',0,'kW'),(150,'UPS4_BypassPower02','UPS4: Bypass Power L2',1,'2015-08-18 07:40:31.395','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Bypass Power L2',0,'kW'),(151,'UPS4_BypassPower03','UPS4: Bypass Power L3',1,'2015-08-18 07:40:31.395','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Bypass Power L3',0,'kW'),(152,'UPS4_OutputFrequency','UPS4: Output Frequency ',1,'2015-08-18 07:40:31.410','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Output Frequency ',0,'Hz'),(153,'UPS4_OutputVoltage01','UPS4: Output Voltage L1',1,'2015-08-18 07:40:31.426','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Output Voltage L1',0,'V'),(154,'UPS4_OutputVoltage02','UPS4: Output Voltage L2',1,'2015-08-18 07:40:31.441','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Output Voltage L2',0,'V'),(155,'UPS4_OutputVoltage03','UPS4: Output Voltage L3',1,'2015-08-18 07:40:31.457','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Output Voltage L3',0,'V'),(156,'UPS4_OutputCurrent01','UPS4: Output Current L1',1,'2015-08-18 07:40:31.457','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Output Current L1',0,'A'),(157,'UPS4_OutputCurrent02','UPS4: Output Current L2',1,'2015-08-18 07:40:31.473','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Output Current L2',0,'A'),(158,'UPS4_OutputCurrent03','UPS4: Output Current L3',1,'2015-08-18 07:40:31.488','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Output Current L3',0,'A'),(159,'UPS4_OutputPower01','UPS4: Output Power L1',1,'2015-08-18 07:40:31.504','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Output Power L1',0,'kW'),(160,'UPS4_OutputPower02','UPS4: Output Power L2',1,'2015-08-18 07:40:31.520','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Output Power L2',0,'kW'),(161,'UPS4_OutputPower03','UPS4: Output Power L3',1,'2015-08-18 07:40:31.535','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Output Power L3',0,'kW'),(162,'UPS4_OutputPercentLoad01','UPS4: Output Percent Load L1',1,'2015-08-18 07:40:31.535','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Output Percent Load L1',0,'%'),(163,'UPS4_OutputPercentLoad02','UPS4: Output Percent Load L2',1,'2015-08-18 07:40:31.551','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Output Percent Load L2',0,'%'),(164,'UPS4_OutputPercentLoad03','UPS4: Output Percent Load L3',1,'2015-08-18 07:40:31.566','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Output Percent Load L3',0,'%'),(165,'UPS4_BatteryStatus','UPS4: Battery Status',1,'2015-08-18 07:40:31.582','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Battery Status',0,'---'),(166,'UPS4_BatteryTemperature','UPS4: Battery Temperature',1,'2015-08-18 07:40:31.598','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Battery Temperature',0,'°C'),(167,'UPS4_BatteryVoltage','UPS4: Battery Voltage ',1,'2015-08-18 07:40:31.598','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Battery Voltage ',0,'V'),(168,'UPS4_BatteryCurrent','UPS4: Battery Current ',1,'2015-08-18 07:40:31.613','2015-07-17 22:12:00.000',13,'Analogue','UPS4: Battery Current ',0,'A'),(169,'DHCX1_UnitRuntimeUnit','DHCX1: Unit Runtime Unit ',1,'2015-08-18 07:40:31.629','2015-07-17 22:12:00.000',14,'Analogue','DHCX1: Unit Runtime Unit ',0,'Hour'),(170,'DHCX1_UnitSetpointTemperatureDay','DHCX1: Unit Setpoint Temperature Day',1,'2015-08-18 07:40:31.645','2015-07-17 22:12:00.000',14,'Analogue','DHCX1: Unit Setpoint Temperature Day',0,'°C'),(171,'DHCX1_UnitSetpointTemperatureNight','DHCX1: Unit Setpoint Temperature Night',1,'2015-08-18 07:40:31.660','2015-07-17 22:12:00.000',14,'Analogue','DHCX1: Unit Setpoint Temperature Night',0,'°C'),(172,'DHCX1_UnitSetpointHumidity','DHCX1: Unit Setpoint Humidity',1,'2015-08-18 07:40:31.660','2015-07-17 22:12:00.000',14,'Analogue','DHCX1: Unit Setpoint Humidity',0,'%RH'),(173,'DHCX1_UnitReturnAirTemperature','DHCX1: Unit Return Air Temperature ',1,'2015-08-18 07:40:31.676','2015-07-17 22:12:00.000',14,'Analogue','DHCX1: Unit Return Air Temperature ',0,'°C'),(174,'DHCX1_UnitReturnAirHumidity','DHCX1: Unit Return Air Humidity',1,'2015-08-18 07:40:31.691','2015-07-17 22:12:00.000',14,'Analogue','DHCX1: Unit Return Air Humidity',0,'%RH'),(175,'DHCX1_CommonAlarm','DHCX1: Common Alarm',1,'2015-08-18 07:40:31.707','2015-07-17 22:12:00.000',14,'Digital','DHCX1: Common Alarm',0,'---'),(176,'DHCX1_UnitOnOff','DHCX1: Unit OnOff',1,'2015-08-18 07:40:31.723','2015-07-17 22:12:00.000',14,'Digital','DHCX1: Unit OnOff',0,'---'),(177,'DHCX1_UnitCooling','DHCX1: Unit Cooling',1,'2015-08-18 07:40:31.738','2015-07-17 22:12:00.000',14,'Digital','DHCX1: Unit Cooling',0,'---'),(178,'DHCX1_UnitHeating','DHCX1: Unit Heating',1,'2015-08-18 07:40:31.738','2015-07-17 22:12:00.000',14,'Digital','DHCX1: Unit Heating',0,'---'),(179,'DHCX1_UnitHumidification','DHCX1: Unit Humidification',1,'2015-08-18 07:40:31.770','2015-07-17 22:12:00.000',14,'Digital','DHCX1: Unit Humidification',0,'---'),(180,'DHCX1_UnitDehumidification','DHCX1: Unit Dehumidification',1,'2015-08-18 07:40:31.785','2015-07-17 22:12:00.000',14,'Digital','DHCX1: Unit Dehumidification',0,'---'),(181,'DHCX1_Airflow1','DHCX1: Air flow1',1,'2015-08-18 07:40:31.801','2015-07-17 22:12:00.000',14,'Analogue','DHCX1: Air flow1',0,'---'),(182,'DHCX1_Airflow2','DHCX1: Air flow2',1,'2015-08-18 07:40:31.816','2015-07-17 22:12:00.000',14,'Analogue','DHCX1: Air flow2',0,'---'),(183,'DHCX1_Airflow3','DHCX1: Air flow3',1,'2015-08-18 07:40:31.816','2015-07-17 22:12:00.000',14,'Analogue','DHCX1: Air flow3',0,'---'),(184,'DHCX1_HighPressure1','DHCX1: High Pressure1',1,'2015-08-18 07:40:31.832','2015-07-17 22:12:00.000',14,'Digital','DHCX1: High Pressure1',0,'---'),(185,'DHCX1_HighPressure2','DHCX1: High Pressure2',1,'2015-08-18 07:40:31.848','2015-07-17 22:12:00.000',14,'Digital','DHCX1: High Pressure2',0,'---'),(186,'DHCX1_HighPressure3','DHCX1: High Pressure3',1,'2015-08-18 07:40:31.863','2015-07-17 22:12:00.000',14,'Digital','DHCX1: High Pressure3',0,'---'),(187,'DHCX1_WaterDetector','DHCX1: WaterDetector',1,'2015-08-18 07:40:31.879','2015-07-17 22:12:00.000',14,'Digital','DHCX1: WaterDetector',0,'---'),(188,'DHCX1_PhaseCheck','DHCX1: PhaseCheck',1,'2015-08-18 07:40:31.879','2015-07-17 22:12:00.000',14,'Digital','DHCX1: PhaseCheck',0,'---'),(189,'DHCX1_FireSmoke','DHCX1: FireSmoke',1,'2015-08-18 07:40:31.895','2015-07-17 22:12:00.000',14,'Digital','DHCX1: FireSmoke',0,'---'),(190,'DHCX1_ReturnAirTempHighAlarm','DHCX1: Return Air Temp High Alarm',1,'2015-08-18 07:40:31.910','2015-07-17 22:12:00.000',14,'Digital','DHCX1: Return Air Temp High Alarm',0,'---'),(191,'DHCX1_ReturnAirHumidHighAlarm','DHCX1: Return Air Humid High Alarm',1,'2015-08-18 07:40:31.926','2015-07-17 22:12:00.000',14,'Digital','DHCX1: Return Air Humid High Alarm',0,'---'),(192,'DHCX1_SupplyAirTempHighAlarm','DHCX1: SupplyAir Temp High Alarm',1,'2015-08-18 07:40:31.941','2015-07-17 22:12:00.000',14,'Digital','DHCX1: SupplyAir Temp High Alarm',0,'---'),(193,'DHCX1_SupplyAirHumidHighAlarm','DHCX1: SupplyAir Humid High Alarm',1,'2015-08-18 07:40:31.941','2015-07-17 22:12:00.000',14,'Digital','DHCX1: SupplyAir Humid High Alarm',0,'---'),(194,'DHCX1_WaterTempHighAlarm','DHCX1: WaterTempHigh Alarm',1,'2015-08-18 07:40:31.957','2015-07-17 22:12:00.000',14,'Digital','DHCX1: WaterTempHigh Alarm',0,'---'),(195,'DHCX1_ReturnAirTempLowAlarm','DHCX1: Return Air Temp Low Alarm',1,'2015-08-18 07:40:31.973','2015-07-17 22:12:00.000',14,'Digital','DHCX1: Return Air Temp Low Alarm',0,'---'),(196,'DHCX1_ReturnAirHumidLowAlarm','DHCX1: Return Air Humid Low Alarm',1,'2015-08-18 07:40:31.988','2015-07-17 22:12:00.000',14,'Digital','DHCX1: Return Air Humid Low Alarm',0,'---'),(197,'DHCX1_SupplyAirTempLowAlarm','DHCX1: SupplyAir Temp Low Alarm',1,'2015-08-18 07:40:32.004','2015-07-17 22:12:00.000',14,'Digital','DHCX1: SupplyAir Temp Low Alarm',0,'---'),(198,'DHCX1_SupplyAirHumidLowAlarm','DHCX1: SupplyAir Humid Low Alarm',1,'2015-08-18 07:40:32.020','2015-07-17 22:12:00.000',14,'Digital','DHCX1: SupplyAir Humid Low Alarm',0,'---'),(199,'DHCX1_WaterTempLowAlarm','DHCX1: Water Temp Low Alarm',1,'2015-08-18 07:40:32.020','2015-07-17 22:12:00.000',14,'Digital','DHCX1: Water Temp Low Alarm',0,'---'),(200,'DHCX1_FreezeAlarm','DHCX1: Freeze Alarm',1,'2015-08-18 07:40:32.035','2015-07-17 22:12:00.000',14,'Digital','DHCX1: Freeze Alarm',0,'---'),(201,'DHCX2_UnitRuntimeUnit','DHCX2: Unit Runtime Unit ',1,'2015-08-18 07:40:32.051','2015-07-17 22:12:00.000',15,'Analogue','DHCX2: Unit Runtime Unit ',0,'Hour'),(202,'DHCX2_UnitSetpointTemperatureDay','DHCX2: Unit Setpoint Temperature Day',1,'2015-08-18 07:40:32.066','2015-07-17 22:12:00.000',15,'Analogue','DHCX2: Unit Setpoint Temperature Day',0,'°C'),(203,'DHCX2_UnitSetpointTemperatureNight','DHCX2: Unit Setpoint Temperature Night',1,'2015-08-18 07:40:32.082','2015-07-17 22:12:00.000',15,'Analogue','DHCX2: Unit Setpoint Temperature Night',0,'°C'),(204,'DHCX2_UnitSetpointHumidity','DHCX2: Unit Setpoint Humidity',1,'2015-08-18 07:40:32.082','2015-07-17 22:12:00.000',15,'Analogue','DHCX2: Unit Setpoint Humidity',0,'%RH'),(205,'DHCX2_UnitReturnAirTemperature','DHCX2: Unit Return Air Temperature ',1,'2015-08-18 07:40:32.098','2015-07-17 22:12:00.000',15,'Analogue','DHCX2: Unit Return Air Temperature ',0,'°C'),(206,'DHCX2_UnitReturnAirHumidity','DHCX2: Unit Return Air Humidity',1,'2015-08-18 07:40:32.113','2015-07-17 22:12:00.000',15,'Analogue','DHCX2: Unit Return Air Humidity',0,'%RH'),(207,'DHCX2_CommonAlarm','DHCX2: Common Alarm',1,'2015-08-18 07:40:32.129','2015-07-17 22:12:00.000',15,'Digital','DHCX2: Common Alarm',0,'---'),(208,'DHCX2_UnitOnOff','DHCX2: Unit OnOff',1,'2015-08-18 07:40:32.145','2015-07-17 22:12:00.000',15,'Digital','DHCX2: Unit OnOff',0,'---'),(209,'DHCX2_UnitCooling','DHCX2: Unit Cooling',1,'2015-08-18 07:40:32.145','2015-07-17 22:12:00.000',15,'Digital','DHCX2: Unit Cooling',0,'---'),(210,'DHCX2_UnitHeating','DHCX2: Unit Heating',1,'2015-08-18 07:40:32.160','2015-07-17 22:12:00.000',15,'Digital','DHCX2: Unit Heating',0,'---'),(211,'DHCX2_UnitHumidification','DHCX2: Unit Humidification',1,'2015-08-18 07:40:32.176','2015-07-17 22:12:00.000',15,'Digital','DHCX2: Unit Humidification',0,'---'),(212,'DHCX2_UnitDehumidification','DHCX2: Unit Dehumidification',1,'2015-08-18 07:40:32.191','2015-07-17 22:12:00.000',15,'Digital','DHCX2: Unit Dehumidification',0,'---'),(213,'DHCX2_Airflow1','DHCX2: Air flow1',1,'2015-08-18 07:40:32.207','2015-07-17 22:12:00.000',15,'Analogue','DHCX2: Air flow1',0,'---'),(214,'DHCX2_Airflow2','DHCX2: Air flow2',1,'2015-08-18 07:40:32.223','2015-07-17 22:12:00.000',15,'Analogue','DHCX2: Air flow2',0,'---'),(215,'DHCX2_Airflow3','DHCX2: Air flow3',1,'2015-08-18 07:40:32.223','2015-07-17 22:12:00.000',15,'Analogue','DHCX2: Air flow3',0,'---'),(216,'DHCX2_HighPressure1','DHCX2: High Pressure1',1,'2015-08-18 07:40:32.238','2015-07-17 22:12:00.000',15,'Digital','DHCX2: High Pressure1',0,'---'),(217,'DHCX2_HighPressure2','DHCX2: High Pressure2',1,'2015-08-18 07:40:32.254','2015-07-17 22:12:00.000',15,'Digital','DHCX2: High Pressure2',0,'---'),(218,'DHCX2_HighPressure3','DHCX2: High Pressure3',1,'2015-08-18 07:40:32.270','2015-07-17 22:12:00.000',15,'Digital','DHCX2: High Pressure3',0,'---'),(219,'DHCX2_WaterDetector','DHCX2: WaterDetector',1,'2015-08-18 07:40:32.285','2015-07-17 22:12:00.000',15,'Digital','DHCX2: WaterDetector',0,'---'),(220,'DHCX2_PhaseCheck','DHCX2: PhaseCheck',1,'2015-08-18 07:40:32.285','2015-07-17 22:12:00.000',15,'Digital','DHCX2: PhaseCheck',0,'---'),(221,'DHCX2_FireSmoke','DHCX2: FireSmoke',1,'2015-08-18 07:40:32.301','2015-07-17 22:12:00.000',15,'Digital','DHCX2: FireSmoke',0,'---'),(222,'DHCX2_ReturnAirTempHighAlarm','DHCX2: Return Air Temp High Alarm',1,'2015-08-18 07:40:32.316','2015-07-17 22:12:00.000',15,'Digital','DHCX2: Return Air Temp High Alarm',0,'---'),(223,'DHCX2_ReturnAirHumidHighAlarm','DHCX2: Return Air Humid High Alarm',1,'2015-08-18 07:40:32.332','2015-07-17 22:12:00.000',15,'Digital','DHCX2: Return Air Humid High Alarm',0,'---'),(224,'DHCX2_SupplyAirTempHighAlarm','DHCX2: SupplyAir Temp High Alarm',1,'2015-08-18 07:40:32.348','2015-07-17 22:12:00.000',15,'Digital','DHCX2: SupplyAir Temp High Alarm',0,'---'),(225,'DHCX2_SupplyAirHumidHighAlarm','DHCX2: SupplyAir Humid High Alarm',1,'2015-08-18 07:40:32.363','2015-07-17 22:12:00.000',15,'Digital','DHCX2: SupplyAir Humid High Alarm',0,'---'),(226,'DHCX2_WaterTempHighAlarm','DHCX2: WaterTempHigh Alarm',1,'2015-08-18 07:40:32.363','2015-07-17 22:12:00.000',15,'Digital','DHCX2: WaterTempHigh Alarm',0,'---'),(227,'DHCX2_ReturnAirTempLowAlarm','DHCX2: Return Air Temp Low Alarm',1,'2015-08-18 07:40:32.379','2015-07-17 22:12:00.000',15,'Digital','DHCX2: Return Air Temp Low Alarm',0,'---'),(228,'DHCX2_ReturnAirHumidLowAlarm','DHCX2: Return Air Humid Low Alarm',1,'2015-08-18 07:40:32.395','2015-07-17 22:12:00.000',15,'Digital','DHCX2: Return Air Humid Low Alarm',0,'---'),(229,'DHCX2_SupplyAirTempLowAlarm','DHCX2: SupplyAir Temp Low Alarm',1,'2015-08-18 07:40:32.410','2015-07-17 22:12:00.000',15,'Digital','DHCX2: SupplyAir Temp Low Alarm',0,'---'),(230,'DHCX2_SupplyAirHumidLowAlarm','DHCX2: SupplyAir Humid Low Alarm',1,'2015-08-18 07:40:32.426','2015-07-17 22:12:00.000',15,'Digital','DHCX2: SupplyAir Humid Low Alarm',0,'---'),(231,'DHCX2_WaterTempLowAlarm','DHCX2: Water Temp Low Alarm',1,'2015-08-18 07:40:32.426','2015-07-17 22:12:00.000',15,'Digital','DHCX2: Water Temp Low Alarm',0,'---'),(232,'DHCX2_FreezeAlarm','DHCX2: Freeze Alarm',1,'2015-08-18 07:40:32.441','2015-07-17 22:12:00.000',15,'Digital','DHCX2: Freeze Alarm',0,'---'),(233,'DHCX3_UnitRuntimeUnit','DHCX3: Unit Runtime Unit ',1,'2015-08-18 07:40:32.457','2015-07-17 22:12:00.000',16,'Analogue','DHCX3: Unit Runtime Unit ',0,'Hour'),(234,'DHCX3_UnitSetpointTemperatureDay','DHCX3: Unit Setpoint Temperature Day',1,'2015-08-18 07:40:32.473','2015-07-17 22:12:00.000',16,'Analogue','DHCX3: Unit Setpoint Temperature Day',0,'°C'),(235,'DHCX3_UnitSetpointTemperatureNight','DHCX3: Unit Setpoint Temperature Night',1,'2015-08-18 07:40:32.488','2015-07-17 22:12:00.000',16,'Analogue','DHCX3: Unit Setpoint Temperature Night',0,'°C'),(236,'DHCX3_UnitSetpointHumidity','DHCX3: Unit Setpoint Humidity',1,'2015-08-18 07:40:32.488','2015-07-17 22:12:00.000',16,'Analogue','DHCX3: Unit Setpoint Humidity',0,'%RH'),(237,'DHCX3_UnitReturnAirTemperature','DHCX3: Unit Return Air Temperature ',1,'2015-08-18 07:40:32.504','2015-07-17 22:12:00.000',16,'Analogue','DHCX3: Unit Return Air Temperature ',0,'°C'),(238,'DHCX3_UnitReturnAirHumidity','DHCX3: Unit Return Air Humidity',1,'2015-08-18 07:40:32.520','2015-07-17 22:12:00.000',16,'Analogue','DHCX3: Unit Return Air Humidity',0,'%RH'),(239,'DHCX3_CommonAlarm','DHCX3: Common Alarm',1,'2015-08-18 07:40:32.535','2015-07-17 22:12:00.000',16,'Digital','DHCX3: Common Alarm',0,'---'),(240,'DHCX3_UnitOnOff','DHCX3: Unit OnOff',1,'2015-08-18 07:40:32.551','2015-07-17 22:12:00.000',16,'Digital','DHCX3: Unit OnOff',0,'---'),(241,'DHCX3_UnitCooling','DHCX3: Unit Cooling',1,'2015-08-18 07:40:32.566','2015-07-17 22:12:00.000',16,'Digital','DHCX3: Unit Cooling',0,'---'),(242,'DHCX3_UnitHeating','DHCX3: Unit Heating',1,'2015-08-18 07:40:32.566','2015-07-17 22:12:00.000',16,'Digital','DHCX3: Unit Heating',0,'---'),(243,'DHCX3_UnitHumidification','DHCX3: Unit Humidification',1,'2015-08-18 07:40:32.582','2015-07-17 22:12:00.000',16,'Digital','DHCX3: Unit Humidification',0,'---'),(244,'DHCX3_UnitDehumidification','DHCX3: Unit Dehumidification',1,'2015-08-18 07:40:32.598','2015-07-17 22:12:00.000',16,'Digital','DHCX3: Unit Dehumidification',0,'---'),(245,'DHCX3_Airflow1','DHCX3: Air flow1',1,'2015-08-18 07:40:32.613','2015-07-17 22:12:00.000',16,'Analogue','DHCX3: Air flow1',0,'---'),(246,'DHCX3_Airflow2','DHCX3: Air flow2',1,'2015-08-18 07:40:32.629','2015-07-17 22:12:00.000',16,'Analogue','DHCX3: Air flow2',0,'---'),(247,'DHCX3_Airflow3','DHCX3: Air flow3',1,'2015-08-18 07:40:32.629','2015-07-17 22:12:00.000',16,'Analogue','DHCX3: Air flow3',0,'---'),(248,'DHCX3_HighPressure1','DHCX3: High Pressure1',1,'2015-08-18 07:40:32.645','2015-07-17 22:12:00.000',16,'Digital','DHCX3: High Pressure1',0,'---'),(249,'DHCX3_HighPressure2','DHCX3: High Pressure2',1,'2015-08-18 07:40:32.660','2015-07-17 22:12:00.000',16,'Digital','DHCX3: High Pressure2',0,'---'),(250,'DHCX3_HighPressure3','DHCX3: High Pressure3',1,'2015-08-18 07:40:32.676','2015-07-17 22:12:00.000',16,'Digital','DHCX3: High Pressure3',0,'---'),(251,'DHCX3_WaterDetector','DHCX3: WaterDetector',1,'2015-08-18 07:40:32.691','2015-07-17 22:12:00.000',16,'Digital','DHCX3: WaterDetector',0,'---'),(252,'DHCX3_PhaseCheck','DHCX3: PhaseCheck',1,'2015-08-18 07:40:32.691','2015-07-17 22:12:00.000',16,'Digital','DHCX3: PhaseCheck',0,'---'),(253,'DHCX3_FireSmoke','DHCX3: FireSmoke',1,'2015-08-18 07:40:32.707','2015-07-17 22:12:00.000',16,'Digital','DHCX3: FireSmoke',0,'---'),(254,'DHCX3_ReturnAirTempHighAlarm','DHCX3: Return Air Temp High Alarm',1,'2015-08-18 07:40:32.723','2015-07-17 22:12:00.000',16,'Digital','DHCX3: Return Air Temp High Alarm',0,'---'),(255,'DHCX3_ReturnAirHumidHighAlarm','DHCX3: Return Air Humid High Alarm',1,'2015-08-18 07:40:32.738','2015-07-17 22:12:00.000',16,'Digital','DHCX3: Return Air Humid High Alarm',0,'---'),(256,'DHCX3_SupplyAirTempHighAlarm','DHCX3: SupplyAir Temp High Alarm',1,'2015-08-18 07:40:32.754','2015-07-17 22:12:00.000',16,'Digital','DHCX3: SupplyAir Temp High Alarm',0,'---'),(257,'DHCX3_SupplyAirHumidHighAlarm','DHCX3: SupplyAir Humid High Alarm',1,'2015-08-18 07:40:32.754','2015-07-17 22:12:00.000',16,'Digital','DHCX3: SupplyAir Humid High Alarm',0,'---'),(258,'DHCX3_WaterTempHighAlarm','DHCX3: WaterTempHigh Alarm',1,'2015-08-18 07:40:32.770','2015-07-17 22:12:00.000',16,'Digital','DHCX3: WaterTempHigh Alarm',0,'---'),(259,'DHCX3_ReturnAirTempLowAlarm','DHCX3: Return Air Temp Low Alarm',1,'2015-08-18 07:40:32.785','2015-07-17 22:12:00.000',16,'Digital','DHCX3: Return Air Temp Low Alarm',0,'---'),(260,'DHCX3_ReturnAirHumidLowAlarm','DHCX3: Return Air Humid Low Alarm',1,'2015-08-18 07:40:32.801','2015-07-17 22:12:00.000',16,'Digital','DHCX3: Return Air Humid Low Alarm',0,'---'),(261,'DHCX3_SupplyAirTempLowAlarm','DHCX3: SupplyAir Temp Low Alarm',1,'2015-08-18 07:40:32.816','2015-07-17 22:12:00.000',16,'Digital','DHCX3: SupplyAir Temp Low Alarm',0,'---'),(262,'DHCX3_SupplyAirHumidLowAlarm','DHCX3: SupplyAir Humid Low Alarm',1,'2015-08-18 07:40:32.832','2015-07-17 22:12:00.000',16,'Digital','DHCX3: SupplyAir Humid Low Alarm',0,'---'),(263,'DHCX3_WaterTempLowAlarm','DHCX3: Water Temp Low Alarm',1,'2015-08-18 07:40:32.832','2015-07-17 22:12:00.000',16,'Digital','DHCX3: Water Temp Low Alarm',0,'---'),(264,'DHCX3_FreezeAlarm','DHCX3: Freeze Alarm',1,'2015-08-18 07:40:32.848','2015-07-17 22:12:00.000',16,'Digital','DHCX3: Freeze Alarm',0,'---'),(265,'DHCX4_UnitRuntimeUnit','DHCX4: Unit Runtime Unit ',1,'2015-08-18 07:40:32.863','2015-07-17 22:12:00.000',17,'Analogue','DHCX4: Unit Runtime Unit ',0,'Hour'),(266,'DHCX4_UnitSetpointTemperatureDay','DHCX4: Unit Setpoint Temperature Day',1,'2015-08-18 07:40:32.879','2015-07-17 22:12:00.000',17,'Analogue','DHCX4: Unit Setpoint Temperature Day',0,'°C'),(267,'DHCX4_UnitSetpointTemperatureNight','DHCX4: Unit Setpoint Temperature Night',1,'2015-08-18 07:40:32.895','2015-07-17 22:12:00.000',17,'Analogue','DHCX4: Unit Setpoint Temperature Night',0,'°C'),(268,'DHCX4_UnitSetpointHumidity','DHCX4: Unit Setpoint Humidity',1,'2015-08-18 07:40:32.895','2015-07-17 22:12:00.000',17,'Analogue','DHCX4: Unit Setpoint Humidity',0,'%RH'),(269,'DHCX4_UnitReturnAirTemperature','DHCX4: Unit Return Air Temperature ',1,'2015-08-18 07:40:32.910','2015-07-17 22:12:00.000',17,'Analogue','DHCX4: Unit Return Air Temperature ',0,'°C'),(270,'DHCX4_UnitReturnAirHumidity','DHCX4: Unit Return Air Humidity',1,'2015-08-18 07:40:32.926','2015-07-17 22:12:00.000',17,'Analogue','DHCX4: Unit Return Air Humidity',0,'%RH'),(271,'DHCX4_CommonAlarm','DHCX4: Common Alarm',1,'2015-08-18 07:40:32.941','2015-07-17 22:12:00.000',17,'Digital','DHCX4: Common Alarm',0,'---'),(272,'DHCX4_UnitOnOff','DHCX4: Unit OnOff',1,'2015-08-18 07:40:32.957','2015-07-17 22:12:00.000',17,'Digital','DHCX4: Unit OnOff',0,'---'),(273,'DHCX4_UnitCooling','DHCX4: Unit Cooling',1,'2015-08-18 07:40:32.957','2015-07-17 22:12:00.000',17,'Digital','DHCX4: Unit Cooling',0,'---'),(274,'DHCX4_UnitHeating','DHCX4: Unit Heating',1,'2015-08-18 07:40:32.973','2015-07-17 22:12:00.000',17,'Digital','DHCX4: Unit Heating',0,'---'),(275,'DHCX4_UnitHumidification','DHCX4: Unit Humidification',1,'2015-08-18 07:40:32.988','2015-07-17 22:12:00.000',17,'Digital','DHCX4: Unit Humidification',0,'---'),(276,'DHCX4_UnitDehumidification','DHCX4: Unit Dehumidification',1,'2015-08-18 07:40:33.004','2015-07-17 22:12:00.000',17,'Digital','DHCX4: Unit Dehumidification',0,'---'),(277,'DHCX4_Airflow1','DHCX4: Air flow1',1,'2015-08-18 07:40:33.020','2015-07-17 22:12:00.000',17,'Analogue','DHCX4: Air flow1',0,'---'),(278,'DHCX4_Airflow2','DHCX4: Air flow2',1,'2015-08-18 07:40:33.035','2015-07-17 22:12:00.000',17,'Analogue','DHCX4: Air flow2',0,'---'),(279,'DHCX4_Airflow3','DHCX4: Air flow3',1,'2015-08-18 07:40:33.035','2015-07-17 22:12:00.000',17,'Analogue','DHCX4: Air flow3',0,'---'),(280,'DHCX4_HighPressure1','DHCX4: High Pressure1',1,'2015-08-18 07:40:33.051','2015-07-17 22:12:00.000',17,'Digital','DHCX4: High Pressure1',0,'---'),(281,'DHCX4_HighPressure2','DHCX4: High Pressure2',1,'2015-08-18 07:40:33.066','2015-07-17 22:12:00.000',17,'Digital','DHCX4: High Pressure2',0,'---'),(282,'DHCX4_HighPressure3','DHCX4: High Pressure3',1,'2015-08-18 07:40:33.082','2015-07-17 22:12:00.000',17,'Digital','DHCX4: High Pressure3',0,'---'),(283,'DHCX4_WaterDetector','DHCX4: WaterDetector',1,'2015-08-18 07:40:33.098','2015-07-17 22:12:00.000',17,'Digital','DHCX4: WaterDetector',0,'---'),(284,'DHCX4_PhaseCheck','DHCX4: PhaseCheck',1,'2015-08-18 07:40:33.098','2015-07-17 22:12:00.000',17,'Digital','DHCX4: PhaseCheck',0,'---'),(285,'DHCX4_FireSmoke','DHCX4: FireSmoke',1,'2015-08-18 07:40:33.113','2015-07-17 22:12:00.000',17,'Digital','DHCX4: FireSmoke',0,'---'),(286,'DHCX4_ReturnAirTempHighAlarm','DHCX4: Return Air Temp High Alarm',1,'2015-08-18 07:40:33.129','2015-07-17 22:12:00.000',17,'Digital','DHCX4: Return Air Temp High Alarm',0,'---'),(287,'DHCX4_ReturnAirHumidHighAlarm','DHCX4: Return Air Humid High Alarm',1,'2015-08-18 07:40:33.145','2015-07-17 22:12:00.000',17,'Digital','DHCX4: Return Air Humid High Alarm',0,'---'),(288,'DHCX4_SupplyAirTempHighAlarm','DHCX4: SupplyAir Temp High Alarm',1,'2015-08-18 07:40:33.160','2015-07-17 22:12:00.000',17,'Digital','DHCX4: SupplyAir Temp High Alarm',0,'---'),(289,'DHCX4_SupplyAirHumidHighAlarm','DHCX4: SupplyAir Humid High Alarm',1,'2015-08-18 07:40:33.176','2015-07-17 22:12:00.000',17,'Digital','DHCX4: SupplyAir Humid High Alarm',0,'---'),(290,'DHCX4_WaterTempHighAlarm','DHCX4: WaterTempHigh Alarm',1,'2015-08-18 07:40:33.176','2015-07-17 22:12:00.000',17,'Digital','DHCX4: WaterTempHigh Alarm',0,'---'),(291,'DHCX4_ReturnAirTempLowAlarm','DHCX4: Return Air Temp Low Alarm',1,'2015-08-18 07:40:33.191','2015-07-17 22:12:00.000',17,'Digital','DHCX4: Return Air Temp Low Alarm',0,'---'),(292,'DHCX4_ReturnAirHumidLowAlarm','DHCX4: Return Air Humid Low Alarm',1,'2015-08-18 07:40:33.238','2015-07-17 22:12:00.000',17,'Digital','DHCX4: Return Air Humid Low Alarm',0,'---'),(293,'DHCX4_SupplyAirTempLowAlarm','DHCX4: SupplyAir Temp Low Alarm',1,'2015-08-18 07:40:33.238','2015-07-17 22:12:00.000',17,'Digital','DHCX4: SupplyAir Temp Low Alarm',0,'---'),(294,'DHCX4_SupplyAirHumidLowAlarm','DHCX4: SupplyAir Humid Low Alarm',1,'2015-08-18 07:40:33.254','2015-07-17 22:12:00.000',17,'Digital','DHCX4: SupplyAir Humid Low Alarm',0,'---'),(295,'DHCX4_WaterTempLowAlarm','DHCX4: Water Temp Low Alarm',1,'2015-08-18 07:40:33.270','2015-07-17 22:12:00.000',17,'Digital','DHCX4: Water Temp Low Alarm',0,'---'),(296,'DHCX4_FreezeAlarm','DHCX4: Freeze Alarm',1,'2015-08-18 07:40:33.285','2015-07-17 22:12:00.000',17,'Digital','DHCX4: Freeze Alarm',0,'---'),(297,'DHCX5_UnitRuntimeUnit','DHCX5: Unit Runtime Unit ',1,'2015-08-18 07:40:33.301','2015-07-17 22:12:00.000',18,'Analogue','DHCX5: Unit Runtime Unit ',0,'Hour'),(298,'DHCX5_UnitSetpointTemperatureDay','DHCX5: Unit Setpoint Temperature Day',1,'2015-08-18 07:40:33.301','2015-07-17 22:12:00.000',18,'Analogue','DHCX5: Unit Setpoint Temperature Day',0,'°C'),(299,'DHCX5_UnitSetpointTemperatureNight','DHCX5: Unit Setpoint Temperature Night',1,'2015-08-18 07:40:33.316','2015-07-17 22:12:00.000',18,'Analogue','DHCX5: Unit Setpoint Temperature Night',0,'°C'),(300,'DHCX5_UnitSetpointHumidity','DHCX5: Unit Setpoint Humidity',1,'2015-08-18 07:40:33.332','2015-07-17 22:12:00.000',18,'Analogue','DHCX5: Unit Setpoint Humidity',0,'%RH'),(301,'DHCX5_UnitReturnAirTemperature','DHCX5: Unit Return Air Temperature ',1,'2015-08-18 07:40:33.348','2015-07-17 22:12:00.000',18,'Analogue','DHCX5: Unit Return Air Temperature ',0,'°C'),(302,'DHCX5_UnitReturnAirHumidity','DHCX5: Unit Return Air Humidity',1,'2015-08-18 07:40:33.363','2015-07-17 22:12:00.000',18,'Analogue','DHCX5: Unit Return Air Humidity',0,'%RH'),(303,'DHCX5_CommonAlarm','DHCX5: Common Alarm',1,'2015-08-18 07:40:33.363','2015-07-17 22:12:00.000',18,'Digital','DHCX5: Common Alarm',0,'---'),(304,'DHCX5_UnitOnOff','DHCX5: Unit OnOff',1,'2015-08-18 07:40:33.379','2015-07-17 22:12:00.000',18,'Digital','DHCX5: Unit OnOff',0,'---'),(305,'DHCX5_UnitCooling','DHCX5: Unit Cooling',1,'2015-08-18 07:40:33.395','2015-07-17 22:12:00.000',18,'Digital','DHCX5: Unit Cooling',0,'---'),(306,'DHCX5_UnitHeating','DHCX5: Unit Heating',1,'2015-08-18 07:40:33.410','2015-07-17 22:12:00.000',18,'Digital','DHCX5: Unit Heating',0,'---'),(307,'DHCX5_UnitHumidification','DHCX5: Unit Humidification',1,'2015-08-18 07:40:33.426','2015-07-17 22:12:00.000',18,'Digital','DHCX5: Unit Humidification',0,'---'),(308,'DHCX5_UnitDehumidification','DHCX5: Unit Dehumidification',1,'2015-08-18 07:40:33.426','2015-07-17 22:12:00.000',18,'Digital','DHCX5: Unit Dehumidification',0,'---'),(309,'DHCX5_Airflow1','DHCX5: Air flow1',1,'2015-08-18 07:40:33.442','2015-07-17 22:12:00.000',18,'Analogue','DHCX5: Air flow1',0,'---'),(310,'DHCX5_Airflow2','DHCX5: Air flow2',1,'2015-08-18 07:40:33.457','2015-07-17 22:12:00.000',18,'Analogue','DHCX5: Air flow2',0,'---'),(311,'DHCX5_Airflow3','DHCX5: Air flow3',1,'2015-08-18 07:40:33.488','2015-07-17 22:12:00.000',18,'Analogue','DHCX5: Air flow3',0,'---'),(312,'DHCX5_HighPressure1','DHCX5: High Pressure1',1,'2015-08-18 07:40:33.504','2015-07-17 22:12:00.000',18,'Digital','DHCX5: High Pressure1',0,'---'),(313,'DHCX5_HighPressure2','DHCX5: High Pressure2',1,'2015-08-18 07:40:33.520','2015-07-17 22:12:00.000',18,'Digital','DHCX5: High Pressure2',0,'---'),(314,'DHCX5_HighPressure3','DHCX5: High Pressure3',1,'2015-08-18 07:40:33.535','2015-07-17 22:12:00.000',18,'Digital','DHCX5: High Pressure3',0,'---'),(315,'DHCX5_WaterDetector','DHCX5: WaterDetector',1,'2015-08-18 07:40:33.551','2015-07-17 22:12:00.000',18,'Digital','DHCX5: WaterDetector',0,'---'),(316,'DHCX5_PhaseCheck','DHCX5: PhaseCheck',1,'2015-08-18 07:40:33.551','2015-07-17 22:12:00.000',18,'Digital','DHCX5: PhaseCheck',0,'---'),(317,'DHCX5_FireSmoke','DHCX5: FireSmoke',1,'2015-08-18 07:40:33.566','2015-07-17 22:12:00.000',18,'Digital','DHCX5: FireSmoke',0,'---'),(318,'DHCX5_ReturnAirTempHighAlarm','DHCX5: Return Air Temp High Alarm',1,'2015-08-18 07:40:33.582','2015-07-17 22:12:00.000',18,'Digital','DHCX5: Return Air Temp High Alarm',0,'---'),(319,'DHCX5_ReturnAirHumidHighAlarm','DHCX5: Return Air Humid High Alarm',1,'2015-08-18 07:40:33.598','2015-07-17 22:12:00.000',18,'Digital','DHCX5: Return Air Humid High Alarm',0,'---'),(320,'DHCX5_SupplyAirTempHighAlarm','DHCX5: SupplyAir Temp High Alarm',1,'2015-08-18 07:40:33.613','2015-07-17 22:12:00.000',18,'Digital','DHCX5: SupplyAir Temp High Alarm',0,'---'),(321,'DHCX5_SupplyAirHumidHighAlarm','DHCX5: SupplyAir Humid High Alarm',1,'2015-08-18 07:40:33.629','2015-07-17 22:12:00.000',18,'Digital','DHCX5: SupplyAir Humid High Alarm',0,'---'),(322,'DHCX5_WaterTempHighAlarm','DHCX5: WaterTempHigh Alarm',1,'2015-08-18 07:40:33.629','2015-07-17 22:12:00.000',18,'Digital','DHCX5: WaterTempHigh Alarm',0,'---'),(323,'DHCX5_ReturnAirTempLowAlarm','DHCX5: Return Air Temp Low Alarm',1,'2015-08-18 07:40:33.645','2015-07-17 22:12:00.000',18,'Digital','DHCX5: Return Air Temp Low Alarm',0,'---'),(324,'DHCX5_ReturnAirHumidLowAlarm','DHCX5: Return Air Humid Low Alarm',1,'2015-08-18 07:40:33.660','2015-07-17 22:12:00.000',18,'Digital','DHCX5: Return Air Humid Low Alarm',0,'---'),(325,'DHCX5_SupplyAirTempLowAlarm','DHCX5: SupplyAir Temp Low Alarm',1,'2015-08-18 07:40:33.676','2015-07-17 22:12:00.000',18,'Digital','DHCX5: SupplyAir Temp Low Alarm',0,'---'),(326,'DHCX5_SupplyAirHumidLowAlarm','DHCX5: SupplyAir Humid Low Alarm',1,'2015-08-18 07:40:33.692','2015-07-17 22:12:00.000',18,'Digital','DHCX5: SupplyAir Humid Low Alarm',0,'---'),(327,'DHCX5_WaterTempLowAlarm','DHCX5: Water Temp Low Alarm',1,'2015-08-18 07:40:33.692','2015-07-17 22:12:00.000',18,'Digital','DHCX5: Water Temp Low Alarm',0,'---'),(328,'DHCX5_FreezeAlarm','DHCX5: Freeze Alarm',1,'2015-08-18 07:40:33.707','2015-07-17 22:12:00.000',18,'Digital','DHCX5: Freeze Alarm',0,'---'),(329,'DHCX6_UnitRuntimeUnit','DHCX6: Unit Runtime Unit ',1,'2015-08-18 07:40:33.723','2015-07-17 22:12:00.000',19,'Analogue','DHCX6: Unit Runtime Unit ',0,'Hour'),(330,'DHCX6_UnitSetpointTemperatureDay','DHCX6: Unit Setpoint Temperature Day',1,'2015-08-18 07:40:33.738','2015-07-17 22:12:00.000',19,'Analogue','DHCX6: Unit Setpoint Temperature Day',0,'°C'),(331,'DHCX6_UnitSetpointTemperatureNight','DHCX6: Unit Setpoint Temperature Night',1,'2015-08-18 07:40:33.754','2015-07-17 22:12:00.000',19,'Analogue','DHCX6: Unit Setpoint Temperature Night',0,'°C'),(332,'DHCX6_UnitSetpointHumidity','DHCX6: Unit Setpoint Humidity',1,'2015-08-18 07:40:33.754','2015-07-17 22:12:00.000',19,'Analogue','DHCX6: Unit Setpoint Humidity',0,'%RH'),(333,'DHCX6_UnitReturnAirTemperature','DHCX6: Unit Return Air Temperature ',1,'2015-08-18 07:40:33.770','2015-07-17 22:12:00.000',19,'Analogue','DHCX6: Unit Return Air Temperature ',0,'°C'),(334,'DHCX6_UnitReturnAirHumidity','DHCX6: Unit Return Air Humidity',1,'2015-08-18 07:40:33.785','2015-07-17 22:12:00.000',19,'Analogue','DHCX6: Unit Return Air Humidity',0,'%RH'),(335,'DHCX6_CommonAlarm','DHCX6: Common Alarm',1,'2015-08-18 07:40:33.801','2015-07-17 22:12:00.000',19,'Digital','DHCX6: Common Alarm',0,'---'),(336,'DHCX6_UnitOnOff','DHCX6: Unit OnOff',1,'2015-08-18 07:40:33.816','2015-07-17 22:12:00.000',19,'Digital','DHCX6: Unit OnOff',0,'---'),(337,'DHCX6_UnitCooling','DHCX6: Unit Cooling',1,'2015-08-18 07:40:33.816','2015-07-17 22:12:00.000',19,'Digital','DHCX6: Unit Cooling',0,'---'),(338,'DHCX6_UnitHeating','DHCX6: Unit Heating',1,'2015-08-18 07:40:33.832','2015-07-17 22:12:00.000',19,'Digital','DHCX6: Unit Heating',0,'---'),(339,'DHCX6_UnitHumidification','DHCX6: Unit Humidification',1,'2015-08-18 07:40:33.848','2015-07-17 22:12:00.000',19,'Digital','DHCX6: Unit Humidification',0,'---'),(340,'DHCX6_UnitDehumidification','DHCX6: Unit Dehumidification',1,'2015-08-18 07:40:33.863','2015-07-17 22:12:00.000',19,'Digital','DHCX6: Unit Dehumidification',0,'---'),(341,'DHCX6_Airflow1','DHCX6: Air flow1',1,'2015-08-18 07:40:33.879','2015-07-17 22:12:00.000',19,'Analogue','DHCX6: Air flow1',0,'---'),(342,'DHCX6_Airflow2','DHCX6: Air flow2',1,'2015-08-18 07:40:33.879','2015-07-17 22:12:00.000',19,'Analogue','DHCX6: Air flow2',0,'---'),(343,'DHCX6_Airflow3','DHCX6: Air flow3',1,'2015-08-18 07:40:33.895','2015-07-17 22:12:00.000',19,'Analogue','DHCX6: Air flow3',0,'---'),(344,'DHCX6_HighPressure1','DHCX6: High Pressure1',1,'2015-08-18 07:40:33.910','2015-07-17 22:12:00.000',19,'Digital','DHCX6: High Pressure1',0,'---'),(345,'DHCX6_HighPressure2','DHCX6: High Pressure2',1,'2015-08-18 07:40:33.926','2015-07-17 22:12:00.000',19,'Digital','DHCX6: High Pressure2',0,'---'),(346,'DHCX6_HighPressure3','DHCX6: High Pressure3',1,'2015-08-18 07:40:33.941','2015-07-17 22:12:00.000',19,'Digital','DHCX6: High Pressure3',0,'---'),(347,'DHCX6_WaterDetector','DHCX6: WaterDetector',1,'2015-08-18 07:40:33.957','2015-07-17 22:12:00.000',19,'Digital','DHCX6: WaterDetector',0,'---'),(348,'DHCX6_PhaseCheck','DHCX6: PhaseCheck',1,'2015-08-18 07:40:33.957','2015-07-17 22:12:00.000',19,'Digital','DHCX6: PhaseCheck',0,'---'),(349,'DHCX6_FireSmoke','DHCX6: FireSmoke',1,'2015-08-18 07:40:33.973','2015-07-17 22:12:00.000',19,'Digital','DHCX6: FireSmoke',0,'---'),(350,'DHCX6_ReturnAirTempHighAlarm','DHCX6: Return Air Temp High Alarm',1,'2015-08-18 07:40:33.988','2015-07-17 22:12:00.000',19,'Digital','DHCX6: Return Air Temp High Alarm',0,'---'),(351,'DHCX6_ReturnAirHumidHighAlarm','DHCX6: Return Air Humid High Alarm',1,'2015-08-18 07:40:34.004','2015-07-17 22:12:00.000',19,'Digital','DHCX6: Return Air Humid High Alarm',0,'---'),(352,'DHCX6_SupplyAirTempHighAlarm','DHCX6: SupplyAir Temp High Alarm',1,'2015-08-18 07:40:34.020','2015-07-17 22:12:00.000',19,'Digital','DHCX6: SupplyAir Temp High Alarm',0,'---'),(353,'DHCX6_SupplyAirHumidHighAlarm','DHCX6: SupplyAir Humid High Alarm',1,'2015-08-18 07:40:34.020','2015-07-17 22:12:00.000',19,'Digital','DHCX6: SupplyAir Humid High Alarm',0,'---'),(354,'DHCX6_WaterTempHighAlarm','DHCX6: WaterTempHigh Alarm',1,'2015-08-18 07:40:34.035','2015-07-17 22:12:00.000',19,'Digital','DHCX6: WaterTempHigh Alarm',0,'---'),(355,'DHCX6_ReturnAirTempLowAlarm','DHCX6: Return Air Temp Low Alarm',1,'2015-08-18 07:40:34.051','2015-07-17 22:12:00.000',19,'Digital','DHCX6: Return Air Temp Low Alarm',0,'---'),(356,'DHCX6_ReturnAirHumidLowAlarm','DHCX6: Return Air Humid Low Alarm',1,'2015-08-18 07:40:34.066','2015-07-17 22:12:00.000',19,'Digital','DHCX6: Return Air Humid Low Alarm',0,'---'),(357,'DHCX6_SupplyAirTempLowAlarm','DHCX6: SupplyAir Temp Low Alarm',1,'2015-08-18 07:40:34.145','2015-07-17 22:12:00.000',19,'Digital','DHCX6: SupplyAir Temp Low Alarm',0,'---'),(358,'DHCX6_SupplyAirHumidLowAlarm','DHCX6: SupplyAir Humid Low Alarm',1,'2015-08-18 07:40:34.160','2015-07-17 22:12:00.000',19,'Digital','DHCX6: SupplyAir Humid Low Alarm',0,'---'),(359,'DHCX6_WaterTempLowAlarm','DHCX6: Water Temp Low Alarm',1,'2015-08-18 07:40:34.176','2015-07-17 22:12:00.000',19,'Digital','DHCX6: Water Temp Low Alarm',0,'---'),(360,'DHCX6_FreezeAlarm','DHCX6: Freeze Alarm',1,'2015-08-18 07:40:34.192','2015-07-17 22:12:00.000',19,'Digital','DHCX6: Freeze Alarm',0,'---'),(361,'DHCX7_UnitRuntimeUnit','DHCX7: Unit Runtime Unit ',1,'2015-08-18 07:40:34.192','2015-07-17 22:12:00.000',20,'Analogue','DHCX7: Unit Runtime Unit ',0,'Hour'),(362,'DHCX7_UnitSetpointTemperatureDay','DHCX7: Unit Setpoint Temperature Day',1,'2015-08-18 07:40:34.207','2015-07-17 22:12:00.000',20,'Analogue','DHCX7: Unit Setpoint Temperature Day',0,'°C'),(363,'DHCX7_UnitSetpointTemperatureNight','DHCX7: Unit Setpoint Temperature Night',1,'2015-08-18 07:40:34.223','2015-07-17 22:12:00.000',20,'Analogue','DHCX7: Unit Setpoint Temperature Night',0,'°C'),(364,'DHCX7_UnitSetpointHumidity','DHCX7: Unit Setpoint Humidity',1,'2015-08-18 07:40:34.238','2015-07-17 22:12:00.000',20,'Analogue','DHCX7: Unit Setpoint Humidity',0,'%RH'),(365,'DHCX7_UnitReturnAirTemperature','DHCX7: Unit Return Air Temperature ',1,'2015-08-18 07:40:34.254','2015-07-17 22:12:00.000',20,'Analogue','DHCX7: Unit Return Air Temperature ',0,'°C'),(366,'DHCX7_UnitReturnAirHumidity','DHCX7: Unit Return Air Humidity',1,'2015-08-18 07:40:34.254','2015-07-17 22:12:00.000',20,'Analogue','DHCX7: Unit Return Air Humidity',0,'%RH'),(367,'DHCX7_CommonAlarm','DHCX7: Common Alarm',1,'2015-08-18 07:40:34.270','2015-07-17 22:12:00.000',20,'Digital','DHCX7: Common Alarm',0,'---'),(368,'DHCX7_UnitOnOff','DHCX7: Unit OnOff',1,'2015-08-18 07:40:34.285','2015-07-17 22:12:00.000',20,'Digital','DHCX7: Unit OnOff',0,'---'),(369,'DHCX7_UnitCooling','DHCX7: Unit Cooling',1,'2015-08-18 07:40:34.301','2015-07-17 22:12:00.000',20,'Digital','DHCX7: Unit Cooling',0,'---'),(370,'DHCX7_UnitHeating','DHCX7: Unit Heating',1,'2015-08-18 07:40:34.317','2015-07-17 22:12:00.000',20,'Digital','DHCX7: Unit Heating',0,'---'),(371,'DHCX7_UnitHumidification','DHCX7: Unit Humidification',1,'2015-08-18 07:40:34.317','2015-07-17 22:12:00.000',20,'Digital','DHCX7: Unit Humidification',0,'---'),(372,'DHCX7_UnitDehumidification','DHCX7: Unit Dehumidification',1,'2015-08-18 07:40:34.332','2015-07-17 22:12:00.000',20,'Digital','DHCX7: Unit Dehumidification',0,'---'),(373,'DHCX7_Airflow1','DHCX7: Air flow1',1,'2015-08-18 07:40:34.348','2015-07-17 22:12:00.000',20,'Analogue','DHCX7: Air flow1',0,'---'),(374,'DHCX7_Airflow2','DHCX7: Air flow2',1,'2015-08-18 07:40:34.363','2015-07-17 22:12:00.000',20,'Analogue','DHCX7: Air flow2',0,'---'),(375,'DHCX7_Airflow3','DHCX7: Air flow3',1,'2015-08-18 07:40:34.379','2015-07-17 22:12:00.000',20,'Analogue','DHCX7: Air flow3',0,'---'),(376,'DHCX7_HighPressure1','DHCX7: High Pressure1',1,'2015-08-18 07:40:34.395','2015-07-17 22:12:00.000',20,'Digital','DHCX7: High Pressure1',0,'---'),(377,'DHCX7_HighPressure2','DHCX7: High Pressure2',1,'2015-08-18 07:40:34.395','2015-07-17 22:12:00.000',20,'Digital','DHCX7: High Pressure2',0,'---'),(378,'DHCX7_HighPressure3','DHCX7: High Pressure3',1,'2015-08-18 07:40:34.410','2015-07-17 22:12:00.000',20,'Digital','DHCX7: High Pressure3',0,'---'),(379,'DHCX7_WaterDetector','DHCX7: WaterDetector',1,'2015-08-18 07:40:34.426','2015-07-17 22:12:00.000',20,'Digital','DHCX7: WaterDetector',0,'---'),(380,'DHCX7_PhaseCheck','DHCX7: PhaseCheck',1,'2015-08-18 07:40:34.442','2015-07-17 22:12:00.000',20,'Digital','DHCX7: PhaseCheck',0,'---'),(381,'DHCX7_FireSmoke','DHCX7: FireSmoke',1,'2015-08-18 07:40:34.457','2015-07-17 22:12:00.000',20,'Digital','DHCX7: FireSmoke',0,'---'),(382,'DHCX7_ReturnAirTempHighAlarm','DHCX7: Return Air Temp High Alarm',1,'2015-08-18 07:40:34.457','2015-07-17 22:12:00.000',20,'Digital','DHCX7: Return Air Temp High Alarm',0,'---'),(383,'DHCX7_ReturnAirHumidHighAlarm','DHCX7: Return Air Humid High Alarm',1,'2015-08-18 07:40:34.473','2015-07-17 22:12:00.000',20,'Digital','DHCX7: Return Air Humid High Alarm',0,'---'),(384,'DHCX7_SupplyAirTempHighAlarm','DHCX7: SupplyAir Temp High Alarm',1,'2015-08-18 07:40:34.488','2015-07-17 22:12:00.000',20,'Digital','DHCX7: SupplyAir Temp High Alarm',0,'---'),(385,'DHCX7_SupplyAirHumidHighAlarm','DHCX7: SupplyAir Humid High Alarm',1,'2015-08-18 07:40:34.504','2015-07-17 22:12:00.000',20,'Digital','DHCX7: SupplyAir Humid High Alarm',0,'---'),(386,'DHCX7_WaterTempHighAlarm','DHCX7: WaterTempHigh Alarm',1,'2015-08-18 07:40:34.520','2015-07-17 22:12:00.000',20,'Digital','DHCX7: WaterTempHigh Alarm',0,'---'),(387,'DHCX7_ReturnAirTempLowAlarm','DHCX7: Return Air Temp Low Alarm',1,'2015-08-18 07:40:34.520','2015-07-17 22:12:00.000',20,'Digital','DHCX7: Return Air Temp Low Alarm',0,'---'),(388,'DHCX7_ReturnAirHumidLowAlarm','DHCX7: Return Air Humid Low Alarm',1,'2015-08-18 07:40:34.535','2015-07-17 22:12:00.000',20,'Digital','DHCX7: Return Air Humid Low Alarm',0,'---'),(389,'DHCX7_SupplyAirTempLowAlarm','DHCX7: SupplyAir Temp Low Alarm',1,'2015-08-18 07:40:34.551','2015-07-17 22:12:00.000',20,'Digital','DHCX7: SupplyAir Temp Low Alarm',0,'---'),(390,'DHCX7_SupplyAirHumidLowAlarm','DHCX7: SupplyAir Humid Low Alarm',1,'2015-08-18 07:40:34.567','2015-07-17 22:12:00.000',20,'Digital','DHCX7: SupplyAir Humid Low Alarm',0,'---'),(391,'DHCX7_WaterTempLowAlarm','DHCX7: Water Temp Low Alarm',1,'2015-08-18 07:40:34.582','2015-07-17 22:12:00.000',20,'Digital','DHCX7: Water Temp Low Alarm',0,'---'),(392,'DHCX7_FreezeAlarm','DHCX7: Freeze Alarm',1,'2015-08-18 07:40:34.582','2015-07-17 22:12:00.000',20,'Digital','DHCX7: Freeze Alarm',0,'---'),(393,'DHCX8_UnitRuntimeUnit','DHCX8: Unit Runtime Unit ',1,'2015-08-18 07:40:34.598','2015-07-17 22:12:00.000',21,'Analogue','DHCX8: Unit Runtime Unit ',0,'Hour'),(394,'DHCX8_UnitSetpointTemperatureDay','DHCX8: Unit Setpoint Temperature Day',1,'2015-08-18 07:40:34.613','2015-07-17 22:12:00.000',21,'Analogue','DHCX8: Unit Setpoint Temperature Day',0,'°C'),(395,'DHCX8_UnitSetpointTemperatureNight','DHCX8: Unit Setpoint Temperature Night',1,'2015-08-18 07:40:34.629','2015-07-17 22:12:00.000',21,'Analogue','DHCX8: Unit Setpoint Temperature Night',0,'°C'),(396,'DHCX8_UnitSetpointHumidity','DHCX8: Unit Setpoint Humidity',1,'2015-08-18 07:40:34.645','2015-07-17 22:12:00.000',21,'Analogue','DHCX8: Unit Setpoint Humidity',0,'%RH'),(397,'DHCX8_UnitReturnAirTemperature','DHCX8: Unit Return Air Temperature ',1,'2015-08-18 07:40:34.645','2015-07-17 22:12:00.000',21,'Analogue','DHCX8: Unit Return Air Temperature ',0,'°C'),(398,'DHCX8_UnitReturnAirHumidity','DHCX8: Unit Return Air Humidity',1,'2015-08-18 07:40:34.660','2015-07-17 22:12:00.000',21,'Analogue','DHCX8: Unit Return Air Humidity',0,'%RH'),(399,'DHCX8_CommonAlarm','DHCX8: Common Alarm',1,'2015-08-18 07:40:34.676','2015-07-17 22:12:00.000',21,'Digital','DHCX8: Common Alarm',0,'---'),(400,'DHCX8_UnitOnOff','DHCX8: Unit OnOff',1,'2015-08-18 07:40:34.691','2015-07-17 22:12:00.000',21,'Digital','DHCX8: Unit OnOff',0,'---'),(401,'DHCX8_UnitCooling','DHCX8: Unit Cooling',1,'2015-08-18 07:40:34.707','2015-07-17 22:12:00.000',21,'Digital','DHCX8: Unit Cooling',0,'---'),(402,'DHCX8_UnitHeating','DHCX8: Unit Heating',1,'2015-08-18 07:40:34.723','2015-07-17 22:12:00.000',21,'Digital','DHCX8: Unit Heating',0,'---'),(403,'DHCX8_UnitHumidification','DHCX8: Unit Humidification',1,'2015-08-18 07:40:34.738','2015-07-17 22:12:00.000',21,'Digital','DHCX8: Unit Humidification',0,'---'),(404,'DHCX8_UnitDehumidification','DHCX8: Unit Dehumidification',1,'2015-08-18 07:40:34.754','2015-07-17 22:12:00.000',21,'Digital','DHCX8: Unit Dehumidification',0,'---'),(405,'DHCX8_Airflow1','DHCX8: Air flow1',1,'2015-08-18 07:40:34.770','2015-07-17 22:12:00.000',21,'Analogue','DHCX8: Air flow1',0,'---'),(406,'DHCX8_Airflow2','DHCX8: Air flow2',1,'2015-08-18 07:40:34.785','2015-07-17 22:12:00.000',21,'Analogue','DHCX8: Air flow2',0,'---'),(407,'DHCX8_Airflow3','DHCX8: Air flow3',1,'2015-08-18 07:40:34.785','2015-07-17 22:12:00.000',21,'Analogue','DHCX8: Air flow3',0,'---'),(408,'DHCX8_HighPressure1','DHCX8: High Pressure1',1,'2015-08-18 07:40:34.801','2015-07-17 22:12:00.000',21,'Digital','DHCX8: High Pressure1',0,'---'),(409,'DHCX8_HighPressure2','DHCX8: High Pressure2',1,'2015-08-18 07:40:34.817','2015-07-17 22:12:00.000',21,'Digital','DHCX8: High Pressure2',0,'---'),(410,'DHCX8_HighPressure3','DHCX8: High Pressure3',1,'2015-08-18 07:40:34.832','2015-07-17 22:12:00.000',21,'Digital','DHCX8: High Pressure3',0,'---'),(411,'DHCX8_WaterDetector','DHCX8: WaterDetector',1,'2015-08-18 07:40:34.848','2015-07-17 22:12:00.000',21,'Digital','DHCX8: WaterDetector',0,'---'),(412,'DHCX8_PhaseCheck','DHCX8: PhaseCheck',1,'2015-08-18 07:40:34.863','2015-07-17 22:12:00.000',21,'Digital','DHCX8: PhaseCheck',0,'---'),(413,'DHCX8_FireSmoke','DHCX8: FireSmoke',1,'2015-08-18 07:40:34.879','2015-07-17 22:12:00.000',21,'Digital','DHCX8: FireSmoke',0,'---'),(414,'DHCX8_ReturnAirTempHighAlarm','DHCX8: Return Air Temp High Alarm',1,'2015-08-18 07:40:34.895','2015-07-17 22:12:00.000',21,'Digital','DHCX8: Return Air Temp High Alarm',0,'---'),(415,'DHCX8_ReturnAirHumidHighAlarm','DHCX8: Return Air Humid High Alarm',1,'2015-08-18 07:40:34.895','2015-07-17 22:12:00.000',21,'Digital','DHCX8: Return Air Humid High Alarm',0,'---'),(416,'DHCX8_SupplyAirTempHighAlarm','DHCX8: SupplyAir Temp High Alarm',1,'2015-08-18 07:40:34.910','2015-07-17 22:12:00.000',21,'Digital','DHCX8: SupplyAir Temp High Alarm',0,'---'),(417,'DHCX8_SupplyAirHumidHighAlarm','DHCX8: SupplyAir Humid High Alarm',1,'2015-08-18 07:40:34.926','2015-07-17 22:12:00.000',21,'Digital','DHCX8: SupplyAir Humid High Alarm',0,'---'),(418,'DHCX8_WaterTempHighAlarm','DHCX8: WaterTempHigh Alarm',1,'2015-08-18 07:40:34.942','2015-07-17 22:12:00.000',21,'Digital','DHCX8: WaterTempHigh Alarm',0,'---'),(419,'DHCX8_ReturnAirTempLowAlarm','DHCX8: Return Air Temp Low Alarm',1,'2015-08-18 07:40:34.957','2015-07-17 22:12:00.000',21,'Digital','DHCX8: Return Air Temp Low Alarm',0,'---'),(420,'DHCX8_ReturnAirHumidLowAlarm','DHCX8: Return Air Humid Low Alarm',1,'2015-08-18 07:40:34.957','2015-07-17 22:12:00.000',21,'Digital','DHCX8: Return Air Humid Low Alarm',0,'---'),(421,'DHCX8_SupplyAirTempLowAlarm','DHCX8: SupplyAir Temp Low Alarm',1,'2015-08-18 07:40:34.973','2015-07-17 22:12:00.000',21,'Digital','DHCX8: SupplyAir Temp Low Alarm',0,'---'),(422,'DHCX8_SupplyAirHumidLowAlarm','DHCX8: SupplyAir Humid Low Alarm',1,'2015-08-18 07:40:34.988','2015-07-17 22:12:00.000',21,'Digital','DHCX8: SupplyAir Humid Low Alarm',0,'---'),(423,'DHCX8_WaterTempLowAlarm','DHCX8: Water Temp Low Alarm',1,'2015-08-18 07:40:35.004','2015-07-17 22:12:00.000',21,'Digital','DHCX8: Water Temp Low Alarm',0,'---'),(424,'DHCX8_FreezeAlarm','DHCX8: Freeze Alarm',1,'2015-08-18 07:40:35.020','2015-07-17 22:12:00.000',21,'Digital','DHCX8: Freeze Alarm',0,'---'),(425,'REC1_systemStatus','REC1: system Status',1,'2015-08-18 07:40:35.020','2015-07-17 22:12:00.000',43,'Analogue','REC1: system Status',0,'---'),(426,'REC1_systemVoltage','REC1: system Voltage',1,'2015-08-18 07:40:35.035','2015-07-17 22:12:00.000',43,'Analogue','REC1: system Voltage',0,'V'),(427,'REC1_systemCurrent','REC1: system Current',1,'2015-08-18 07:40:35.051','2015-07-17 22:12:00.000',43,'Analogue','REC1: system Current',0,'A'),(428,'REC1_systemUsedCapacity','REC1: system Used Capacity',1,'2015-08-18 07:40:35.067','2015-07-17 22:12:00.000',43,'Analogue','REC1: system Used Capacity',0,'%'),(429,'REC1_psStatusCommunication','REC1: ps Status Communication',1,'2015-08-18 07:40:35.082','2015-07-17 22:12:00.000',43,'Analogue','REC1: ps Status Communication',0,'---'),(430,'REC1_psTemperature1','REC1: ps Temperature1',1,'2015-08-18 07:40:35.082','2015-07-17 22:12:00.000',43,'Analogue','REC1: ps Temperature1',0,'°C'),(431,'REC1_psBatteryVoltage','REC1: ps Battery Voltage',1,'2015-08-18 07:40:35.098','2015-07-17 22:12:00.000',43,'Analogue','REC1: ps Battery Voltage',0,'V'),(432,'REC1_psTotalBatteryCurrent','REC1: ps Total Battery Current',1,'2015-08-18 07:40:35.113','2015-07-17 22:12:00.000',43,'Analogue','REC1: ps Total Battery Current',0,'A'),(433,'REC1_psInputLineAVoltage','REC1: ps Input Line A Voltage',1,'2015-08-18 07:40:35.129','2015-07-17 22:12:00.000',43,'Analogue','REC1: ps Input Line A Voltage',0,'V'),(434,'REC1_psInputLineBVoltage','REC1: ps Input Line B Voltage',1,'2015-08-18 07:40:35.145','2015-07-17 22:12:00.000',43,'Analogue','REC1: ps Input Line B Voltage',0,'V'),(435,'REC1_psInputLineCVoltage','REC1: ps Input Line C Voltage',1,'2015-08-18 07:40:35.145','2015-07-17 22:12:00.000',43,'Analogue','REC1: ps Input Line C Voltage',0,'V'),(436,'REC1_psStatusBatteryMode','REC1: ps Status Battery Mode',1,'2015-08-18 07:40:35.160','2015-07-17 22:12:00.000',43,'Analogue','REC1: ps Status Battery Mode',0,'---'),(437,'REC2_systemStatus','REC2: system Status',1,'2015-08-18 07:40:35.176','2015-07-17 22:12:00.000',44,'Analogue','REC2: system Status',0,'---'),(438,'REC2_systemVoltage','REC2: system Voltage',1,'2015-08-18 07:40:35.192','2015-07-17 22:12:00.000',44,'Analogue','REC2: system Voltage',0,'V'),(439,'REC2_systemCurrent','REC2: system Current',1,'2015-08-18 07:40:35.207','2015-07-17 22:12:00.000',44,'Analogue','REC2: system Current',0,'A'),(440,'REC2_systemUsedCapacity','REC2: system Used Capacity',1,'2015-08-18 07:40:35.223','2015-07-17 22:12:00.000',44,'Analogue','REC2: system Used Capacity',0,'%'),(441,'REC2_psStatusCommunication','REC2: ps Status Communication',1,'2015-08-18 07:40:35.223','2015-07-17 22:12:00.000',44,'Analogue','REC2: ps Status Communication',0,'---'),(442,'REC2_psTemperature1','REC2: ps Temperature1',1,'2015-08-18 07:40:35.238','2015-07-17 22:12:00.000',44,'Analogue','REC2: ps Temperature1',0,'°C'),(443,'REC2_psBatteryVoltage','REC2: ps Battery Voltage',1,'2015-08-18 07:40:35.254','2015-07-17 22:12:00.000',44,'Analogue','REC2: ps Battery Voltage',0,'V'),(444,'REC2_psTotalBatteryCurrent','REC2: ps Total Battery Current',1,'2015-08-18 07:40:35.270','2015-07-17 22:12:00.000',44,'Analogue','REC2: ps Total Battery Current',0,'A'),(445,'REC2_psInputLineAVoltage','REC2: ps Input Line A Voltage',1,'2015-08-18 07:40:35.285','2015-07-17 22:12:00.000',44,'Analogue','REC2: ps Input Line A Voltage',0,'V'),(446,'REC2_psInputLineBVoltage','REC2: ps Input Line B Voltage',1,'2015-08-18 07:40:35.285','2015-07-17 22:12:00.000',44,'Analogue','REC2: ps Input Line B Voltage',0,'V'),(447,'REC2_psInputLineCVoltage','REC2: ps Input Line C Voltage',1,'2015-08-18 07:40:35.301','2015-07-17 22:12:00.000',44,'Analogue','REC2: ps Input Line C Voltage',0,'V'),(448,'REC2_psStatusBatteryMode','REC2: ps Status Battery Mode',1,'2015-08-18 07:40:35.317','2015-07-17 22:12:00.000',44,'Analogue','REC2: ps Status Battery Mode',0,'---'),(449,'REC3_systemStatus','REC3: system Status',1,'2015-08-18 07:40:35.332','2015-07-17 22:12:00.000',45,'Analogue','REC3: system Status',0,'---'),(450,'REC3_systemVoltage','REC3: system Voltage',1,'2015-08-18 07:40:35.348','2015-07-17 22:12:00.000',45,'Analogue','REC3: system Voltage',0,'V'),(451,'REC3_systemCurrent','REC3: system Current',1,'2015-08-18 07:40:35.348','2015-07-17 22:12:00.000',45,'Analogue','REC3: system Current',0,'A'),(452,'REC3_systemUsedCapacity','REC3: system Used Capacity',1,'2015-08-18 07:40:35.363','2015-07-17 22:12:00.000',45,'Analogue','REC3: system Used Capacity',0,'%'),(453,'REC3_psStatusCommunication','REC3: ps Status Communication',1,'2015-08-18 07:40:35.379','2015-07-17 22:12:00.000',45,'Analogue','REC3: ps Status Communication',0,'---'),(454,'REC3_psTemperature1','REC3: ps Temperature1',1,'2015-08-18 07:40:35.395','2015-07-17 22:12:00.000',45,'Analogue','REC3: ps Temperature1',0,'°C'),(455,'REC3_psBatteryVoltage','REC3: ps Battery Voltage',1,'2015-08-18 07:40:35.410','2015-07-17 22:12:00.000',45,'Analogue','REC3: ps Battery Voltage',0,'V'),(456,'REC3_psTotalBatteryCurrent','REC3: ps Total Battery Current',1,'2015-08-18 07:40:35.410','2015-07-17 22:12:00.000',45,'Analogue','REC3: ps Total Battery Current',0,'A'),(457,'REC3_psInputLineAVoltage','REC3: ps Input Line A Voltage',1,'2015-08-18 07:40:35.426','2015-07-17 22:12:00.000',45,'Analogue','REC3: ps Input Line A Voltage',0,'V'),(458,'REC3_psInputLineBVoltage','REC3: ps Input Line B Voltage',1,'2015-08-18 07:40:35.442','2015-07-17 22:12:00.000',45,'Analogue','REC3: ps Input Line B Voltage',0,'V'),(459,'REC3_psInputLineCVoltage','REC3: ps Input Line C Voltage',1,'2015-08-18 07:40:35.457','2015-07-17 22:12:00.000',45,'Analogue','REC3: ps Input Line C Voltage',0,'V'),(460,'REC3_psStatusBatteryMode','REC3: ps Status Battery Mode',1,'2015-08-18 07:40:35.473','2015-07-17 22:12:00.000',45,'Analogue','REC3: ps Status Battery Mode',0,'---'),(461,'REC4_systemStatus','REC4: system Status',1,'2015-08-18 07:40:35.473','2015-07-17 22:12:00.000',46,'Analogue','REC4: system Status',0,'---'),(462,'REC4_systemVoltage','REC4: system Voltage',1,'2015-08-18 07:40:35.488','2015-07-17 22:12:00.000',46,'Analogue','REC4: system Voltage',0,'V'),(463,'REC4_systemCurrent','REC4: system Current',1,'2015-08-18 07:40:35.504','2015-07-17 22:12:00.000',46,'Analogue','REC4: system Current',0,'A'),(464,'REC4_systemUsedCapacity','REC4: system Used Capacity',1,'2015-08-18 07:40:35.520','2015-07-17 22:12:00.000',46,'Analogue','REC4: system Used Capacity',0,'%'),(465,'REC4_psStatusCommunication','REC4: ps Status Communication',1,'2015-08-18 07:40:35.535','2015-07-17 22:12:00.000',46,'Analogue','REC4: ps Status Communication',0,'---'),(466,'REC4_psTemperature1','REC4: ps Temperature1',1,'2015-08-18 07:40:35.535','2015-07-17 22:12:00.000',46,'Analogue','REC4: ps Temperature1',0,'°C'),(467,'REC4_psBatteryVoltage','REC4: ps Battery Voltage',1,'2015-08-18 07:40:35.551','2015-07-17 22:12:00.000',46,'Analogue','REC4: ps Battery Voltage',0,'V'),(468,'REC4_psTotalBatteryCurrent','REC4: ps Total Battery Current',1,'2015-08-18 07:40:35.567','2015-07-17 22:12:00.000',46,'Analogue','REC4: ps Total Battery Current',0,'A'),(469,'REC4_psInputLineAVoltage','REC4: ps Input Line A Voltage',1,'2015-08-18 07:40:35.582','2015-07-17 22:12:00.000',46,'Analogue','REC4: ps Input Line A Voltage',0,'V'),(470,'REC4_psInputLineBVoltage','REC4: ps Input Line B Voltage',1,'2015-08-18 07:40:35.598','2015-07-17 22:12:00.000',46,'Analogue','REC4: ps Input Line B Voltage',0,'V'),(471,'REC4_psInputLineCVoltage','REC4: ps Input Line C Voltage',1,'2015-08-18 07:40:35.613','2015-07-17 22:12:00.000',46,'Analogue','REC4: ps Input Line C Voltage',0,'V'),(472,'REC4_psStatusBatteryMode','REC4: ps Status Battery Mode',1,'2015-08-18 07:40:35.613','2015-07-17 22:12:00.000',46,'Analogue','REC4: ps Status Battery Mode',0,'---'),(473,'REC5_systemStatus','REC5: system Status',1,'2015-08-18 07:40:35.629','2015-07-17 22:12:00.000',47,'Analogue','REC5: system Status',0,'---'),(474,'REC5_systemVoltage','REC5: system Voltage',1,'2015-08-18 07:40:35.645','2015-07-17 22:12:00.000',47,'Analogue','REC5: system Voltage',0,'V'),(475,'REC5_systemCurrent','REC5: system Current',1,'2015-08-18 07:40:35.660','2015-07-17 22:12:00.000',47,'Analogue','REC5: system Current',0,'A'),(476,'REC5_systemUsedCapacity','REC5: system Used Capacity',1,'2015-08-18 07:40:35.676','2015-07-17 22:12:00.000',47,'Analogue','REC5: system Used Capacity',0,'%'),(477,'REC5_psStatusCommunication','REC5: ps Status Communication',1,'2015-08-18 07:40:35.692','2015-07-17 22:12:00.000',47,'Analogue','REC5: ps Status Communication',0,'---'),(478,'REC5_psTemperature1','REC5: ps Temperature1',1,'2015-08-18 07:40:35.692','2015-07-17 22:12:00.000',47,'Analogue','REC5: ps Temperature1',0,'°C'),(479,'REC5_psBatteryVoltage','REC5: ps Battery Voltage',1,'2015-08-18 07:40:35.707','2015-07-17 22:12:00.000',47,'Analogue','REC5: ps Battery Voltage',0,'V'),(480,'REC5_psTotalBatteryCurrent','REC5: ps Total Battery Current',1,'2015-08-18 07:40:35.723','2015-07-17 22:12:00.000',47,'Analogue','REC5: ps Total Battery Current',0,'A'),(481,'REC5_psInputLineAVoltage','REC5: ps Input Line A Voltage',1,'2015-08-18 07:40:35.738','2015-07-17 22:12:00.000',47,'Analogue','REC5: ps Input Line A Voltage',0,'V'),(482,'REC5_psInputLineBVoltage','REC5: ps Input Line B Voltage',1,'2015-08-18 07:40:35.754','2015-07-17 22:12:00.000',47,'Analogue','REC5: ps Input Line B Voltage',0,'V'),(483,'REC5_psInputLineCVoltage','REC5: ps Input Line C Voltage',1,'2015-08-18 07:40:35.754','2015-07-17 22:12:00.000',47,'Analogue','REC5: ps Input Line C Voltage',0,'V'),(484,'REC5_psStatusBatteryMode','REC5: ps Status Battery Mode',1,'2015-08-18 07:40:35.770','2015-07-17 22:12:00.000',47,'Analogue','REC5: ps Status Battery Mode',0,'---'),(485,'REC6_systemStatus','REC6: system Status',1,'2015-08-18 07:40:35.785','2015-07-17 22:12:00.000',48,'Analogue','REC6: system Status',0,'---'),(486,'REC6_systemVoltage','REC6: system Voltage',1,'2015-08-18 07:40:35.801','2015-07-17 22:12:00.000',48,'Analogue','REC6: system Voltage',0,'V'),(487,'REC6_systemCurrent','REC6: system Current',1,'2015-08-18 07:40:35.817','2015-07-17 22:12:00.000',48,'Analogue','REC6: system Current',0,'A'),(488,'REC6_systemUsedCapacity','REC6: system Used Capacity',1,'2015-08-18 07:40:35.817','2015-07-17 22:12:00.000',48,'Analogue','REC6: system Used Capacity',0,'%'),(489,'REC6_psStatusCommunication','REC6: ps Status Communication',1,'2015-08-18 07:40:35.832','2015-07-17 22:12:00.000',48,'Analogue','REC6: ps Status Communication',0,'---'),(490,'REC6_psTemperature1','REC6: ps Temperature1',1,'2015-08-18 07:40:35.848','2015-07-17 22:12:00.000',48,'Analogue','REC6: ps Temperature1',0,'°C'),(491,'REC6_psBatteryVoltage','REC6: ps Battery Voltage',1,'2015-08-18 07:40:35.863','2015-07-17 22:12:00.000',48,'Analogue','REC6: ps Battery Voltage',0,'V'),(492,'REC6_psTotalBatteryCurrent','REC6: ps Total Battery Current',1,'2015-08-18 07:40:35.879','2015-07-17 22:12:00.000',48,'Analogue','REC6: ps Total Battery Current',0,'A'),(493,'REC6_psInputLineAVoltage','REC6: ps Input Line A Voltage',1,'2015-08-18 07:40:35.895','2015-07-17 22:12:00.000',48,'Analogue','REC6: ps Input Line A Voltage',0,'V'),(494,'REC6_psInputLineBVoltage','REC6: ps Input Line B Voltage',1,'2015-08-18 07:40:35.895','2015-07-17 22:12:00.000',48,'Analogue','REC6: ps Input Line B Voltage',0,'V'),(495,'REC6_psInputLineCVoltage','REC6: ps Input Line C Voltage',1,'2015-08-18 07:40:35.910','2015-07-17 22:12:00.000',48,'Analogue','REC6: ps Input Line C Voltage',0,'V'),(496,'REC6_psStatusBatteryMode','REC6: ps Status Battery Mode',1,'2015-08-18 07:40:35.926','2015-07-17 22:12:00.000',48,'Analogue','REC6: ps Status Battery Mode',0,'---'),(497,'GENSET1_V12','GENSET1: Voltage L12',1,'2015-08-18 07:40:35.942','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: Voltage L12',0,'V'),(498,'GENSET1_V23','GENSET1: Voltage L23',1,'2015-08-18 07:40:35.957','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: Voltage L23',0,'V'),(499,'GENSET1_V31','GENSET1: Voltage L31',1,'2015-08-18 07:40:35.957','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: Voltage L31',0,'V'),(500,'GENSET1_V1','GENSET1: Voltage L1',1,'2015-08-18 07:40:35.973','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: Voltage L1',0,'V'),(501,'GENSET1_V2','GENSET1: Voltage L2',1,'2015-08-18 07:40:35.988','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: Voltage L2',0,'V'),(502,'GENSET1_V3','GENSET1: Voltage L3',1,'2015-08-18 07:40:36.004','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: Voltage L3',0,'V'),(503,'GENSET1_F1','GENSET1: Frequency L1',1,'2015-08-18 07:40:36.020','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: Frequency L1',0,'Hz'),(504,'GENSET1_F2','GENSET1: Frequency L2',1,'2015-08-18 07:40:36.020','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: Frequency L2',0,'Hz'),(505,'GENSET1_F3','GENSET1: Frequency L3',1,'2015-08-18 07:40:36.035','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: Frequency L3',0,'Hz'),(506,'GENSET1_I1','GENSET1: Current L1',1,'2015-08-18 07:40:36.051','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: Current L1',0,'A'),(507,'GENSET1_I2','GENSET1: Current L2',1,'2015-08-18 07:40:36.067','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: Current L2',0,'A'),(508,'GENSET1_I3','GENSET1: Current L3',1,'2015-08-18 07:40:36.082','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: Current L3',0,'A'),(509,'GENSET1_kW1','GENSET1: Power L1',1,'2015-08-18 07:40:36.098','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: Power L1',0,'kW'),(510,'GENSET1_kW2','GENSET1: Power L2',1,'2015-08-18 07:40:36.098','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: Power L2',0,'kW'),(511,'GENSET1_kW3','GENSET1: Power L3',1,'2015-08-18 07:40:36.113','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: Power L3',0,'kW'),(512,'GENSET1_kW','GENSET1: Power ',1,'2015-08-18 07:40:36.129','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: Power ',0,'kW'),(513,'GENSET1_kVA1','GENSET1: apparent power L1',1,'2015-08-18 07:40:36.145','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: apparent power L1',0,'kVA'),(514,'GENSET1_kVA2','GENSET1: apparent power L2',1,'2015-08-18 07:40:36.160','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: apparent power L2',0,'kVA'),(515,'GENSET1_kVA3','GENSET1: apparent power L3',1,'2015-08-18 07:40:36.160','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: apparent power L3',0,'kVA'),(516,'GENSET1_kVA','GENSET1: apparent power ',1,'2015-08-18 07:40:36.176','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: apparent power ',0,'kVA'),(517,'GENSET1_kWh','GENSET1: Energy',1,'2015-08-18 07:40:36.192','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: Energy',0,'kWh'),(518,'GENSET1_pf','GENSET1: Power factor',1,'2015-08-18 07:40:36.207','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: Power factor',0,'---'),(519,'GENSET1_Hour','GENSET1: Hour',1,'2015-08-18 07:40:36.223','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: Hour',0,'Hour'),(520,'GENSET1_Alarms','GENSET1: Alarms',1,'2015-08-18 07:40:36.238','2015-07-17 22:12:00.000',22,'Analogue','GENSET1: Alarms',0,'---'),(521,'GENSET2_V12','GENSET2: Voltage L12',1,'2015-08-18 07:40:36.254','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: Voltage L12',0,'V'),(522,'GENSET2_V23','GENSET2: Voltage L23',1,'2015-08-18 07:40:36.270','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: Voltage L23',0,'V'),(523,'GENSET2_V31','GENSET2: Voltage L31',1,'2015-08-18 07:40:36.285','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: Voltage L31',0,'V'),(524,'GENSET2_V1','GENSET2: Voltage L1',1,'2015-08-18 07:40:36.301','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: Voltage L1',0,'V'),(525,'GENSET2_V2','GENSET2: Voltage L2',1,'2015-08-18 07:40:36.301','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: Voltage L2',0,'V'),(526,'GENSET2_V3','GENSET2: Voltage L3',1,'2015-08-18 07:40:36.317','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: Voltage L3',0,'V'),(527,'GENSET2_F1','GENSET2: Frequency L1',1,'2015-08-18 07:40:36.332','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: Frequency L1',0,'Hz'),(528,'GENSET2_F2','GENSET2: Frequency L2',1,'2015-08-18 07:40:36.348','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: Frequency L2',0,'Hz'),(529,'GENSET2_F3','GENSET2: Frequency L3',1,'2015-08-18 07:40:36.363','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: Frequency L3',0,'Hz'),(530,'GENSET2_I1','GENSET2: Current L1',1,'2015-08-18 07:40:36.363','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: Current L1',0,'A'),(531,'GENSET2_I2','GENSET2: Current L2',1,'2015-08-18 07:40:36.379','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: Current L2',0,'A'),(532,'GENSET2_I3','GENSET2: Current L3',1,'2015-08-18 07:40:36.395','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: Current L3',0,'A'),(533,'GENSET2_kW1','GENSET2: Power L1',1,'2015-08-18 07:40:36.410','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: Power L1',0,'kW'),(534,'GENSET2_kW2','GENSET2: Power L2',1,'2015-08-18 07:40:36.426','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: Power L2',0,'kW'),(535,'GENSET2_kW3','GENSET2: Power L3',1,'2015-08-18 07:40:36.442','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: Power L3',0,'kW'),(536,'GENSET2_kW','GENSET2: Power ',1,'2015-08-18 07:40:36.442','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: Power ',0,'kW'),(537,'GENSET2_kVA1','GENSET2: apparent power L1',1,'2015-08-18 07:40:36.457','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: apparent power L1',0,'kVA'),(538,'GENSET2_kVA2','GENSET2: apparent power L2',1,'2015-08-18 07:40:36.473','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: apparent power L2',0,'kVA'),(539,'GENSET2_kVA3','GENSET2: apparent power L3',1,'2015-08-18 07:40:36.488','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: apparent power L3',0,'kVA'),(540,'GENSET2_kVA','GENSET2: apparent power ',1,'2015-08-18 07:40:36.504','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: apparent power ',0,'kVA'),(541,'GENSET2_kWh','GENSET2: Energy',1,'2015-08-18 07:40:36.504','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: Energy',0,'kWh'),(542,'GENSET2_pf','GENSET2: Power factor',1,'2015-08-18 07:40:36.520','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: Power factor',0,'---'),(543,'GENSET2_Hour','GENSET2: Hour',1,'2015-08-18 07:40:36.535','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: Hour',0,'Hour'),(544,'GENSET2_Alarms','GENSET2: Alarms',1,'2015-08-18 07:40:36.551','2015-07-17 22:12:00.000',23,'Analogue','GENSET2: Alarms',0,'---'),(545,'PM2_1_I1','PM870: Current L1',1,'2015-08-18 07:40:36.567','2015-07-17 22:12:00.000',28,'Analogue','PM870: Current L1',0,'A'),(546,'PM2_1_I2','PM870: Current L2',1,'2015-08-18 07:40:36.567','2015-07-17 22:12:00.000',28,'Analogue','PM870: Current L2',0,'A'),(547,'PM2_1_I3','PM870: Current L3',1,'2015-08-18 07:40:36.582','2015-07-17 22:12:00.000',28,'Analogue','PM870: Current L3',0,'A'),(548,'PM2_1_In','PM870: Current',1,'2015-08-18 07:40:36.598','2015-07-17 22:12:00.000',28,'Analogue','PM870: Current',0,'A'),(549,'PM2_1_V12','PM870: Voltage L12',1,'2015-08-18 07:40:36.613','2015-07-17 22:12:00.000',28,'Analogue','PM870: Voltage L12',0,'V'),(550,'PM2_1_V23','PM870: Voltage L23',1,'2015-08-18 07:40:36.629','2015-07-17 22:12:00.000',28,'Analogue','PM870: Voltage L23',0,'V'),(551,'PM2_1_V31','PM870: Voltage L31',1,'2015-08-18 07:40:36.629','2015-07-17 22:12:00.000',28,'Analogue','PM870: Voltage L31',0,'V'),(552,'PM2_1_V1','PM870: Voltage L1',1,'2015-08-18 07:40:36.645','2015-07-17 22:12:00.000',28,'Analogue','PM870: Voltage L1',0,'V'),(553,'PM2_1_V2','PM870: Voltage L2',1,'2015-08-18 07:40:36.660','2015-07-17 22:12:00.000',28,'Analogue','PM870: Voltage L2',0,'V'),(554,'PM2_1_V3','PM870: Voltage L3',1,'2015-08-18 07:40:36.676','2015-07-17 22:12:00.000',28,'Analogue','PM870: Voltage L3',0,'V'),(555,'PM2_1_kW1','PM870: Power L1',1,'2015-08-18 07:40:36.692','2015-07-17 22:12:00.000',28,'Analogue','PM870: Power L1',0,'kW'),(556,'PM2_1_kW2','PM870: Power L2',1,'2015-08-18 07:40:36.707','2015-07-17 22:12:00.000',28,'Analogue','PM870: Power L2',0,'kW'),(557,'PM2_1_kW3','PM870: Power L3',1,'2015-08-18 07:40:36.707','2015-07-17 22:12:00.000',28,'Analogue','PM870: Power L3',0,'kW'),(558,'PM2_1_kW','PM870: Power ',1,'2015-08-18 07:40:36.723','2015-07-17 22:12:00.000',28,'Analogue','PM870: Power ',0,'kW'),(559,'PM2_1_kVA1','PM870: apparent power L1',1,'2015-08-18 07:40:36.738','2015-07-17 22:12:00.000',28,'Analogue','PM870: apparent power L1',0,'kVA'),(560,'PM2_1_kVA2','PM870: apparent power L2',1,'2015-08-18 07:40:36.754','2015-07-17 22:12:00.000',28,'Analogue','PM870: apparent power L2',0,'kVA'),(561,'PM2_1_kVA3','PM870: apparent power L3',1,'2015-08-18 07:40:36.770','2015-07-17 22:12:00.000',28,'Analogue','PM870: apparent power L3',0,'kVA'),(562,'PM2_1_kVA','PM870: apparent power ',1,'2015-08-18 07:40:36.770','2015-07-17 22:12:00.000',28,'Analogue','PM870: apparent power ',0,'kVA'),(563,'PM2_1_pf','PM870: Power factor',1,'2015-08-18 07:40:36.785','2015-07-17 22:12:00.000',28,'Analogue','PM870: Power factor',0,'---'),(564,'PM2_1_F','PM870: Frequency',1,'2015-08-18 07:40:36.801','2015-07-17 22:12:00.000',28,'Analogue','PM870: Frequency',0,'Hz'),(565,'PM2_1_THD_I1','PM870: THD Current L1',1,'2015-08-18 07:40:36.817','2015-07-17 22:12:00.000',28,'Analogue','PM870: THD Current L1',0,'%'),(566,'PM2_1_THD_I2','PM870: THD Current L2',1,'2015-08-18 07:40:36.832','2015-07-17 22:12:00.000',28,'Analogue','PM870: THD Current L2',0,'%'),(567,'PM2_1_THD_I3','PM870: THD Current L3',1,'2015-08-18 07:40:36.832','2015-07-17 22:12:00.000',28,'Analogue','PM870: THD Current L3',0,'%'),(568,'PM2_1_THD_V1','PM870: THD Voltage L1',1,'2015-08-18 07:40:36.848','2015-07-17 22:12:00.000',28,'Analogue','PM870: THD Voltage L1',0,'%'),(569,'PM2_1_THD_V2','PM870: THD Voltage L2',1,'2015-08-18 07:40:36.863','2015-07-17 22:12:00.000',28,'Analogue','PM870: THD Voltage L2',0,'%'),(570,'PM2_1_THD_V3','PM870: THD Voltage L3',1,'2015-08-18 07:40:36.879','2015-07-17 22:12:00.000',28,'Analogue','PM870: THD Voltage L3',0,'%'),(571,'PM2_1_THD_V12','PM870: THD Voltage L12',1,'2015-08-18 07:40:36.879','2015-07-17 22:12:00.000',28,'Analogue','PM870: THD Voltage L12',0,'%'),(572,'PM2_1_THD_V23','PM870: THD Voltage L23',1,'2015-08-18 07:40:36.895','2015-07-17 22:12:00.000',28,'Analogue','PM870: THD Voltage L23',0,'%'),(573,'PM2_1_THD_V31','PM870: THD Voltage L31',1,'2015-08-18 07:40:36.910','2015-07-17 22:12:00.000',28,'Analogue','PM870: THD Voltage L31',0,'%'),(574,'PM1_12_kWh','PM710: Energy',1,'2015-08-18 07:40:36.926','2015-07-17 22:12:00.000',28,'Analogue','PM710: Energy',0,'kWh'),(575,'PM1_12_pf','PM710: Power factor',1,'2015-08-18 07:40:36.942','2015-07-17 22:12:00.000',28,'Analogue','PM710: Power factor',0,'---'),(576,'PM1_12_kW','PM710: Power',1,'2015-08-18 07:40:36.942','2015-07-17 22:12:00.000',28,'Analogue','PM710: Power',0,'kW'),(577,'PM1_12_kVA','PM710: apparent power',1,'2015-08-18 07:40:36.957','2015-07-17 22:12:00.000',28,'Analogue','PM710: apparent power',0,'kVA'),(578,'PM1_12_F','PM710: Frequency',1,'2015-08-18 07:40:36.973','2015-07-17 22:12:00.000',28,'Analogue','PM710: Frequency',0,'Hz'),(579,'PM1_12_I1','PM710: Current L1',1,'2015-08-18 07:40:36.988','2015-07-17 22:12:00.000',28,'Analogue','PM710: Current L1',0,'A'),(580,'PM1_12_I2','PM710: Current L2',1,'2015-08-18 07:40:36.988','2015-07-17 22:12:00.000',28,'Analogue','PM710: Current L2',0,'A'),(581,'PM1_12_I3','PM710: Current L3',1,'2015-08-18 07:40:37.004','2015-07-17 22:12:00.000',28,'Analogue','PM710: Current L3',0,'A'),(582,'PM1_12_In','PM710: Current',1,'2015-08-18 07:40:37.020','2015-07-17 22:12:00.000',28,'Analogue','PM710: Current',0,'A'),(583,'PM1_12_V12','PM710: Voltage L12',1,'2015-08-18 07:40:37.035','2015-07-17 22:12:00.000',28,'Analogue','PM710: Voltage L12',0,'V'),(584,'PM1_12_V23','PM710: Voltage L23',1,'2015-08-18 07:40:37.051','2015-07-17 22:12:00.000',28,'Analogue','PM710: Voltage L23',0,'V'),(585,'PM1_12_V31','PM710: Voltage L31',1,'2015-08-18 07:40:37.051','2015-07-17 22:12:00.000',28,'Analogue','PM710: Voltage L31',0,'V'),(586,'PM1_12_V1','PM710: Voltage L1',1,'2015-08-18 07:40:37.067','2015-07-17 22:12:00.000',28,'Analogue','PM710: Voltage L1',0,'V'),(587,'PM1_12_V2','PM710: Voltage L2',1,'2015-08-18 07:40:37.082','2015-07-17 22:12:00.000',28,'Analogue','PM710: Voltage L2',0,'V'),(588,'PM1_12_V3','PM710: Voltage L3',1,'2015-08-18 07:40:37.098','2015-07-17 22:12:00.000',28,'Analogue','PM710: Voltage L3',0,'V'),(589,'PM1_12_kW1','PM710: Power L1',1,'2015-08-18 07:40:37.113','2015-07-17 22:12:00.000',28,'Analogue','PM710: Power L1',0,'kW'),(590,'PM1_12_kW2','PM710: Power L2',1,'2015-08-18 07:40:37.129','2015-07-17 22:12:00.000',28,'Analogue','PM710: Power L2',0,'kW'),(591,'PM1_12_kW3','PM710: Power L3',1,'2015-08-18 07:40:37.145','2015-07-17 22:12:00.000',28,'Analogue','PM710: Power L3',0,'kW'),(592,'PM1_12_kVA1','PM710: apparent power L1',1,'2015-08-18 07:40:37.160','2015-07-17 22:12:00.000',28,'Analogue','PM710: apparent power L1',0,'kVA'),(593,'PM1_12_kVA2','PM710: apparent power L2',1,'2015-08-18 07:40:37.176','2015-07-17 22:12:00.000',28,'Analogue','PM710: apparent power L2',0,'kVA'),(594,'PM1_12_kVA3','PM710: apparent power L3',1,'2015-08-18 07:40:37.176','2015-07-17 22:12:00.000',28,'Analogue','PM710: apparent power L3',0,'kVA'),(595,'PM1_12_THD_I1','PM710: THD Current L1',1,'2015-08-18 07:40:37.192','2015-07-17 22:12:00.000',28,'Analogue','PM710: THD Current L1',0,'%'),(596,'PM1_12_THD_I2','PM710: THD Current L2',1,'2015-08-18 07:40:37.207','2015-07-17 22:12:00.000',28,'Analogue','PM710: THD Current L2',0,'%'),(597,'PM1_12_THD_I3','PM710: THD Current L3',1,'2015-08-18 07:40:37.223','2015-07-17 22:12:00.000',28,'Analogue','PM710: THD Current L3',0,'%'),(598,'PM1_12_THD_V1','PM710: THD Voltage L1',1,'2015-08-18 07:40:37.238','2015-07-17 22:12:00.000',28,'Analogue','PM710: THD Voltage L1',0,'%'),(599,'PM1_12_THD_V2','PM710: THD Voltage L2',1,'2015-08-18 07:40:37.238','2015-07-17 22:12:00.000',28,'Analogue','PM710: THD Voltage L2',0,'%'),(600,'PM1_12_THD_V3','PM710: THD Voltage L3',1,'2015-08-18 07:40:37.254','2015-07-17 22:12:00.000',28,'Analogue','PM710: THD Voltage L3',0,'%'),(601,'PM1_12_THD_V12','PM710: THD Voltage L12',1,'2015-08-18 07:40:37.270','2015-07-17 22:12:00.000',28,'Analogue','PM710: THD Voltage L12',0,'%'),(602,'PM1_12_THD_V23','PM710: THD Voltage L23',1,'2015-08-18 07:40:37.285','2015-07-17 22:12:00.000',28,'Analogue','PM710: THD Voltage L23',0,'%'),(603,'PM1_12_THD_V31','PM710: THD Voltage L31',1,'2015-08-18 07:40:37.301','2015-07-17 22:12:00.000',28,'Analogue','PM710: THD Voltage L31',0,'%'),(604,'PM1_12_Hour','PM710: Hour',1,'2015-08-18 07:40:37.301','2015-07-17 22:12:00.000',28,'Analogue','PM710: Hour',0,'Hour'),(605,'PM1_12_Min','PM710: Min',1,'2015-08-18 07:40:37.317','2015-07-17 22:12:00.000',28,'Analogue','PM710: Min',0,'Min'),(606,'PM2_2_I1','PM870: Current L1',1,'2015-08-18 07:40:37.332','2015-07-17 22:12:00.000',29,'Analogue','PM870: Current L1',0,'A'),(607,'PM2_2_I2','PM870: Current L2',1,'2015-08-18 07:40:37.348','2015-07-17 22:12:00.000',29,'Analogue','PM870: Current L2',0,'A'),(608,'PM2_2_I3','PM870: Current L3',1,'2015-08-18 07:40:37.363','2015-07-17 22:12:00.000',29,'Analogue','PM870: Current L3',0,'A'),(609,'PM2_2_In','PM870: Current',1,'2015-08-18 07:40:37.363','2015-07-17 22:12:00.000',29,'Analogue','PM870: Current',0,'A'),(610,'PM2_2_V12','PM870: Voltage L12',1,'2015-08-18 07:40:37.379','2015-07-17 22:12:00.000',29,'Analogue','PM870: Voltage L12',0,'V'),(611,'PM2_2_V23','PM870: Voltage L23',1,'2015-08-18 07:40:37.395','2015-07-17 22:12:00.000',29,'Analogue','PM870: Voltage L23',0,'V'),(612,'PM2_2_V31','PM870: Voltage L31',1,'2015-08-18 07:40:37.410','2015-07-17 22:12:00.000',29,'Analogue','PM870: Voltage L31',0,'V'),(613,'PM2_2_V1','PM870: Voltage L1',1,'2015-08-18 07:40:37.426','2015-07-17 22:12:00.000',29,'Analogue','PM870: Voltage L1',0,'V'),(614,'PM2_2_V2','PM870: Voltage L2',1,'2015-08-18 07:40:37.426','2015-07-17 22:12:00.000',29,'Analogue','PM870: Voltage L2',0,'V'),(615,'PM2_2_V3','PM870: Voltage L3',1,'2015-08-18 07:40:37.442','2015-07-17 22:12:00.000',29,'Analogue','PM870: Voltage L3',0,'V'),(616,'PM2_2_kW1','PM870: Power L1',1,'2015-08-18 07:40:37.457','2015-07-17 22:12:00.000',29,'Analogue','PM870: Power L1',0,'kW'),(617,'PM2_2_kW2','PM870: Power L2',1,'2015-08-18 07:40:37.473','2015-07-17 22:12:00.000',29,'Analogue','PM870: Power L2',0,'kW'),(618,'PM2_2_kW3','PM870: Power L3',1,'2015-08-18 07:40:37.488','2015-07-17 22:12:00.000',29,'Analogue','PM870: Power L3',0,'kW'),(619,'PM2_2_kW','PM870: Power ',1,'2015-08-18 07:40:37.488','2015-07-17 22:12:00.000',29,'Analogue','PM870: Power ',0,'kW'),(620,'PM2_2_kVA1','PM870: apparent power L1',1,'2015-08-18 07:40:37.504','2015-07-17 22:12:00.000',29,'Analogue','PM870: apparent power L1',0,'kVA'),(621,'PM2_2_kVA2','PM870: apparent power L2',1,'2015-08-18 07:40:37.520','2015-07-17 22:12:00.000',29,'Analogue','PM870: apparent power L2',0,'kVA'),(622,'PM2_2_kVA3','PM870: apparent power L3',1,'2015-08-18 07:40:37.535','2015-07-17 22:12:00.000',29,'Analogue','PM870: apparent power L3',0,'kVA'),(623,'PM2_2_kVA','PM870: apparent power ',1,'2015-08-18 07:40:37.551','2015-07-17 22:12:00.000',29,'Analogue','PM870: apparent power ',0,'kVA'),(624,'PM2_2_pf','PM870: Power factor',1,'2015-08-18 07:40:37.582','2015-07-17 22:12:00.000',29,'Analogue','PM870: Power factor',0,'---'),(625,'PM2_2_F','PM870: Frequency',1,'2015-08-18 07:40:37.598','2015-07-17 22:12:00.000',29,'Analogue','PM870: Frequency',0,'Hz'),(626,'PM2_2_THD_I1','PM870: THD Current L1',1,'2015-08-18 07:40:37.598','2015-07-17 22:12:00.000',29,'Analogue','PM870: THD Current L1',0,'%'),(627,'PM2_2_THD_I2','PM870: THD Current L2',1,'2015-08-18 07:40:37.613','2015-07-17 22:12:00.000',29,'Analogue','PM870: THD Current L2',0,'%'),(628,'PM2_2_THD_I3','PM870: THD Current L3',1,'2015-08-18 07:40:37.629','2015-07-17 22:12:00.000',29,'Analogue','PM870: THD Current L3',0,'%'),(629,'PM2_2_THD_V1','PM870: THD Voltage L1',1,'2015-08-18 07:40:37.645','2015-07-17 22:12:00.000',29,'Analogue','PM870: THD Voltage L1',0,'%'),(630,'PM2_2_THD_V2','PM870: THD Voltage L2',1,'2015-08-18 07:40:37.660','2015-07-17 22:12:00.000',29,'Analogue','PM870: THD Voltage L2',0,'%'),(631,'PM2_2_THD_V3','PM870: THD Voltage L3',1,'2015-08-18 07:40:37.660','2015-07-17 22:12:00.000',29,'Analogue','PM870: THD Voltage L3',0,'%'),(632,'PM2_2_THD_V12','PM870: THD Voltage L12',1,'2015-08-18 07:40:37.676','2015-07-17 22:12:00.000',29,'Analogue','PM870: THD Voltage L12',0,'%'),(633,'PM2_2_THD_V23','PM870: THD Voltage L23',1,'2015-08-18 07:40:37.692','2015-07-17 22:12:00.000',29,'Analogue','PM870: THD Voltage L23',0,'%'),(634,'PM2_2_THD_V31','PM870: THD Voltage L31',1,'2015-08-18 07:40:37.707','2015-07-17 22:12:00.000',29,'Analogue','PM870: THD Voltage L31',0,'%'),(635,'PM1_13_kWh','PM710: Energy',1,'2015-08-18 07:40:37.723','2015-07-17 22:12:00.000',29,'Analogue','PM710: Energy',0,'kWh'),(636,'PM1_13_pf','PM710: Power factor',1,'2015-08-18 07:40:37.723','2015-07-17 22:12:00.000',29,'Analogue','PM710: Power factor',0,'---'),(637,'PM1_13_kW','PM710: Power',1,'2015-08-18 07:40:37.738','2015-07-17 22:12:00.000',29,'Analogue','PM710: Power',0,'kW'),(638,'PM1_13_kVA','PM710: apparent power',1,'2015-08-18 07:40:37.754','2015-07-17 22:12:00.000',29,'Analogue','PM710: apparent power',0,'kVA'),(639,'PM1_13_F','PM710: Frequency',1,'2015-08-18 07:40:37.770','2015-07-17 22:12:00.000',29,'Analogue','PM710: Frequency',0,'Hz'),(640,'PM1_13_I1','PM710: Current L1',1,'2015-08-18 07:40:37.785','2015-07-17 22:12:00.000',29,'Analogue','PM710: Current L1',0,'A'),(641,'PM1_13_I2','PM710: Current L2',1,'2015-08-18 07:40:37.785','2015-07-17 22:12:00.000',29,'Analogue','PM710: Current L2',0,'A'),(642,'PM1_13_I3','PM710: Current L3',1,'2015-08-18 07:40:37.801','2015-07-17 22:12:00.000',29,'Analogue','PM710: Current L3',0,'A'),(643,'PM1_13_In','PM710: Current',1,'2015-08-18 07:40:37.817','2015-07-17 22:12:00.000',29,'Analogue','PM710: Current',0,'A'),(644,'PM1_13_V12','PM710: Voltage L12',1,'2015-08-18 07:40:37.832','2015-07-17 22:12:00.000',29,'Analogue','PM710: Voltage L12',0,'V'),(645,'PM1_13_V23','PM710: Voltage L23',1,'2015-08-18 07:40:37.848','2015-07-17 22:12:00.000',29,'Analogue','PM710: Voltage L23',0,'V'),(646,'PM1_13_V31','PM710: Voltage L31',1,'2015-08-18 07:40:37.848','2015-07-17 22:12:00.000',29,'Analogue','PM710: Voltage L31',0,'V'),(647,'PM1_13_V1','PM710: Voltage L1',1,'2015-08-18 07:40:37.863','2015-07-17 22:12:00.000',29,'Analogue','PM710: Voltage L1',0,'V'),(648,'PM1_13_V2','PM710: Voltage L2',1,'2015-08-18 07:40:37.879','2015-07-17 22:12:00.000',29,'Analogue','PM710: Voltage L2',0,'V'),(649,'PM1_13_V3','PM710: Voltage L3',1,'2015-08-18 07:40:37.895','2015-07-17 22:12:00.000',29,'Analogue','PM710: Voltage L3',0,'V'),(650,'PM1_13_kW1','PM710: Power L1',1,'2015-08-18 07:40:37.910','2015-07-17 22:12:00.000',29,'Analogue','PM710: Power L1',0,'kW'),(651,'PM1_13_kW2','PM710: Power L2',1,'2015-08-18 07:40:37.910','2015-07-17 22:12:00.000',29,'Analogue','PM710: Power L2',0,'kW'),(652,'PM1_13_kW3','PM710: Power L3',1,'2015-08-18 07:40:37.926','2015-07-17 22:12:00.000',29,'Analogue','PM710: Power L3',0,'kW'),(653,'PM1_13_kVA1','PM710: apparent power L1',1,'2015-08-18 07:40:37.942','2015-07-17 22:12:00.000',29,'Analogue','PM710: apparent power L1',0,'kVA'),(654,'PM1_13_kVA2','PM710: apparent power L2',1,'2015-08-18 07:40:37.957','2015-07-17 22:12:00.000',29,'Analogue','PM710: apparent power L2',0,'kVA'),(655,'PM1_13_kVA3','PM710: apparent power L3',1,'2015-08-18 07:40:37.973','2015-07-17 22:12:00.000',29,'Analogue','PM710: apparent power L3',0,'kVA'),(656,'PM1_13_THD_I1','PM710: THD Current L1',1,'2015-08-18 07:40:37.973','2015-07-17 22:12:00.000',29,'Analogue','PM710: THD Current L1',0,'%'),(657,'PM1_13_THD_I2','PM710: THD Current L2',1,'2015-08-18 07:40:37.988','2015-07-17 22:12:00.000',29,'Analogue','PM710: THD Current L2',0,'%'),(658,'PM1_13_THD_I3','PM710: THD Current L3',1,'2015-08-18 07:40:38.004','2015-07-17 22:12:00.000',29,'Analogue','PM710: THD Current L3',0,'%'),(659,'PM1_13_THD_V1','PM710: THD Voltage L1',1,'2015-08-18 07:40:38.020','2015-07-17 22:12:00.000',29,'Analogue','PM710: THD Voltage L1',0,'%'),(660,'PM1_13_THD_V2','PM710: THD Voltage L2',1,'2015-08-18 07:40:38.035','2015-07-17 22:12:00.000',29,'Analogue','PM710: THD Voltage L2',0,'%'),(661,'PM1_13_THD_V3','PM710: THD Voltage L3',1,'2015-08-18 07:40:38.051','2015-07-17 22:12:00.000',29,'Analogue','PM710: THD Voltage L3',0,'%'),(662,'PM1_13_THD_V12','PM710: THD Voltage L12',1,'2015-08-18 07:40:38.067','2015-07-17 22:12:00.000',29,'Analogue','PM710: THD Voltage L12',0,'%'),(663,'PM1_13_THD_V23','PM710: THD Voltage L23',1,'2015-08-18 07:40:38.082','2015-07-17 22:12:00.000',29,'Analogue','PM710: THD Voltage L23',0,'%'),(664,'PM1_13_THD_V31','PM710: THD Voltage L31',1,'2015-08-18 07:40:38.098','2015-07-17 22:12:00.000',29,'Analogue','PM710: THD Voltage L31',0,'%'),(665,'PM1_13_Hour','PM710: Hour',1,'2015-08-18 07:40:38.098','2015-07-17 22:12:00.000',29,'Analogue','PM710: Hour',0,'Hour'),(666,'PM1_13_Min','PM710: Min',1,'2015-08-18 07:40:38.113','2015-07-17 22:12:00.000',29,'Analogue','PM710: Min',0,'Min'),(667,'PM1_11_kWh','PM710: Energy',1,'2015-08-18 07:40:38.129','2015-07-17 22:12:00.000',26,'Analogue','PM710: Energy',0,'kWh'),(668,'PM1_11_pf','PM710: Power factor',1,'2015-08-18 07:40:38.145','2015-07-17 22:12:00.000',26,'Analogue','PM710: Power factor',0,'---'),(669,'PM1_11_kW','PM710: Power',1,'2015-08-18 07:40:38.145','2015-07-17 22:12:00.000',26,'Analogue','PM710: Power',0,'kW'),(670,'PM1_11_kVA','PM710: apparent power',1,'2015-08-18 07:40:38.160','2015-07-17 22:12:00.000',26,'Analogue','PM710: apparent power',0,'kVA'),(671,'PM1_11_F','PM710: Frequency',1,'2015-08-18 07:40:38.176','2015-07-17 22:12:00.000',26,'Analogue','PM710: Frequency',0,'Hz'),(672,'PM1_11_I1','PM710: Current L1',1,'2015-08-18 07:40:38.192','2015-07-17 22:12:00.000',26,'Analogue','PM710: Current L1',0,'A'),(673,'PM1_11_I2','PM710: Current L2',1,'2015-08-18 07:40:38.207','2015-07-17 22:12:00.000',26,'Analogue','PM710: Current L2',0,'A'),(674,'PM1_11_I3','PM710: Current L3',1,'2015-08-18 07:40:38.207','2015-07-17 22:12:00.000',26,'Analogue','PM710: Current L3',0,'A'),(675,'PM1_11_In','PM710: Current',1,'2015-08-18 07:40:38.223','2015-07-17 22:12:00.000',26,'Analogue','PM710: Current',0,'A'),(676,'PM1_11_V12','PM710: Voltage L12',1,'2015-08-18 07:40:38.238','2015-07-17 22:12:00.000',26,'Analogue','PM710: Voltage L12',0,'V'),(677,'PM1_11_V23','PM710: Voltage L23',1,'2015-08-18 07:40:38.254','2015-07-17 22:12:00.000',26,'Analogue','PM710: Voltage L23',0,'V'),(678,'PM1_11_V31','PM710: Voltage L31',1,'2015-08-18 07:40:38.270','2015-07-17 22:12:00.000',26,'Analogue','PM710: Voltage L31',0,'V'),(679,'PM1_11_V1','PM710: Voltage L1',1,'2015-08-18 07:40:38.270','2015-07-17 22:12:00.000',26,'Analogue','PM710: Voltage L1',0,'V'),(680,'PM1_11_V2','PM710: Voltage L2',1,'2015-08-18 07:40:38.285','2015-07-17 22:12:00.000',26,'Analogue','PM710: Voltage L2',0,'V'),(681,'PM1_11_V3','PM710: Voltage L3',1,'2015-08-18 07:40:38.301','2015-07-17 22:12:00.000',26,'Analogue','PM710: Voltage L3',0,'V'),(682,'PM1_11_kW1','PM710: Power L1',1,'2015-08-18 07:40:38.317','2015-07-17 22:12:00.000',26,'Analogue','PM710: Power L1',0,'kW'),(683,'PM1_11_kW2','PM710: Power L2',1,'2015-08-18 07:40:38.332','2015-07-17 22:12:00.000',26,'Analogue','PM710: Power L2',0,'kW'),(684,'PM1_11_kW3','PM710: Power L3',1,'2015-08-18 07:40:38.332','2015-07-17 22:12:00.000',26,'Analogue','PM710: Power L3',0,'kW'),(685,'PM1_11_kVA1','PM710: apparent power L1',1,'2015-08-18 07:40:38.348','2015-07-17 22:12:00.000',26,'Analogue','PM710: apparent power L1',0,'kVA'),(686,'PM1_11_kVA2','PM710: apparent power L2',1,'2015-08-18 07:40:38.363','2015-07-17 22:12:00.000',26,'Analogue','PM710: apparent power L2',0,'kVA'),(687,'PM1_11_kVA3','PM710: apparent power L3',1,'2015-08-18 07:40:38.379','2015-07-17 22:12:00.000',26,'Analogue','PM710: apparent power L3',0,'kVA'),(688,'PM1_11_THD_I1','PM710: THD Current L1',1,'2015-08-18 07:40:38.395','2015-07-17 22:12:00.000',26,'Analogue','PM710: THD Current L1',0,'%'),(689,'PM1_11_THD_I2','PM710: THD Current L2',1,'2015-08-18 07:40:38.395','2015-07-17 22:12:00.000',26,'Analogue','PM710: THD Current L2',0,'%'),(690,'PM1_11_THD_I3','PM710: THD Current L3',1,'2015-08-18 07:40:38.410','2015-07-17 22:12:00.000',26,'Analogue','PM710: THD Current L3',0,'%'),(691,'PM1_11_THD_V1','PM710: THD Voltage L1',1,'2015-08-18 07:40:38.426','2015-07-17 22:12:00.000',26,'Analogue','PM710: THD Voltage L1',0,'%'),(692,'PM1_11_THD_V2','PM710: THD Voltage L2',1,'2015-08-18 07:40:38.442','2015-07-17 22:12:00.000',26,'Analogue','PM710: THD Voltage L2',0,'%'),(693,'PM1_11_THD_V3','PM710: THD Voltage L3',1,'2015-08-18 07:40:38.457','2015-07-17 22:12:00.000',26,'Analogue','PM710: THD Voltage L3',0,'%'),(694,'PM1_11_THD_V12','PM710: THD Voltage L12',1,'2015-08-18 07:40:38.457','2015-07-17 22:12:00.000',26,'Analogue','PM710: THD Voltage L12',0,'%'),(695,'PM1_11_THD_V23','PM710: THD Voltage L23',1,'2015-08-18 07:40:38.473','2015-07-17 22:12:00.000',26,'Analogue','PM710: THD Voltage L23',0,'%'),(696,'PM1_11_THD_V31','PM710: THD Voltage L31',1,'2015-08-18 07:40:38.488','2015-07-17 22:12:00.000',26,'Analogue','PM710: THD Voltage L31',0,'%'),(697,'PM1_11_Hour','PM710: Hour',1,'2015-08-18 07:40:38.504','2015-07-17 22:12:00.000',26,'Analogue','PM710: Hour',0,'Hour'),(698,'PM1_11_Min','PM710: Min',1,'2015-08-18 07:40:38.520','2015-07-17 22:12:00.000',26,'Analogue','PM710: Min',0,'Min'),(699,'PM1_16_kWh','PM710: Energy',1,'2015-08-18 07:40:38.520','2015-07-17 22:12:00.000',27,'Analogue','PM710: Energy',0,'kWh'),(700,'PM1_16_pf','PM710: Power factor',1,'2015-08-18 07:40:38.535','2015-07-17 22:12:00.000',27,'Analogue','PM710: Power factor',0,'---'),(701,'PM1_16_kW','PM710: Power',1,'2015-08-18 07:40:38.551','2015-07-17 22:12:00.000',27,'Analogue','PM710: Power',0,'kW'),(702,'PM1_16_kVA','PM710: apparent power',1,'2015-08-18 07:40:38.567','2015-07-17 22:12:00.000',27,'Analogue','PM710: apparent power',0,'kVA'),(703,'PM1_16_F','PM710: Frequency',1,'2015-08-18 07:40:38.567','2015-07-17 22:12:00.000',27,'Analogue','PM710: Frequency',0,'Hz'),(704,'PM1_16_I1','PM710: Current L1',1,'2015-08-18 07:40:38.582','2015-07-17 22:12:00.000',27,'Analogue','PM710: Current L1',0,'A'),(705,'PM1_16_I2','PM710: Current L2',1,'2015-08-18 07:40:38.598','2015-07-17 22:12:00.000',27,'Analogue','PM710: Current L2',0,'A'),(706,'PM1_16_I3','PM710: Current L3',1,'2015-08-18 07:40:38.613','2015-07-17 22:12:00.000',27,'Analogue','PM710: Current L3',0,'A'),(707,'PM1_16_In','PM710: Current',1,'2015-08-18 07:40:38.629','2015-07-17 22:12:00.000',27,'Analogue','PM710: Current',0,'A'),(708,'PM1_16_V12','PM710: Voltage L12',1,'2015-08-18 07:40:38.629','2015-07-17 22:12:00.000',27,'Analogue','PM710: Voltage L12',0,'V'),(709,'PM1_16_V23','PM710: Voltage L23',1,'2015-08-18 07:40:38.645','2015-07-17 22:12:00.000',27,'Analogue','PM710: Voltage L23',0,'V'),(710,'PM1_16_V31','PM710: Voltage L31',1,'2015-08-18 07:40:38.660','2015-07-17 22:12:00.000',27,'Analogue','PM710: Voltage L31',0,'V'),(711,'PM1_16_V1','PM710: Voltage L1',1,'2015-08-18 07:40:38.676','2015-07-17 22:12:00.000',27,'Analogue','PM710: Voltage L1',0,'V'),(712,'PM1_16_V2','PM710: Voltage L2',1,'2015-08-18 07:40:38.692','2015-07-17 22:12:00.000',27,'Analogue','PM710: Voltage L2',0,'V'),(713,'PM1_16_V3','PM710: Voltage L3',1,'2015-08-18 07:40:38.692','2015-07-17 22:12:00.000',27,'Analogue','PM710: Voltage L3',0,'V'),(714,'PM1_16_kW1','PM710: Power L1',1,'2015-08-18 07:40:38.770','2015-07-17 22:12:00.000',27,'Analogue','PM710: Power L1',0,'kW'),(715,'PM1_16_kW2','PM710: Power L2',1,'2015-08-18 07:40:38.785','2015-07-17 22:12:00.000',27,'Analogue','PM710: Power L2',0,'kW'),(716,'PM1_16_kW3','PM710: Power L3',1,'2015-08-18 07:40:38.785','2015-07-17 22:12:00.000',27,'Analogue','PM710: Power L3',0,'kW'),(717,'PM1_16_kVA1','PM710: apparent power L1',1,'2015-08-18 07:40:38.801','2015-07-17 22:12:00.000',27,'Analogue','PM710: apparent power L1',0,'kVA'),(718,'PM1_16_kVA2','PM710: apparent power L2',1,'2015-08-18 07:40:38.817','2015-07-17 22:12:00.000',27,'Analogue','PM710: apparent power L2',0,'kVA'),(719,'PM1_16_kVA3','PM710: apparent power L3',1,'2015-08-18 07:40:38.832','2015-07-17 22:12:00.000',27,'Analogue','PM710: apparent power L3',0,'kVA'),(720,'PM1_16_THD_I1','PM710: THD Current L1',1,'2015-08-18 07:40:38.848','2015-07-17 22:12:00.000',27,'Analogue','PM710: THD Current L1',0,'%'),(721,'PM1_16_THD_I2','PM710: THD Current L2',1,'2015-08-18 07:40:38.848','2015-07-17 22:12:00.000',27,'Analogue','PM710: THD Current L2',0,'%'),(722,'PM1_16_THD_I3','PM710: THD Current L3',1,'2015-08-18 07:40:38.863','2015-07-17 22:12:00.000',27,'Analogue','PM710: THD Current L3',0,'%'),(723,'PM1_16_THD_V1','PM710: THD Voltage L1',1,'2015-08-18 07:40:38.879','2015-07-17 22:12:00.000',27,'Analogue','PM710: THD Voltage L1',0,'%'),(724,'PM1_16_THD_V2','PM710: THD Voltage L2',1,'2015-08-18 07:40:38.895','2015-07-17 22:12:00.000',27,'Analogue','PM710: THD Voltage L2',0,'%'),(725,'PM1_16_THD_V3','PM710: THD Voltage L3',1,'2015-08-18 07:40:38.895','2015-07-17 22:12:00.000',27,'Analogue','PM710: THD Voltage L3',0,'%'),(726,'PM1_16_THD_V12','PM710: THD Voltage L12',1,'2015-08-18 07:40:38.910','2015-07-17 22:12:00.000',27,'Analogue','PM710: THD Voltage L12',0,'%'),(727,'PM1_16_THD_V23','PM710: THD Voltage L23',1,'2015-08-18 07:40:38.926','2015-07-17 22:12:00.000',27,'Analogue','PM710: THD Voltage L23',0,'%'),(728,'PM1_16_THD_V31','PM710: THD Voltage L31',1,'2015-08-18 07:40:38.942','2015-07-17 22:12:00.000',27,'Analogue','PM710: THD Voltage L31',0,'%'),(729,'PM1_16_Hour','PM710: Hour',1,'2015-08-18 07:40:38.957','2015-07-17 22:12:00.000',27,'Analogue','PM710: Hour',0,'Hour'),(730,'PM1_16_Min','PM710: Min',1,'2015-08-18 07:40:38.957','2015-07-17 22:12:00.000',27,'Analogue','PM710: Min',0,'Min'),(731,'PM1_15_kWh','PM710: Energy',1,'2015-08-18 07:40:38.973','2015-07-17 22:12:00.000',30,'Analogue','PM710: Energy',0,'kWh'),(732,'PM1_15_pf','PM710: Power factor',1,'2015-08-18 07:40:38.988','2015-07-17 22:12:00.000',30,'Analogue','PM710: Power factor',0,'---'),(733,'PM1_15_kW','PM710: Power',1,'2015-08-18 07:40:39.004','2015-07-17 22:12:00.000',30,'Analogue','PM710: Power',0,'kW'),(734,'PM1_15_kVA','PM710: apparent power',1,'2015-08-18 07:40:39.020','2015-07-17 22:12:00.000',30,'Analogue','PM710: apparent power',0,'kVA'),(735,'PM1_15_F','PM710: Frequency',1,'2015-08-18 07:40:39.020','2015-07-17 22:12:00.000',30,'Analogue','PM710: Frequency',0,'Hz'),(736,'PM1_15_I1','PM710: Current L1',1,'2015-08-18 07:40:39.035','2015-07-17 22:12:00.000',30,'Analogue','PM710: Current L1',0,'A'),(737,'PM1_15_I2','PM710: Current L2',1,'2015-08-18 07:40:39.051','2015-07-17 22:12:00.000',30,'Analogue','PM710: Current L2',0,'A'),(738,'PM1_15_I3','PM710: Current L3',1,'2015-08-18 07:40:39.067','2015-07-17 22:12:00.000',30,'Analogue','PM710: Current L3',0,'A'),(739,'PM1_15_In','PM710: Current',1,'2015-08-18 07:40:39.082','2015-07-17 22:12:00.000',30,'Analogue','PM710: Current',0,'A'),(740,'PM1_15_V12','PM710: Voltage L12',1,'2015-08-18 07:40:39.082','2015-07-17 22:12:00.000',30,'Analogue','PM710: Voltage L12',0,'V'),(741,'PM1_15_V23','PM710: Voltage L23',1,'2015-08-18 07:40:39.098','2015-07-17 22:12:00.000',30,'Analogue','PM710: Voltage L23',0,'V'),(742,'PM1_15_V31','PM710: Voltage L31',1,'2015-08-18 07:40:39.113','2015-07-17 22:12:00.000',30,'Analogue','PM710: Voltage L31',0,'V'),(743,'PM1_15_V1','PM710: Voltage L1',1,'2015-08-18 07:40:39.129','2015-07-17 22:12:00.000',30,'Analogue','PM710: Voltage L1',0,'V'),(744,'PM1_15_V2','PM710: Voltage L2',1,'2015-08-18 07:40:39.129','2015-07-17 22:12:00.000',30,'Analogue','PM710: Voltage L2',0,'V'),(745,'PM1_15_V3','PM710: Voltage L3',1,'2015-08-18 07:40:39.145','2015-07-17 22:12:00.000',30,'Analogue','PM710: Voltage L3',0,'V'),(746,'PM1_15_kW1','PM710: Power L1',1,'2015-08-18 07:40:39.160','2015-07-17 22:12:00.000',30,'Analogue','PM710: Power L1',0,'kW'),(747,'PM1_15_kW2','PM710: Power L2',1,'2015-08-18 07:40:39.176','2015-07-17 22:12:00.000',30,'Analogue','PM710: Power L2',0,'kW'),(748,'PM1_15_kW3','PM710: Power L3',1,'2015-08-18 07:40:39.192','2015-07-17 22:12:00.000',30,'Analogue','PM710: Power L3',0,'kW'),(749,'PM1_15_kVA1','PM710: apparent power L1',1,'2015-08-18 07:40:39.192','2015-07-17 22:12:00.000',30,'Analogue','PM710: apparent power L1',0,'kVA'),(750,'PM1_15_kVA2','PM710: apparent power L2',1,'2015-08-18 07:40:39.207','2015-07-17 22:12:00.000',30,'Analogue','PM710: apparent power L2',0,'kVA'),(751,'PM1_15_kVA3','PM710: apparent power L3',1,'2015-08-18 07:40:39.223','2015-07-17 22:12:00.000',30,'Analogue','PM710: apparent power L3',0,'kVA'),(752,'PM1_15_THD_I1','PM710: THD Current L1',1,'2015-08-18 07:40:39.238','2015-07-17 22:12:00.000',30,'Analogue','PM710: THD Current L1',0,'%'),(753,'PM1_15_THD_I2','PM710: THD Current L2',1,'2015-08-18 07:40:39.254','2015-07-17 22:12:00.000',30,'Analogue','PM710: THD Current L2',0,'%'),(754,'PM1_15_THD_I3','PM710: THD Current L3',1,'2015-08-18 07:40:39.254','2015-07-17 22:12:00.000',30,'Analogue','PM710: THD Current L3',0,'%'),(755,'PM1_15_THD_V1','PM710: THD Voltage L1',1,'2015-08-18 07:40:39.270','2015-07-17 22:12:00.000',30,'Analogue','PM710: THD Voltage L1',0,'%'),(756,'PM1_15_THD_V2','PM710: THD Voltage L2',1,'2015-08-18 07:40:39.285','2015-07-17 22:12:00.000',30,'Analogue','PM710: THD Voltage L2',0,'%'),(757,'PM1_15_THD_V3','PM710: THD Voltage L3',1,'2015-08-18 07:40:39.301','2015-07-17 22:12:00.000',30,'Analogue','PM710: THD Voltage L3',0,'%'),(758,'PM1_15_THD_V12','PM710: THD Voltage L12',1,'2015-08-18 07:40:39.301','2015-07-17 22:12:00.000',30,'Analogue','PM710: THD Voltage L12',0,'%'),(759,'PM1_15_THD_V23','PM710: THD Voltage L23',1,'2015-08-18 07:40:39.317','2015-07-17 22:12:00.000',30,'Analogue','PM710: THD Voltage L23',0,'%'),(760,'PM1_15_THD_V31','PM710: THD Voltage L31',1,'2015-08-18 07:40:39.332','2015-07-17 22:12:00.000',30,'Analogue','PM710: THD Voltage L31',0,'%'),(761,'PM1_15_Hour','PM710: Hour',1,'2015-08-18 07:40:39.348','2015-07-17 22:12:00.000',30,'Analogue','PM710: Hour',0,'Hour'),(762,'PM1_15_Min','PM710: Min',1,'2015-08-18 07:40:39.363','2015-07-17 22:12:00.000',30,'Analogue','PM710: Min',0,'Min'),(763,'OTB20_I4','MC CB 100A',1,'2015-08-18 07:40:39.363','2015-07-17 22:12:00.000',30,'Digital','MC CB 100A',0,'---'),(764,'OTB20_I2','MC CB 100A',1,'2015-08-18 07:40:39.379','2015-07-17 22:12:00.000',30,'Digital','MC CB 100A',0,'---'),(765,'OTB20_I0','MC CB 100A',1,'2015-08-18 07:40:39.395','2015-07-17 22:12:00.000',30,'Digital','MC CB 100A',0,'---'),(766,'OTB19_I10','MC CB 100A',1,'2015-08-18 07:40:39.410','2015-07-17 22:12:00.000',30,'Digital','MC CB 100A',0,'---'),(767,'OTB19_I8','MC CB 100A',1,'2015-08-18 07:40:39.426','2015-07-17 22:12:00.000',30,'Digital','MC CB 100A',0,'---'),(768,'OTB19_I6','MC CB 100A',1,'2015-08-18 07:40:39.426','2015-07-17 22:12:00.000',30,'Digital','MC CB 100A',0,'---'),(769,'OTB19_I4','MC CB 100A',1,'2015-08-18 07:40:39.442','2015-07-17 22:12:00.000',30,'Digital','MC CB 100A',0,'---'),(770,'OTB20_I6','MC CB 100A',1,'2015-08-18 07:40:39.457','2015-07-17 22:12:00.000',30,'Digital','MC CB 100A',0,'---'),(771,'PM1_8_kWh','PM710: Energy',1,'2015-08-18 07:40:39.473','2015-07-17 22:12:00.000',33,'Analogue','PM710: Energy',0,'kWh'),(772,'PM1_8_pf','PM710: Power factor',1,'2015-08-18 07:40:39.473','2015-07-17 22:12:00.000',33,'Analogue','PM710: Power factor',0,'---'),(773,'PM1_8_kW','PM710: Power',1,'2015-08-18 07:40:39.488','2015-07-17 22:12:00.000',33,'Analogue','PM710: Power',0,'kW'),(774,'PM1_8_kVA','PM710: apparent power',1,'2015-08-18 07:40:39.504','2015-07-17 22:12:00.000',33,'Analogue','PM710: apparent power',0,'kVA'),(775,'PM1_8_F','PM710: Frequency',1,'2015-08-18 07:40:39.520','2015-07-17 22:12:00.000',33,'Analogue','PM710: Frequency',0,'Hz'),(776,'PM1_8_I1','PM710: Current L1',1,'2015-08-18 07:40:39.535','2015-07-17 22:12:00.000',33,'Analogue','PM710: Current L1',0,'A'),(777,'PM1_8_I2','PM710: Current L2',1,'2015-08-18 07:40:39.567','2015-07-17 22:12:00.000',33,'Analogue','PM710: Current L2',0,'A'),(778,'PM1_8_I3','PM710: Current L3',1,'2015-08-18 07:40:39.582','2015-07-17 22:12:00.000',33,'Analogue','PM710: Current L3',0,'A'),(779,'PM1_8_In','PM710: Current',1,'2015-08-18 07:40:39.598','2015-07-17 22:12:00.000',33,'Analogue','PM710: Current',0,'A'),(780,'PM1_8_V12','PM710: Voltage L12',1,'2015-08-18 07:40:39.598','2015-07-17 22:12:00.000',33,'Analogue','PM710: Voltage L12',0,'V'),(781,'PM1_8_V23','PM710: Voltage L23',1,'2015-08-18 07:40:39.613','2015-07-17 22:12:00.000',33,'Analogue','PM710: Voltage L23',0,'V'),(782,'PM1_8_V31','PM710: Voltage L31',1,'2015-08-18 07:40:39.629','2015-07-17 22:12:00.000',33,'Analogue','PM710: Voltage L31',0,'V'),(783,'PM1_8_V1','PM710: Voltage L1',1,'2015-08-18 07:40:39.645','2015-07-17 22:12:00.000',33,'Analogue','PM710: Voltage L1',0,'V'),(784,'PM1_8_V2','PM710: Voltage L2',1,'2015-08-18 07:40:39.645','2015-07-17 22:12:00.000',33,'Analogue','PM710: Voltage L2',0,'V'),(785,'PM1_8_V3','PM710: Voltage L3',1,'2015-08-18 07:40:39.660','2015-07-17 22:12:00.000',33,'Analogue','PM710: Voltage L3',0,'V'),(786,'PM1_8_kW1','PM710: Power L1',1,'2015-08-18 07:40:39.676','2015-07-17 22:12:00.000',33,'Analogue','PM710: Power L1',0,'kW'),(787,'PM1_8_kW2','PM710: Power L2',1,'2015-08-18 07:40:39.692','2015-07-17 22:12:00.000',33,'Analogue','PM710: Power L2',0,'kW'),(788,'PM1_8_kW3','PM710: Power L3',1,'2015-08-18 07:40:39.707','2015-07-17 22:12:00.000',33,'Analogue','PM710: Power L3',0,'kW'),(789,'PM1_8_kVA1','PM710: apparent power L1',1,'2015-08-18 07:40:39.707','2015-07-17 22:12:00.000',33,'Analogue','PM710: apparent power L1',0,'kVA'),(790,'PM1_8_kVA2','PM710: apparent power L2',1,'2015-08-18 07:40:39.723','2015-07-17 22:12:00.000',33,'Analogue','PM710: apparent power L2',0,'kVA'),(791,'PM1_8_kVA3','PM710: apparent power L3',1,'2015-08-18 07:40:39.738','2015-07-17 22:12:00.000',33,'Analogue','PM710: apparent power L3',0,'kVA'),(792,'PM1_8_THD_I1','PM710: THD Current L1',1,'2015-08-18 07:40:39.754','2015-07-17 22:12:00.000',33,'Analogue','PM710: THD Current L1',0,'%'),(793,'PM1_8_THD_I2','PM710: THD Current L2',1,'2015-08-18 07:40:39.770','2015-07-17 22:12:00.000',33,'Analogue','PM710: THD Current L2',0,'%'),(794,'PM1_8_THD_I3','PM710: THD Current L3',1,'2015-08-18 07:40:39.785','2015-07-17 22:12:00.000',33,'Analogue','PM710: THD Current L3',0,'%'),(795,'PM1_8_THD_V1','PM710: THD Voltage L1',1,'2015-08-18 07:40:39.801','2015-07-17 22:12:00.000',33,'Analogue','PM710: THD Voltage L1',0,'%'),(796,'PM1_8_THD_V2','PM710: THD Voltage L2',1,'2015-08-18 07:40:39.817','2015-07-17 22:12:00.000',33,'Analogue','PM710: THD Voltage L2',0,'%'),(797,'PM1_8_THD_V3','PM710: THD Voltage L3',1,'2015-08-18 07:40:39.817','2015-07-17 22:12:00.000',33,'Analogue','PM710: THD Voltage L3',0,'%'),(798,'PM1_8_THD_V12','PM710: THD Voltage L12',1,'2015-08-18 07:40:39.832','2015-07-17 22:12:00.000',33,'Analogue','PM710: THD Voltage L12',0,'%'),(799,'PM1_8_THD_V23','PM710: THD Voltage L23',1,'2015-08-18 07:40:39.848','2015-07-17 22:12:00.000',33,'Analogue','PM710: THD Voltage L23',0,'%'),(800,'PM1_8_THD_V31','PM710: THD Voltage L31',1,'2015-08-18 07:40:39.863','2015-07-17 22:12:00.000',33,'Analogue','PM710: THD Voltage L31',0,'%'),(801,'PM1_8_Hour','PM710: Hour',1,'2015-08-18 07:40:39.879','2015-07-17 22:12:00.000',33,'Analogue','PM710: Hour',0,'Hour'),(802,'PM1_8_Min','PM710: Min',1,'2015-08-18 07:40:39.895','2015-07-17 22:12:00.000',33,'Analogue','PM710: Min',0,'Min'),(803,'OTB8_I0','MC CB 630A',1,'2015-08-18 07:40:39.910','2015-07-17 22:12:00.000',33,'Digital','MC CB 630A',0,'---'),(804,'OTB8_I2','MC CB 100A',1,'2015-08-18 07:40:39.926','2015-07-17 22:12:00.000',33,'Digital','MC CB 100A',0,'---'),(805,'PM1_9_kWh','PM710: Energy',1,'2015-08-18 07:40:39.926','2015-07-17 22:12:00.000',34,'Analogue','PM710: Energy',0,'kWh'),(806,'PM1_9_pf','PM710: Power factor',1,'2015-08-18 07:40:39.942','2015-07-17 22:12:00.000',34,'Analogue','PM710: Power factor',0,'---'),(807,'PM1_9_kW','PM710: Power',1,'2015-08-18 07:40:39.957','2015-07-17 22:12:00.000',34,'Analogue','PM710: Power',0,'kW'),(808,'PM1_9_kVA','PM710: apparent power',1,'2015-08-18 07:40:39.973','2015-07-17 22:12:00.000',34,'Analogue','PM710: apparent power',0,'kVA'),(809,'PM1_9_F','PM710: Frequency',1,'2015-08-18 07:40:39.988','2015-07-17 22:12:00.000',34,'Analogue','PM710: Frequency',0,'Hz'),(810,'PM1_9_I1','PM710: Current L1',1,'2015-08-18 07:40:39.988','2015-07-17 22:12:00.000',34,'Analogue','PM710: Current L1',0,'A'),(811,'PM1_9_I2','PM710: Current L2',1,'2015-08-18 07:40:40.004','2015-07-17 22:12:00.000',34,'Analogue','PM710: Current L2',0,'A'),(812,'PM1_9_I3','PM710: Current L3',1,'2015-08-18 07:40:40.020','2015-07-17 22:12:00.000',34,'Analogue','PM710: Current L3',0,'A'),(813,'PM1_9_In','PM710: Current',1,'2015-08-18 07:40:40.035','2015-07-17 22:12:00.000',34,'Analogue','PM710: Current',0,'A'),(814,'PM1_9_V12','PM710: Voltage L12',1,'2015-08-18 07:40:40.051','2015-07-17 22:12:00.000',34,'Analogue','PM710: Voltage L12',0,'V'),(815,'PM1_9_V23','PM710: Voltage L23',1,'2015-08-18 07:40:40.067','2015-07-17 22:12:00.000',34,'Analogue','PM710: Voltage L23',0,'V'),(816,'PM1_9_V31','PM710: Voltage L31',1,'2015-08-18 07:40:40.082','2015-07-17 22:12:00.000',34,'Analogue','PM710: Voltage L31',0,'V'),(817,'PM1_9_V1','PM710: Voltage L1',1,'2015-08-18 07:40:40.098','2015-07-17 22:12:00.000',34,'Analogue','PM710: Voltage L1',0,'V'),(818,'PM1_9_V2','PM710: Voltage L2',1,'2015-08-18 07:40:40.098','2015-07-17 22:12:00.000',34,'Analogue','PM710: Voltage L2',0,'V'),(819,'PM1_9_V3','PM710: Voltage L3',1,'2015-08-18 07:40:40.113','2015-07-17 22:12:00.000',34,'Analogue','PM710: Voltage L3',0,'V'),(820,'PM1_9_kW1','PM710: Power L1',1,'2015-08-18 07:40:40.129','2015-07-17 22:12:00.000',34,'Analogue','PM710: Power L1',0,'kW'),(821,'PM1_9_kW2','PM710: Power L2',1,'2015-08-18 07:40:40.145','2015-07-17 22:12:00.000',34,'Analogue','PM710: Power L2',0,'kW'),(822,'PM1_9_kW3','PM710: Power L3',1,'2015-08-18 07:40:40.160','2015-07-17 22:12:00.000',34,'Analogue','PM710: Power L3',0,'kW'),(823,'PM1_9_kVA1','PM710: apparent power L1',1,'2015-08-18 07:40:40.160','2015-07-17 22:12:00.000',34,'Analogue','PM710: apparent power L1',0,'kVA'),(824,'PM1_9_kVA2','PM710: apparent power L2',1,'2015-08-18 07:40:40.176','2015-07-17 22:12:00.000',34,'Analogue','PM710: apparent power L2',0,'kVA'),(825,'PM1_9_kVA3','PM710: apparent power L3',1,'2015-08-18 07:40:40.192','2015-07-17 22:12:00.000',34,'Analogue','PM710: apparent power L3',0,'kVA'),(826,'PM1_9_THD_I1','PM710: THD Current L1',1,'2015-08-18 07:40:40.207','2015-07-17 22:12:00.000',34,'Analogue','PM710: THD Current L1',0,'%'),(827,'PM1_9_THD_I2','PM710: THD Current L2',1,'2015-08-18 07:40:40.223','2015-07-17 22:12:00.000',34,'Analogue','PM710: THD Current L2',0,'%'),(828,'PM1_9_THD_I3','PM710: THD Current L3',1,'2015-08-18 07:40:40.223','2015-07-17 22:12:00.000',34,'Analogue','PM710: THD Current L3',0,'%'),(829,'PM1_9_THD_V1','PM710: THD Voltage L1',1,'2015-08-18 07:40:40.238','2015-07-17 22:12:00.000',34,'Analogue','PM710: THD Voltage L1',0,'%'),(830,'PM1_9_THD_V2','PM710: THD Voltage L2',1,'2015-08-18 07:40:40.254','2015-07-17 22:12:00.000',34,'Analogue','PM710: THD Voltage L2',0,'%'),(831,'PM1_9_THD_V3','PM710: THD Voltage L3',1,'2015-08-18 07:40:40.270','2015-07-17 22:12:00.000',34,'Analogue','PM710: THD Voltage L3',0,'%'),(832,'PM1_9_THD_V12','PM710: THD Voltage L12',1,'2015-08-18 07:40:40.285','2015-07-17 22:12:00.000',34,'Analogue','PM710: THD Voltage L12',0,'%'),(833,'PM1_9_THD_V23','PM710: THD Voltage L23',1,'2015-08-18 07:40:40.285','2015-07-17 22:12:00.000',34,'Analogue','PM710: THD Voltage L23',0,'%'),(834,'PM1_9_THD_V31','PM710: THD Voltage L31',1,'2015-08-18 07:40:40.301','2015-07-17 22:12:00.000',34,'Analogue','PM710: THD Voltage L31',0,'%'),(835,'PM1_9_Hour','PM710: Hour',1,'2015-08-18 07:40:40.332','2015-07-17 22:12:00.000',34,'Analogue','PM710: Hour',0,'Hour'),(836,'PM1_9_Min','PM710: Min',1,'2015-08-18 07:40:40.348','2015-07-17 22:12:00.000',34,'Analogue','PM710: Min',0,'Min'),(837,'OTB9_I0','MC CB 630A',1,'2015-08-18 07:40:40.363','2015-07-17 22:12:00.000',34,'Digital','MC CB 630A',0,'---'),(838,'OTB9_I2','MC CB 100A',1,'2015-08-18 07:40:40.379','2015-07-17 22:12:00.000',34,'Digital','MC CB 100A',0,'---'),(839,'OTB8_I9','A CB',1,'2015-08-18 07:40:40.395','2015-07-17 22:12:00.000',97,'Digital','A CB',0,'---'),(840,'OTB6_I3','MC CB 160A',1,'2015-08-18 07:40:40.410','2015-07-17 22:12:00.000',39,'Digital','MC CB 160A',0,'---'),(841,'OTB7_I8','MC CB 160A',1,'2015-08-18 07:40:40.410','2015-07-17 22:12:00.000',40,'Digital','MC CB 160A',0,'---'),(842,'OTB7_I6','MC CB 160A',1,'2015-08-18 07:40:40.426','2015-07-17 22:12:00.000',40,'Digital','MC CB 160A',0,'---'),(843,'OTB7_I2','MC CB 160A',1,'2015-08-18 07:40:40.442','2015-07-17 22:12:00.000',40,'Digital','MC CB 160A',0,'---'),(844,'OTB7_I4','MC CB 160A',1,'2015-08-18 07:40:40.457','2015-07-17 22:12:00.000',40,'Digital','MC CB 160A',0,'---'),(845,'PM1_7_kWh','PM710: Energy',1,'2015-08-18 07:40:40.473','2015-07-17 22:12:00.000',32,'Analogue','PM710: Energy',0,'kWh'),(846,'PM1_7_pf','PM710: Power factor',1,'2015-08-18 07:40:40.473','2015-07-17 22:12:00.000',32,'Analogue','PM710: Power factor',0,'---'),(847,'PM1_7_kW','PM710: Power',1,'2015-08-18 07:40:40.488','2015-07-17 22:12:00.000',32,'Analogue','PM710: Power',0,'kW'),(848,'PM1_7_kVA','PM710: apparent power',1,'2015-08-18 07:40:40.504','2015-07-17 22:12:00.000',32,'Analogue','PM710: apparent power',0,'kVA'),(849,'PM1_7_F','PM710: Frequency',1,'2015-08-18 07:40:40.520','2015-07-17 22:12:00.000',32,'Analogue','PM710: Frequency',0,'Hz'),(850,'PM1_7_I1','PM710: Current L1',1,'2015-08-18 07:40:40.535','2015-07-17 22:12:00.000',32,'Analogue','PM710: Current L1',0,'A'),(851,'PM1_7_I2','PM710: Current L2',1,'2015-08-18 07:40:40.535','2015-07-17 22:12:00.000',32,'Analogue','PM710: Current L2',0,'A'),(852,'PM1_7_I3','PM710: Current L3',1,'2015-08-18 07:40:40.551','2015-07-17 22:12:00.000',32,'Analogue','PM710: Current L3',0,'A'),(853,'PM1_7_In','PM710: Current',1,'2015-08-18 07:40:40.567','2015-07-17 22:12:00.000',32,'Analogue','PM710: Current',0,'A'),(854,'PM1_7_V12','PM710: Voltage L12',1,'2015-08-18 07:40:40.582','2015-07-17 22:12:00.000',32,'Analogue','PM710: Voltage L12',0,'V'),(855,'PM1_7_V23','PM710: Voltage L23',1,'2015-08-18 07:40:40.598','2015-07-17 22:12:00.000',32,'Analogue','PM710: Voltage L23',0,'V'),(856,'PM1_7_V31','PM710: Voltage L31',1,'2015-08-18 07:40:40.598','2015-07-17 22:12:00.000',32,'Analogue','PM710: Voltage L31',0,'V'),(857,'PM1_7_V1','PM710: Voltage L1',1,'2015-08-18 07:40:40.613','2015-07-17 22:12:00.000',32,'Analogue','PM710: Voltage L1',0,'V'),(858,'PM1_7_V2','PM710: Voltage L2',1,'2015-08-18 07:40:40.629','2015-07-17 22:12:00.000',32,'Analogue','PM710: Voltage L2',0,'V'),(859,'PM1_7_V3','PM710: Voltage L3',1,'2015-08-18 07:40:40.645','2015-07-17 22:12:00.000',32,'Analogue','PM710: Voltage L3',0,'V'),(860,'PM1_7_kW1','PM710: Power L1',1,'2015-08-18 07:40:40.645','2015-07-17 22:12:00.000',32,'Analogue','PM710: Power L1',0,'kW'),(861,'PM1_7_kW2','PM710: Power L2',1,'2015-08-18 07:40:40.660','2015-07-17 22:12:00.000',32,'Analogue','PM710: Power L2',0,'kW'),(862,'PM1_7_kW3','PM710: Power L3',1,'2015-08-18 07:40:40.676','2015-07-17 22:12:00.000',32,'Analogue','PM710: Power L3',0,'kW'),(863,'PM1_7_kVA1','PM710: apparent power L1',1,'2015-08-18 07:40:40.692','2015-07-17 22:12:00.000',32,'Analogue','PM710: apparent power L1',0,'kVA'),(864,'PM1_7_kVA2','PM710: apparent power L2',1,'2015-08-18 07:40:40.692','2015-07-17 22:12:00.000',32,'Analogue','PM710: apparent power L2',0,'kVA'),(865,'PM1_7_kVA3','PM710: apparent power L3',1,'2015-08-18 07:40:40.707','2015-07-17 22:12:00.000',32,'Analogue','PM710: apparent power L3',0,'kVA'),(866,'PM1_7_THD_I1','PM710: THD Current L1',1,'2015-08-18 07:40:40.723','2015-07-17 22:12:00.000',32,'Analogue','PM710: THD Current L1',0,'%'),(867,'PM1_7_THD_I2','PM710: THD Current L2',1,'2015-08-18 07:40:40.738','2015-07-17 22:12:00.000',32,'Analogue','PM710: THD Current L2',0,'%'),(868,'PM1_7_THD_I3','PM710: THD Current L3',1,'2015-08-18 07:40:40.754','2015-07-17 22:12:00.000',32,'Analogue','PM710: THD Current L3',0,'%'),(869,'PM1_7_THD_V1','PM710: THD Voltage L1',1,'2015-08-18 07:40:40.770','2015-07-17 22:12:00.000',32,'Analogue','PM710: THD Voltage L1',0,'%'),(870,'PM1_7_THD_V2','PM710: THD Voltage L2',1,'2015-08-18 07:40:40.770','2015-07-17 22:12:00.000',32,'Analogue','PM710: THD Voltage L2',0,'%'),(871,'PM1_7_THD_V3','PM710: THD Voltage L3',1,'2015-08-18 07:40:40.785','2015-07-17 22:12:00.000',32,'Analogue','PM710: THD Voltage L3',0,'%'),(872,'PM1_7_THD_V12','PM710: THD Voltage L12',1,'2015-08-18 07:40:40.801','2015-07-17 22:12:00.000',32,'Analogue','PM710: THD Voltage L12',0,'%'),(873,'PM1_7_THD_V23','PM710: THD Voltage L23',1,'2015-08-18 07:40:40.817','2015-07-17 22:12:00.000',32,'Analogue','PM710: THD Voltage L23',0,'%'),(874,'PM1_7_THD_V31','PM710: THD Voltage L31',1,'2015-08-18 07:40:40.817','2015-07-17 22:12:00.000',32,'Analogue','PM710: THD Voltage L31',0,'%'),(875,'PM1_7_Hour','PM710: Hour',1,'2015-08-18 07:40:40.832','2015-07-17 22:12:00.000',32,'Analogue','PM710: Hour',0,'Hour'),(876,'PM1_7_Min','PM710: Min',1,'2015-08-18 07:40:40.848','2015-07-17 22:12:00.000',32,'Analogue','PM710: Min',0,'Min'),(877,'OTB5_I0','MC CB 100A',1,'2015-08-18 07:40:40.863','2015-07-17 22:12:00.000',32,'Digital','MC CB 100A',0,'---'),(878,'OTB5_I2','MC CB 100A',1,'2015-08-18 07:40:40.879','2015-07-17 22:12:00.000',32,'Digital','MC CB 100A',0,'---'),(879,'OTB5_I6','MC CB 100A',1,'2015-08-18 07:40:40.879','2015-07-17 22:12:00.000',32,'Digital','MC CB 100A',0,'---'),(880,'OTB12_I2','MC CB 100A',1,'2015-08-18 07:40:40.895','2015-07-17 22:12:00.000',32,'Digital','MC CB 100A',0,'---'),(881,'OTB12_I6','MC CB 100A',1,'2015-08-18 07:40:40.910','2015-07-17 22:12:00.000',32,'Digital','MC CB 100A',0,'---'),(882,'OTB6_I0','MC CB 100A',1,'2015-08-18 07:40:40.926','2015-07-17 22:12:00.000',32,'Digital','MC CB 100A',0,'---'),(883,'PM1_10_kWh','PM710: Energy',1,'2015-08-18 07:40:40.926','2015-07-17 22:12:00.000',41,'Analogue','PM710: Energy',0,'kWh'),(884,'PM1_10_pf','PM710: Power factor',1,'2015-08-18 07:40:40.942','2015-07-17 22:12:00.000',41,'Analogue','PM710: Power factor',0,'---'),(885,'PM1_10_kW','PM710: Power',1,'2015-08-18 07:40:40.957','2015-07-17 22:12:00.000',41,'Analogue','PM710: Power',0,'kW'),(886,'PM1_10_kVA','PM710: apparent power',1,'2015-08-18 07:40:40.973','2015-07-17 22:12:00.000',41,'Analogue','PM710: apparent power',0,'kVA'),(887,'PM1_10_F','PM710: Frequency',1,'2015-08-18 07:40:40.988','2015-07-17 22:12:00.000',41,'Analogue','PM710: Frequency',0,'Hz'),(888,'PM1_10_I1','PM710: Current L1',1,'2015-08-18 07:40:40.988','2015-07-17 22:12:00.000',41,'Analogue','PM710: Current L1',0,'A'),(889,'PM1_10_I2','PM710: Current L2',1,'2015-08-18 07:40:41.004','2015-07-17 22:12:00.000',41,'Analogue','PM710: Current L2',0,'A'),(890,'PM1_10_I3','PM710: Current L3',1,'2015-08-18 07:40:41.020','2015-07-17 22:12:00.000',41,'Analogue','PM710: Current L3',0,'A'),(891,'PM1_10_In','PM710: Current',1,'2015-08-18 07:40:41.035','2015-07-17 22:12:00.000',41,'Analogue','PM710: Current',0,'A'),(892,'PM1_10_V12','PM710: Voltage L12',1,'2015-08-18 07:40:41.051','2015-07-17 22:12:00.000',41,'Analogue','PM710: Voltage L12',0,'V'),(893,'PM1_10_V23','PM710: Voltage L23',1,'2015-08-18 07:40:41.051','2015-07-17 22:12:00.000',41,'Analogue','PM710: Voltage L23',0,'V'),(894,'PM1_10_V31','PM710: Voltage L31',1,'2015-08-18 07:40:41.067','2015-07-17 22:12:00.000',41,'Analogue','PM710: Voltage L31',0,'V'),(895,'PM1_10_V1','PM710: Voltage L1',1,'2015-08-18 07:40:41.082','2015-07-17 22:12:00.000',41,'Analogue','PM710: Voltage L1',0,'V'),(896,'PM1_10_V2','PM710: Voltage L2',1,'2015-08-18 07:40:41.098','2015-07-17 22:12:00.000',41,'Analogue','PM710: Voltage L2',0,'V'),(897,'PM1_10_V3','PM710: Voltage L3',1,'2015-08-18 07:40:41.113','2015-07-17 22:12:00.000',41,'Analogue','PM710: Voltage L3',0,'V'),(898,'PM1_10_kW1','PM710: Power L1',1,'2015-08-18 07:40:41.113','2015-07-17 22:12:00.000',41,'Analogue','PM710: Power L1',0,'kW'),(899,'PM1_10_kW2','PM710: Power L2',1,'2015-08-18 07:40:41.129','2015-07-17 22:12:00.000',41,'Analogue','PM710: Power L2',0,'kW'),(900,'PM1_10_kW3','PM710: Power L3',1,'2015-08-18 07:40:41.145','2015-07-17 22:12:00.000',41,'Analogue','PM710: Power L3',0,'kW'),(901,'PM1_10_kVA1','PM710: apparent power L1',1,'2015-08-18 07:40:41.160','2015-07-17 22:12:00.000',41,'Analogue','PM710: apparent power L1',0,'kVA'),(902,'PM1_10_kVA2','PM710: apparent power L2',1,'2015-08-18 07:40:41.160','2015-07-17 22:12:00.000',41,'Analogue','PM710: apparent power L2',0,'kVA'),(903,'PM1_10_kVA3','PM710: apparent power L3',1,'2015-08-18 07:40:41.176','2015-07-17 22:12:00.000',41,'Analogue','PM710: apparent power L3',0,'kVA'),(904,'PM1_10_THD_I1','PM710: THD Current L1',1,'2015-08-18 07:40:41.192','2015-07-17 22:12:00.000',41,'Analogue','PM710: THD Current L1',0,'%'),(905,'PM1_10_THD_I2','PM710: THD Current L2',1,'2015-08-18 07:40:41.207','2015-07-17 22:12:00.000',41,'Analogue','PM710: THD Current L2',0,'%'),(906,'PM1_10_THD_I3','PM710: THD Current L3',1,'2015-08-18 07:40:41.223','2015-07-17 22:12:00.000',41,'Analogue','PM710: THD Current L3',0,'%'),(907,'PM1_10_THD_V1','PM710: THD Voltage L1',1,'2015-08-18 07:40:41.238','2015-07-17 22:12:00.000',41,'Analogue','PM710: THD Voltage L1',0,'%'),(908,'PM1_10_THD_V2','PM710: THD Voltage L2',1,'2015-08-18 07:40:41.238','2015-07-17 22:12:00.000',41,'Analogue','PM710: THD Voltage L2',0,'%'),(909,'PM1_10_THD_V3','PM710: THD Voltage L3',1,'2015-08-18 07:40:41.254','2015-07-17 22:12:00.000',41,'Analogue','PM710: THD Voltage L3',0,'%'),(910,'PM1_10_THD_V12','PM710: THD Voltage L12',1,'2015-08-18 07:40:41.270','2015-07-17 22:12:00.000',41,'Analogue','PM710: THD Voltage L12',0,'%'),(911,'PM1_10_THD_V23','PM710: THD Voltage L23',1,'2015-08-18 07:40:41.285','2015-07-17 22:12:00.000',41,'Analogue','PM710: THD Voltage L23',0,'%'),(912,'PM1_10_THD_V31','PM710: THD Voltage L31',1,'2015-08-18 07:40:41.301','2015-07-17 22:12:00.000',41,'Analogue','PM710: THD Voltage L31',0,'%'),(913,'PM1_10_Hour','PM710: Hour',1,'2015-08-18 07:40:41.301','2015-07-17 22:12:00.000',41,'Analogue','PM710: Hour',0,'Hour'),(914,'PM1_10_Min','PM710: Min',1,'2015-08-18 07:40:41.317','2015-07-17 22:12:00.000',41,'Analogue','PM710: Min',0,'Min'),(915,'PM1_1_kWh','PM710: Energy',1,'2015-08-18 07:40:41.332','2015-07-17 22:12:00.000',35,'Analogue','PM710: Energy',0,'kWh'),(916,'PM1_1_pf','PM710: Power factor',1,'2015-08-18 07:40:41.348','2015-07-17 22:12:00.000',35,'Analogue','PM710: Power factor',0,'---'),(917,'PM1_1_kW','PM710: Power',1,'2015-08-18 07:40:41.363','2015-07-17 22:12:00.000',35,'Analogue','PM710: Power',0,'kW'),(918,'PM1_1_kVA','PM710: apparent power',1,'2015-08-18 07:40:41.363','2015-07-17 22:12:00.000',35,'Analogue','PM710: apparent power',0,'kVA'),(919,'PM1_1_F','PM710: Frequency',1,'2015-08-18 07:40:41.379','2015-07-17 22:12:00.000',35,'Analogue','PM710: Frequency',0,'Hz'),(920,'PM1_1_I1','PM710: Current L1',1,'2015-08-18 07:40:41.395','2015-07-17 22:12:00.000',35,'Analogue','PM710: Current L1',0,'A'),(921,'PM1_1_I2','PM710: Current L2',1,'2015-08-18 07:40:41.410','2015-07-17 22:12:00.000',35,'Analogue','PM710: Current L2',0,'A'),(922,'PM1_1_I3','PM710: Current L3',1,'2015-08-18 07:40:41.426','2015-07-17 22:12:00.000',35,'Analogue','PM710: Current L3',0,'A'),(923,'PM1_1_In','PM710: Current',1,'2015-08-18 07:40:41.426','2015-07-17 22:12:00.000',35,'Analogue','PM710: Current',0,'A'),(924,'PM1_1_V12','PM710: Voltage L12',1,'2015-08-18 07:40:41.442','2015-07-17 22:12:00.000',35,'Analogue','PM710: Voltage L12',0,'V'),(925,'PM1_1_V23','PM710: Voltage L23',1,'2015-08-18 07:40:41.457','2015-07-17 22:12:00.000',35,'Analogue','PM710: Voltage L23',0,'V'),(926,'PM1_1_V31','PM710: Voltage L31',1,'2015-08-18 07:40:41.473','2015-07-17 22:12:00.000',35,'Analogue','PM710: Voltage L31',0,'V'),(927,'PM1_1_V1','PM710: Voltage L1',1,'2015-08-18 07:40:41.473','2015-07-17 22:12:00.000',35,'Analogue','PM710: Voltage L1',0,'V'),(928,'PM1_1_V2','PM710: Voltage L2',1,'2015-08-18 07:40:41.488','2015-07-17 22:12:00.000',35,'Analogue','PM710: Voltage L2',0,'V'),(929,'PM1_1_V3','PM710: Voltage L3',1,'2015-08-18 07:40:41.504','2015-07-17 22:12:00.000',35,'Analogue','PM710: Voltage L3',0,'V'),(930,'PM1_1_kW1','PM710: Power L1',1,'2015-08-18 07:40:41.520','2015-07-17 22:12:00.000',35,'Analogue','PM710: Power L1',0,'kW'),(931,'PM1_1_kW2','PM710: Power L2',1,'2015-08-18 07:40:41.535','2015-07-17 22:12:00.000',35,'Analogue','PM710: Power L2',0,'kW'),(932,'PM1_1_kW3','PM710: Power L3',1,'2015-08-18 07:40:41.535','2015-07-17 22:12:00.000',35,'Analogue','PM710: Power L3',0,'kW'),(933,'PM1_1_kVA1','PM710: apparent power L1',1,'2015-08-18 07:40:41.551','2015-07-17 22:12:00.000',35,'Analogue','PM710: apparent power L1',0,'kVA'),(934,'PM1_1_kVA2','PM710: apparent power L2',1,'2015-08-18 07:40:41.567','2015-07-17 22:12:00.000',35,'Analogue','PM710: apparent power L2',0,'kVA'),(935,'PM1_1_kVA3','PM710: apparent power L3',1,'2015-08-18 07:40:41.582','2015-07-17 22:12:00.000',35,'Analogue','PM710: apparent power L3',0,'kVA'),(936,'PM1_1_THD_I1','PM710: THD Current L1',1,'2015-08-18 07:40:41.598','2015-07-17 22:12:00.000',35,'Analogue','PM710: THD Current L1',0,'%'),(937,'PM1_1_THD_I2','PM710: THD Current L2',1,'2015-08-18 07:40:41.598','2015-07-17 22:12:00.000',35,'Analogue','PM710: THD Current L2',0,'%'),(938,'PM1_1_THD_I3','PM710: THD Current L3',1,'2015-08-18 07:40:41.613','2015-07-17 22:12:00.000',35,'Analogue','PM710: THD Current L3',0,'%'),(939,'PM1_1_THD_V1','PM710: THD Voltage L1',1,'2015-08-18 07:40:41.629','2015-07-17 22:12:00.000',35,'Analogue','PM710: THD Voltage L1',0,'%'),(940,'PM1_1_THD_V2','PM710: THD Voltage L2',1,'2015-08-18 07:40:41.645','2015-07-17 22:12:00.000',35,'Analogue','PM710: THD Voltage L2',0,'%'),(941,'PM1_1_THD_V3','PM710: THD Voltage L3',1,'2015-08-18 07:40:41.660','2015-07-17 22:12:00.000',35,'Analogue','PM710: THD Voltage L3',0,'%'),(942,'PM1_1_THD_V12','PM710: THD Voltage L12',1,'2015-08-18 07:40:41.660','2015-07-17 22:12:00.000',35,'Analogue','PM710: THD Voltage L12',0,'%'),(943,'PM1_1_THD_V23','PM710: THD Voltage L23',1,'2015-08-18 07:40:41.692','2015-07-17 22:12:00.000',35,'Analogue','PM710: THD Voltage L23',0,'%'),(944,'PM1_1_THD_V31','PM710: THD Voltage L31',1,'2015-08-18 07:40:41.707','2015-07-17 22:12:00.000',35,'Analogue','PM710: THD Voltage L31',0,'%'),(945,'PM1_1_Hour','PM710: Hour',1,'2015-08-18 07:40:41.723','2015-07-17 22:12:00.000',35,'Analogue','PM710: Hour',0,'Hour'),(946,'PM1_1_Min','PM710: Min',1,'2015-08-18 07:40:41.738','2015-07-17 22:12:00.000',35,'Analogue','PM710: Min',0,'Min'),(947,'PM1_2_kWh','PM710: Energy',1,'2015-08-18 07:40:41.754','2015-07-17 22:12:00.000',35,'Analogue','PM710: Energy',0,'kWh'),(948,'PM1_2_pf','PM710: Power factor',1,'2015-08-18 07:40:41.754','2015-07-17 22:12:00.000',35,'Analogue','PM710: Power factor',0,'---'),(949,'PM1_2_kW','PM710: Power',1,'2015-08-18 07:40:41.770','2015-07-17 22:12:00.000',35,'Analogue','PM710: Power',0,'kW'),(950,'PM1_2_kVA','PM710: apparent power',1,'2015-08-18 07:40:41.785','2015-07-17 22:12:00.000',35,'Analogue','PM710: apparent power',0,'kVA'),(951,'PM1_2_F','PM710: Frequency',1,'2015-08-18 07:40:41.801','2015-07-17 22:12:00.000',35,'Analogue','PM710: Frequency',0,'Hz'),(952,'PM1_2_I1','PM710: Current L1',1,'2015-08-18 07:40:41.817','2015-07-17 22:12:00.000',35,'Analogue','PM710: Current L1',0,'A'),(953,'PM1_2_I2','PM710: Current L2',1,'2015-08-18 07:40:41.817','2015-07-17 22:12:00.000',35,'Analogue','PM710: Current L2',0,'A'),(954,'PM1_2_I3','PM710: Current L3',1,'2015-08-18 07:40:41.832','2015-07-17 22:12:00.000',35,'Analogue','PM710: Current L3',0,'A'),(955,'PM1_2_In','PM710: Current',1,'2015-08-18 07:40:41.848','2015-07-17 22:12:00.000',35,'Analogue','PM710: Current',0,'A'),(956,'PM1_2_V12','PM710: Voltage L12',1,'2015-08-18 07:40:41.863','2015-07-17 22:12:00.000',35,'Analogue','PM710: Voltage L12',0,'V'),(957,'PM1_2_V23','PM710: Voltage L23',1,'2015-08-18 07:40:41.879','2015-07-17 22:12:00.000',35,'Analogue','PM710: Voltage L23',0,'V'),(958,'PM1_2_V31','PM710: Voltage L31',1,'2015-08-18 07:40:41.879','2015-07-17 22:12:00.000',35,'Analogue','PM710: Voltage L31',0,'V'),(959,'PM1_2_V1','PM710: Voltage L1',1,'2015-08-18 07:40:41.895','2015-07-17 22:12:00.000',35,'Analogue','PM710: Voltage L1',0,'V'),(960,'PM1_2_V2','PM710: Voltage L2',1,'2015-08-18 07:40:41.910','2015-07-17 22:12:00.000',35,'Analogue','PM710: Voltage L2',0,'V'),(961,'PM1_2_V3','PM710: Voltage L3',1,'2015-08-18 07:40:41.926','2015-07-17 22:12:00.000',35,'Analogue','PM710: Voltage L3',0,'V'),(962,'PM1_2_kW1','PM710: Power L1',1,'2015-08-18 07:40:41.942','2015-07-17 22:12:00.000',35,'Analogue','PM710: Power L1',0,'kW'),(963,'PM1_2_kW2','PM710: Power L2',1,'2015-08-18 07:40:41.942','2015-07-17 22:12:00.000',35,'Analogue','PM710: Power L2',0,'kW'),(964,'PM1_2_kW3','PM710: Power L3',1,'2015-08-18 07:40:41.957','2015-07-17 22:12:00.000',35,'Analogue','PM710: Power L3',0,'kW'),(965,'PM1_2_kVA1','PM710: apparent power L1',1,'2015-08-18 07:40:41.973','2015-07-17 22:12:00.000',35,'Analogue','PM710: apparent power L1',0,'kVA'),(966,'PM1_2_kVA2','PM710: apparent power L2',1,'2015-08-18 07:40:41.988','2015-07-17 22:12:00.000',35,'Analogue','PM710: apparent power L2',0,'kVA'),(967,'PM1_2_kVA3','PM710: apparent power L3',1,'2015-08-18 07:40:42.004','2015-07-17 22:12:00.000',35,'Analogue','PM710: apparent power L3',0,'kVA'),(968,'PM1_2_THD_I1','PM710: THD Current L1',1,'2015-08-18 07:40:42.004','2015-07-17 22:12:00.000',35,'Analogue','PM710: THD Current L1',0,'%'),(969,'PM1_2_THD_I2','PM710: THD Current L2',1,'2015-08-18 07:40:42.020','2015-07-17 22:12:00.000',35,'Analogue','PM710: THD Current L2',0,'%'),(970,'PM1_2_THD_I3','PM710: THD Current L3',1,'2015-08-18 07:40:42.035','2015-07-17 22:12:00.000',35,'Analogue','PM710: THD Current L3',0,'%'),(971,'PM1_2_THD_V1','PM710: THD Voltage L1',1,'2015-08-18 07:40:42.051','2015-07-17 22:12:00.000',35,'Analogue','PM710: THD Voltage L1',0,'%'),(972,'PM1_2_THD_V2','PM710: THD Voltage L2',1,'2015-08-18 07:40:42.067','2015-07-17 22:12:00.000',35,'Analogue','PM710: THD Voltage L2',0,'%'),(973,'PM1_2_THD_V3','PM710: THD Voltage L3',1,'2015-08-18 07:40:42.067','2015-07-17 22:12:00.000',35,'Analogue','PM710: THD Voltage L3',0,'%'),(974,'PM1_2_THD_V12','PM710: THD Voltage L12',1,'2015-08-18 07:40:42.082','2015-07-17 22:12:00.000',35,'Analogue','PM710: THD Voltage L12',0,'%'),(975,'PM1_2_THD_V23','PM710: THD Voltage L23',1,'2015-08-18 07:40:42.098','2015-07-17 22:12:00.000',35,'Analogue','PM710: THD Voltage L23',0,'%'),(976,'PM1_2_THD_V31','PM710: THD Voltage L31',1,'2015-08-18 07:40:42.113','2015-07-17 22:12:00.000',35,'Analogue','PM710: THD Voltage L31',0,'%'),(977,'PM1_2_Hour','PM710: Hour',1,'2015-08-18 07:40:42.129','2015-07-17 22:12:00.000',35,'Analogue','PM710: Hour',0,'Hour'),(978,'PM1_2_Min','PM710: Min',1,'2015-08-18 07:40:42.129','2015-07-17 22:12:00.000',35,'Analogue','PM710: Min',0,'Min'),(979,'PM1_5_kWh','PM710: Energy',1,'2015-08-18 07:40:42.145','2015-07-17 22:12:00.000',37,'Analogue','PM710: Energy',0,'kWh'),(980,'PM1_5_pf','PM710: Power factor',1,'2015-08-18 07:40:42.160','2015-07-17 22:12:00.000',37,'Analogue','PM710: Power factor',0,'---'),(981,'PM1_5_kW','PM710: Power',1,'2015-08-18 07:40:42.176','2015-07-17 22:12:00.000',37,'Analogue','PM710: Power',0,'kW'),(982,'PM1_5_kVA','PM710: apparent power',1,'2015-08-18 07:40:42.192','2015-07-17 22:12:00.000',37,'Analogue','PM710: apparent power',0,'kVA'),(983,'PM1_5_F','PM710: Frequency',1,'2015-08-18 07:40:42.192','2015-07-17 22:12:00.000',37,'Analogue','PM710: Frequency',0,'Hz'),(984,'PM1_5_I1','PM710: Current L1',1,'2015-08-18 07:40:42.207','2015-07-17 22:12:00.000',37,'Analogue','PM710: Current L1',0,'A'),(985,'PM1_5_I2','PM710: Current L2',1,'2015-08-18 07:40:42.223','2015-07-17 22:12:00.000',37,'Analogue','PM710: Current L2',0,'A'),(986,'PM1_5_I3','PM710: Current L3',1,'2015-08-18 07:40:42.238','2015-07-17 22:12:00.000',37,'Analogue','PM710: Current L3',0,'A'),(987,'PM1_5_In','PM710: Current',1,'2015-08-18 07:40:42.254','2015-07-17 22:12:00.000',37,'Analogue','PM710: Current',0,'A'),(988,'PM1_5_V12','PM710: Voltage L12',1,'2015-08-18 07:40:42.254','2015-07-17 22:12:00.000',37,'Analogue','PM710: Voltage L12',0,'V'),(989,'PM1_5_V23','PM710: Voltage L23',1,'2015-08-18 07:40:42.270','2015-07-17 22:12:00.000',37,'Analogue','PM710: Voltage L23',0,'V'),(990,'PM1_5_V31','PM710: Voltage L31',1,'2015-08-18 07:40:42.285','2015-07-17 22:12:00.000',37,'Analogue','PM710: Voltage L31',0,'V'),(991,'PM1_5_V1','PM710: Voltage L1',1,'2015-08-18 07:40:42.301','2015-07-17 22:12:00.000',37,'Analogue','PM710: Voltage L1',0,'V'),(992,'PM1_5_V2','PM710: Voltage L2',1,'2015-08-18 07:40:42.301','2015-07-17 22:12:00.000',37,'Analogue','PM710: Voltage L2',0,'V'),(993,'PM1_5_V3','PM710: Voltage L3',1,'2015-08-18 07:40:42.317','2015-07-17 22:12:00.000',37,'Analogue','PM710: Voltage L3',0,'V'),(994,'PM1_5_kW1','PM710: Power L1',1,'2015-08-18 07:40:42.332','2015-07-17 22:12:00.000',37,'Analogue','PM710: Power L1',0,'kW'),(995,'PM1_5_kW2','PM710: Power L2',1,'2015-08-18 07:40:42.348','2015-07-17 22:12:00.000',37,'Analogue','PM710: Power L2',0,'kW'),(996,'PM1_5_kW3','PM710: Power L3',1,'2015-08-18 07:40:42.363','2015-07-17 22:12:00.000',37,'Analogue','PM710: Power L3',0,'kW'),(997,'PM1_5_kVA1','PM710: apparent power L1',1,'2015-08-18 07:40:42.363','2015-07-17 22:12:00.000',37,'Analogue','PM710: apparent power L1',0,'kVA'),(998,'PM1_5_kVA2','PM710: apparent power L2',1,'2015-08-18 07:40:42.379','2015-07-17 22:12:00.000',37,'Analogue','PM710: apparent power L2',0,'kVA'),(999,'PM1_5_kVA3','PM710: apparent power L3',1,'2015-08-18 07:40:42.395','2015-07-17 22:12:00.000',37,'Analogue','PM710: apparent power L3',0,'kVA'),(1000,'PM1_5_THD_I1','PM710: THD Current L1',1,'2015-08-18 07:40:42.410','2015-07-17 22:12:00.000',37,'Analogue','PM710: THD Current L1',0,'%'),(1001,'PM1_5_THD_I2','PM710: THD Current L2',1,'2015-08-18 07:40:42.426','2015-07-17 22:12:00.000',37,'Analogue','PM710: THD Current L2',0,'%'),(1002,'PM1_5_THD_I3','PM710: THD Current L3',1,'2015-08-18 07:40:42.426','2015-07-17 22:12:00.000',37,'Analogue','PM710: THD Current L3',0,'%'),(1003,'PM1_5_THD_V1','PM710: THD Voltage L1',1,'2015-08-18 07:40:42.442','2015-07-17 22:12:00.000',37,'Analogue','PM710: THD Voltage L1',0,'%'),(1004,'PM1_5_THD_V2','PM710: THD Voltage L2',1,'2015-08-18 07:40:42.457','2015-07-17 22:12:00.000',37,'Analogue','PM710: THD Voltage L2',0,'%'),(1005,'PM1_5_THD_V3','PM710: THD Voltage L3',1,'2015-08-18 07:40:42.473','2015-07-17 22:12:00.000',37,'Analogue','PM710: THD Voltage L3',0,'%'),(1006,'PM1_5_THD_V12','PM710: THD Voltage L12',1,'2015-08-18 07:40:42.488','2015-07-17 22:12:00.000',37,'Analogue','PM710: THD Voltage L12',0,'%'),(1007,'PM1_5_THD_V23','PM710: THD Voltage L23',1,'2015-08-18 07:40:42.488','2015-07-17 22:12:00.000',37,'Analogue','PM710: THD Voltage L23',0,'%'),(1008,'PM1_5_THD_V31','PM710: THD Voltage L31',1,'2015-08-18 07:40:42.504','2015-07-17 22:12:00.000',37,'Analogue','PM710: THD Voltage L31',0,'%'),(1009,'PM1_5_Hour','PM710: Hour',1,'2015-08-18 07:40:42.520','2015-07-17 22:12:00.000',37,'Analogue','PM710: Hour',0,'Hour'),(1010,'PM1_5_Min','PM710: Min',1,'2015-08-18 07:40:42.535','2015-07-17 22:12:00.000',37,'Analogue','PM710: Min',0,'Min'),(1011,'PM1_3_kWh','PM710: Energy',1,'2015-08-18 07:40:42.551','2015-07-17 22:12:00.000',36,'Analogue','PM710: Energy',0,'kWh'),(1012,'PM1_3_pf','PM710: Power factor',1,'2015-08-18 07:40:42.551','2015-07-17 22:12:00.000',36,'Analogue','PM710: Power factor',0,'---'),(1013,'PM1_3_kW','PM710: Power',1,'2015-08-18 07:40:42.567','2015-07-17 22:12:00.000',36,'Analogue','PM710: Power',0,'kW'),(1014,'PM1_3_kVA','PM710: apparent power',1,'2015-08-18 07:40:42.582','2015-07-17 22:12:00.000',36,'Analogue','PM710: apparent power',0,'kVA'),(1015,'PM1_3_F','PM710: Frequency',1,'2015-08-18 07:40:42.598','2015-07-17 22:12:00.000',36,'Analogue','PM710: Frequency',0,'Hz'),(1016,'PM1_3_I1','PM710: Current L1',1,'2015-08-18 07:40:42.613','2015-07-17 22:12:00.000',36,'Analogue','PM710: Current L1',0,'A'),(1017,'PM1_3_I2','PM710: Current L2',1,'2015-08-18 07:40:42.613','2015-07-17 22:12:00.000',36,'Analogue','PM710: Current L2',0,'A'),(1018,'PM1_3_I3','PM710: Current L3',1,'2015-08-18 07:40:42.629','2015-07-17 22:12:00.000',36,'Analogue','PM710: Current L3',0,'A'),(1019,'PM1_3_In','PM710: Current',1,'2015-08-18 07:40:42.645','2015-07-17 22:12:00.000',36,'Analogue','PM710: Current',0,'A'),(1020,'PM1_3_V12','PM710: Voltage L12',1,'2015-08-18 07:40:42.660','2015-07-17 22:12:00.000',36,'Analogue','PM710: Voltage L12',0,'V'),(1021,'PM1_3_V23','PM710: Voltage L23',1,'2015-08-18 07:40:42.676','2015-07-17 22:12:00.000',36,'Analogue','PM710: Voltage L23',0,'V'),(1022,'PM1_3_V31','PM710: Voltage L31',1,'2015-08-18 07:40:42.676','2015-07-17 22:12:00.000',36,'Analogue','PM710: Voltage L31',0,'V'),(1023,'PM1_3_V1','PM710: Voltage L1',1,'2015-08-18 07:40:42.692','2015-07-17 22:12:00.000',36,'Analogue','PM710: Voltage L1',0,'V'),(1024,'PM1_3_V2','PM710: Voltage L2',1,'2015-08-18 07:40:42.707','2015-07-17 22:12:00.000',36,'Analogue','PM710: Voltage L2',0,'V'),(1025,'PM1_3_V3','PM710: Voltage L3',1,'2015-08-18 07:40:42.723','2015-07-17 22:12:00.000',36,'Analogue','PM710: Voltage L3',0,'V'),(1026,'PM1_3_kW1','PM710: Power L1',1,'2015-08-18 07:40:42.738','2015-07-17 22:12:00.000',36,'Analogue','PM710: Power L1',0,'kW'),(1027,'PM1_3_kW2','PM710: Power L2',1,'2015-08-18 07:40:42.738','2015-07-17 22:12:00.000',36,'Analogue','PM710: Power L2',0,'kW'),(1028,'PM1_3_kW3','PM710: Power L3',1,'2015-08-18 07:40:42.754','2015-07-17 22:12:00.000',36,'Analogue','PM710: Power L3',0,'kW'),(1029,'PM1_3_kVA1','PM710: apparent power L1',1,'2015-08-18 07:40:42.770','2015-07-17 22:12:00.000',36,'Analogue','PM710: apparent power L1',0,'kVA'),(1030,'PM1_3_kVA2','PM710: apparent power L2',1,'2015-08-18 07:40:42.785','2015-07-17 22:12:00.000',36,'Analogue','PM710: apparent power L2',0,'kVA'),(1031,'PM1_3_kVA3','PM710: apparent power L3',1,'2015-08-18 07:40:42.801','2015-07-17 22:12:00.000',36,'Analogue','PM710: apparent power L3',0,'kVA'),(1032,'PM1_3_THD_I1','PM710: THD Current L1',1,'2015-08-18 07:40:42.801','2015-07-17 22:12:00.000',36,'Analogue','PM710: THD Current L1',0,'%'),(1033,'PM1_3_THD_I2','PM710: THD Current L2',1,'2015-08-18 07:40:42.817','2015-07-17 22:12:00.000',36,'Analogue','PM710: THD Current L2',0,'%'),(1034,'PM1_3_THD_I3','PM710: THD Current L3',1,'2015-08-18 07:40:42.832','2015-07-17 22:12:00.000',36,'Analogue','PM710: THD Current L3',0,'%'),(1035,'PM1_3_THD_V1','PM710: THD Voltage L1',1,'2015-08-18 07:40:42.848','2015-07-17 22:12:00.000',36,'Analogue','PM710: THD Voltage L1',0,'%'),(1036,'PM1_3_THD_V2','PM710: THD Voltage L2',1,'2015-08-18 07:40:42.863','2015-07-17 22:12:00.000',36,'Analogue','PM710: THD Voltage L2',0,'%'),(1037,'PM1_3_THD_V3','PM710: THD Voltage L3',1,'2015-08-18 07:40:42.863','2015-07-17 22:12:00.000',36,'Analogue','PM710: THD Voltage L3',0,'%'),(1038,'PM1_3_THD_V12','PM710: THD Voltage L12',1,'2015-08-18 07:40:42.879','2015-07-17 22:12:00.000',36,'Analogue','PM710: THD Voltage L12',0,'%'),(1039,'PM1_3_THD_V23','PM710: THD Voltage L23',1,'2015-08-18 07:40:42.895','2015-07-17 22:12:00.000',36,'Analogue','PM710: THD Voltage L23',0,'%'),(1040,'PM1_3_THD_V31','PM710: THD Voltage L31',1,'2015-08-18 07:40:42.910','2015-07-17 22:12:00.000',36,'Analogue','PM710: THD Voltage L31',0,'%'),(1041,'PM1_3_Hour','PM710: Hour',1,'2015-08-18 07:40:42.926','2015-07-17 22:12:00.000',36,'Analogue','PM710: Hour',0,'Hour'),(1042,'PM1_3_Min','PM710: Min',1,'2015-08-18 07:40:42.926','2015-07-17 22:12:00.000',36,'Analogue','PM710: Min',0,'Min'),(1043,'PM1_4_kWh','PM710: Energy',1,'2015-08-18 07:40:42.942','2015-07-17 22:12:00.000',36,'Analogue','PM710: Energy',0,'kWh'),(1044,'PM1_4_pf','PM710: Power factor',1,'2015-08-18 07:40:42.957','2015-07-17 22:12:00.000',36,'Analogue','PM710: Power factor',0,'---'),(1045,'PM1_4_kW','PM710: Power',1,'2015-08-18 07:40:42.973','2015-07-17 22:12:00.000',36,'Analogue','PM710: Power',0,'kW'),(1046,'PM1_4_kVA','PM710: apparent power',1,'2015-08-18 07:40:42.988','2015-07-17 22:12:00.000',36,'Analogue','PM710: apparent power',0,'kVA'),(1047,'PM1_4_F','PM710: Frequency',1,'2015-08-18 07:40:42.988','2015-07-17 22:12:00.000',36,'Analogue','PM710: Frequency',0,'Hz'),(1048,'PM1_4_I1','PM710: Current L1',1,'2015-08-18 07:40:43.004','2015-07-17 22:12:00.000',36,'Analogue','PM710: Current L1',0,'A'),(1049,'PM1_4_I2','PM710: Current L2',1,'2015-08-18 07:40:43.020','2015-07-17 22:12:00.000',36,'Analogue','PM710: Current L2',0,'A'),(1050,'PM1_4_I3','PM710: Current L3',1,'2015-08-18 07:40:43.035','2015-07-17 22:12:00.000',36,'Analogue','PM710: Current L3',0,'A'),(1051,'PM1_4_In','PM710: Current',1,'2015-08-18 07:40:43.035','2015-07-17 22:12:00.000',36,'Analogue','PM710: Current',0,'A'),(1052,'PM1_4_V12','PM710: Voltage L12',1,'2015-08-18 07:40:43.051','2015-07-17 22:12:00.000',36,'Analogue','PM710: Voltage L12',0,'V'),(1053,'PM1_4_V23','PM710: Voltage L23',1,'2015-08-18 07:40:43.067','2015-07-17 22:12:00.000',36,'Analogue','PM710: Voltage L23',0,'V'),(1054,'PM1_4_V31','PM710: Voltage L31',1,'2015-08-18 07:40:43.082','2015-07-17 22:12:00.000',36,'Analogue','PM710: Voltage L31',0,'V'),(1055,'PM1_4_V1','PM710: Voltage L1',1,'2015-08-18 07:40:43.098','2015-07-17 22:12:00.000',36,'Analogue','PM710: Voltage L1',0,'V'),(1056,'PM1_4_V2','PM710: Voltage L2',1,'2015-08-18 07:40:43.098','2015-07-17 22:12:00.000',36,'Analogue','PM710: Voltage L2',0,'V'),(1057,'PM1_4_V3','PM710: Voltage L3',1,'2015-08-18 07:40:43.113','2015-07-17 22:12:00.000',36,'Analogue','PM710: Voltage L3',0,'V'),(1058,'PM1_4_kW1','PM710: Power L1',1,'2015-08-18 07:40:43.129','2015-07-17 22:12:00.000',36,'Analogue','PM710: Power L1',0,'kW'),(1059,'PM1_4_kW2','PM710: Power L2',1,'2015-08-18 07:40:43.145','2015-07-17 22:12:00.000',36,'Analogue','PM710: Power L2',0,'kW'),(1060,'PM1_4_kW3','PM710: Power L3',1,'2015-08-18 07:40:43.160','2015-07-17 22:12:00.000',36,'Analogue','PM710: Power L3',0,'kW'),(1061,'PM1_4_kVA1','PM710: apparent power L1',1,'2015-08-18 07:40:43.160','2015-07-17 22:12:00.000',36,'Analogue','PM710: apparent power L1',0,'kVA'),(1062,'PM1_4_kVA2','PM710: apparent power L2',1,'2015-08-18 07:40:43.176','2015-07-17 22:12:00.000',36,'Analogue','PM710: apparent power L2',0,'kVA'),(1063,'PM1_4_kVA3','PM710: apparent power L3',1,'2015-08-18 07:40:43.192','2015-07-17 22:12:00.000',36,'Analogue','PM710: apparent power L3',0,'kVA'),(1064,'PM1_4_THD_I1','PM710: THD Current L1',1,'2015-08-18 07:40:43.207','2015-07-17 22:12:00.000',36,'Analogue','PM710: THD Current L1',0,'%'),(1065,'PM1_4_THD_I2','PM710: THD Current L2',1,'2015-08-18 07:40:43.223','2015-07-17 22:12:00.000',36,'Analogue','PM710: THD Current L2',0,'%'),(1066,'PM1_4_THD_I3','PM710: THD Current L3',1,'2015-08-18 07:40:43.223','2015-07-17 22:12:00.000',36,'Analogue','PM710: THD Current L3',0,'%'),(1067,'PM1_4_THD_V1','PM710: THD Voltage L1',1,'2015-08-18 07:40:43.238','2015-07-17 22:12:00.000',36,'Analogue','PM710: THD Voltage L1',0,'%'),(1068,'PM1_4_THD_V2','PM710: THD Voltage L2',1,'2015-08-18 07:40:43.332','2015-07-17 22:12:00.000',36,'Analogue','PM710: THD Voltage L2',0,'%'),(1069,'PM1_4_THD_V3','PM710: THD Voltage L3',1,'2015-08-18 07:40:43.348','2015-07-17 22:12:00.000',36,'Analogue','PM710: THD Voltage L3',0,'%'),(1070,'PM1_4_THD_V12','PM710: THD Voltage L12',1,'2015-08-18 07:40:43.363','2015-07-17 22:12:00.000',36,'Analogue','PM710: THD Voltage L12',0,'%'),(1071,'PM1_4_THD_V23','PM710: THD Voltage L23',1,'2015-08-18 07:40:43.363','2015-07-17 22:12:00.000',36,'Analogue','PM710: THD Voltage L23',0,'%'),(1072,'PM1_4_THD_V31','PM710: THD Voltage L31',1,'2015-08-18 07:40:43.379','2015-07-17 22:12:00.000',36,'Analogue','PM710: THD Voltage L31',0,'%'),(1073,'PM1_4_Hour','PM710: Hour',1,'2015-08-18 07:40:43.395','2015-07-17 22:12:00.000',36,'Analogue','PM710: Hour',0,'Hour'),(1074,'PM1_4_Min','PM710: Min',1,'2015-08-18 07:40:43.410','2015-07-17 22:12:00.000',36,'Analogue','PM710: Min',0,'Min'),(1075,'PM1_6_kWh','PM710: Energy',1,'2015-08-18 07:40:43.426','2015-07-17 22:12:00.000',38,'Analogue','PM710: Energy',0,'kWh'),(1076,'PM1_6_pf','PM710: Power factor',1,'2015-08-18 07:40:43.426','2015-07-17 22:12:00.000',38,'Analogue','PM710: Power factor',0,'---'),(1077,'PM1_6_kW','PM710: Power',1,'2015-08-18 07:40:43.442','2015-07-17 22:12:00.000',38,'Analogue','PM710: Power',0,'kW'),(1078,'PM1_6_kVA','PM710: apparent power',1,'2015-08-18 07:40:43.457','2015-07-17 22:12:00.000',38,'Analogue','PM710: apparent power',0,'kVA'),(1079,'PM1_6_F','PM710: Frequency',1,'2015-08-18 07:40:43.473','2015-07-17 22:12:00.000',38,'Analogue','PM710: Frequency',0,'Hz'),(1080,'PM1_6_I1','PM710: Current L1',1,'2015-08-18 07:40:43.488','2015-07-17 22:12:00.000',38,'Analogue','PM710: Current L1',0,'A'),(1081,'PM1_6_I2','PM710: Current L2',1,'2015-08-18 07:40:43.488','2015-07-17 22:12:00.000',38,'Analogue','PM710: Current L2',0,'A'),(1082,'PM1_6_I3','PM710: Current L3',1,'2015-08-18 07:40:43.504','2015-07-17 22:12:00.000',38,'Analogue','PM710: Current L3',0,'A'),(1083,'PM1_6_In','PM710: Current',1,'2015-08-18 07:40:43.520','2015-07-17 22:12:00.000',38,'Analogue','PM710: Current',0,'A'),(1084,'PM1_6_V12','PM710: Voltage L12',1,'2015-08-18 07:40:43.535','2015-07-17 22:12:00.000',38,'Analogue','PM710: Voltage L12',0,'V'),(1085,'PM1_6_V23','PM710: Voltage L23',1,'2015-08-18 07:40:43.551','2015-07-17 22:12:00.000',38,'Analogue','PM710: Voltage L23',0,'V'),(1086,'PM1_6_V31','PM710: Voltage L31',1,'2015-08-18 07:40:43.551','2015-07-17 22:12:00.000',38,'Analogue','PM710: Voltage L31',0,'V'),(1087,'PM1_6_V1','PM710: Voltage L1',1,'2015-08-18 07:40:43.582','2015-07-17 22:12:00.000',38,'Analogue','PM710: Voltage L1',0,'V'),(1088,'PM1_6_V2','PM710: Voltage L2',1,'2015-08-18 07:40:43.598','2015-07-17 22:12:00.000',38,'Analogue','PM710: Voltage L2',0,'V'),(1089,'PM1_6_V3','PM710: Voltage L3',1,'2015-08-18 07:40:43.613','2015-07-17 22:12:00.000',38,'Analogue','PM710: Voltage L3',0,'V'),(1090,'PM1_6_kW1','PM710: Power L1',1,'2015-08-18 07:40:43.613','2015-07-17 22:12:00.000',38,'Analogue','PM710: Power L1',0,'kW'),(1091,'PM1_6_kW2','PM710: Power L2',1,'2015-08-18 07:40:43.629','2015-07-17 22:12:00.000',38,'Analogue','PM710: Power L2',0,'kW'),(1092,'PM1_6_kW3','PM710: Power L3',1,'2015-08-18 07:40:43.645','2015-07-17 22:12:00.000',38,'Analogue','PM710: Power L3',0,'kW'),(1093,'PM1_6_kVA1','PM710: apparent power L1',1,'2015-08-18 07:40:43.660','2015-07-17 22:12:00.000',38,'Analogue','PM710: apparent power L1',0,'kVA'),(1094,'PM1_6_kVA2','PM710: apparent power L2',1,'2015-08-18 07:40:43.660','2015-07-17 22:12:00.000',38,'Analogue','PM710: apparent power L2',0,'kVA'),(1095,'PM1_6_kVA3','PM710: apparent power L3',1,'2015-08-18 07:40:43.676','2015-07-17 22:12:00.000',38,'Analogue','PM710: apparent power L3',0,'kVA'),(1096,'PM1_6_THD_I1','PM710: THD Current L1',1,'2015-08-18 07:40:43.692','2015-07-17 22:12:00.000',38,'Analogue','PM710: THD Current L1',0,'%'),(1097,'PM1_6_THD_I2','PM710: THD Current L2',1,'2015-08-18 07:40:43.707','2015-07-17 22:12:00.000',38,'Analogue','PM710: THD Current L2',0,'%'),(1098,'PM1_6_THD_I3','PM710: THD Current L3',1,'2015-08-18 07:40:43.723','2015-07-17 22:12:00.000',38,'Analogue','PM710: THD Current L3',0,'%'),(1099,'PM1_6_THD_V1','PM710: THD Voltage L1',1,'2015-08-18 07:40:43.723','2015-07-17 22:12:00.000',38,'Analogue','PM710: THD Voltage L1',0,'%'),(1100,'PM1_6_THD_V2','PM710: THD Voltage L2',1,'2015-08-18 07:40:43.738','2015-07-17 22:12:00.000',38,'Analogue','PM710: THD Voltage L2',0,'%'),(1101,'PM1_6_THD_V3','PM710: THD Voltage L3',1,'2015-08-18 07:40:43.754','2015-07-17 22:12:00.000',38,'Analogue','PM710: THD Voltage L3',0,'%'),(1102,'PM1_6_THD_V12','PM710: THD Voltage L12',1,'2015-08-18 07:40:43.770','2015-07-17 22:12:00.000',38,'Analogue','PM710: THD Voltage L12',0,'%'),(1103,'PM1_6_THD_V23','PM710: THD Voltage L23',1,'2015-08-18 07:40:43.785','2015-07-17 22:12:00.000',38,'Analogue','PM710: THD Voltage L23',0,'%'),(1104,'PM1_6_THD_V31','PM710: THD Voltage L31',1,'2015-08-18 07:40:43.801','2015-07-17 22:12:00.000',38,'Analogue','PM710: THD Voltage L31',0,'%'),(1105,'PM1_6_Hour','PM710: Hour',1,'2015-08-18 07:40:43.801','2015-07-17 22:12:00.000',38,'Analogue','PM710: Hour',0,'Hour'),(1106,'PM1_6_Min','PM710: Min',1,'2015-08-18 07:40:43.817','2015-07-17 22:12:00.000',38,'Analogue','PM710: Min',0,'Min'),(1107,'HSSD_channel0','HSSD:channel0',1,'2015-08-18 07:40:43.832','2015-07-17 22:12:00.000',98,'Analogue','HSSD:channel0',0,'---'),(1108,'HSSD_channel1','HSSD:channel1',1,'2015-08-18 07:40:43.848','2015-07-17 22:12:00.000',98,'Analogue','HSSD:channel1',0,'---'),(1109,'HSSD_channel2','HSSD:channel2',1,'2015-08-18 07:40:43.863','2015-07-17 22:12:00.000',98,'Analogue','HSSD:channel2',0,'---'),(1110,'HSSD_channel3','HSSD:channel3',1,'2015-08-18 07:40:43.863','2015-07-17 22:12:00.000',98,'Analogue','HSSD:channel3',0,'---'),(1111,'HSSD_channel4','HSSD:channel4',1,'2015-08-18 07:40:43.879','2015-07-17 22:12:00.000',98,'Analogue','HSSD:channel4',0,'---'),(1112,'HSSD_channel5','HSSD:channel5',1,'2015-08-18 07:40:43.895','2015-07-17 22:12:00.000',98,'Analogue','HSSD:channel5',0,'---'),(1113,'HSSD_channel6','HSSD:channel6',1,'2015-08-18 07:40:43.910','2015-07-17 22:12:00.000',98,'Analogue','HSSD:channel6',0,'---'),(1114,'HSSD_channel7','HSSD:channel7',1,'2015-08-18 07:40:43.910','2015-07-17 22:12:00.000',98,'Analogue','HSSD:channel7',0,'---'),(1115,'LASER_channel0','LASER: channel0',1,'2015-08-18 07:40:43.926','2015-07-17 22:12:00.000',101,'Analogue','LASER: channel0',0,'---'),(1116,'LASER_channel1','LASER: channel1',1,'2015-08-18 07:40:43.942','2015-07-17 22:12:00.000',101,'Analogue','LASER: channel1',0,'---'),(1117,'LASER_channel2','LASER: channel2',1,'2015-08-18 07:40:43.957','2015-07-17 22:12:00.000',101,'Analogue','LASER: channel2',0,'---'),(1118,'LASER_channel3','LASER: channel3',1,'2015-08-18 07:40:43.973','2015-07-17 22:12:00.000',101,'Analogue','LASER: channel3',0,'---'),(1119,'LASER_channel4','LASER: channel4',1,'2015-08-18 07:40:43.973','2015-07-17 22:12:00.000',101,'Analogue','LASER: channel4',0,'---'),(1120,'LASER_channel5','LASER: channel5',1,'2015-08-18 07:40:43.988','2015-07-17 22:12:00.000',101,'Analogue','LASER: channel5',0,'---'),(1121,'LASER_channel6','LASER: channel6',1,'2015-08-18 07:40:44.004','2015-07-17 22:12:00.000',101,'Analogue','LASER: channel6',0,'---'),(1122,'LASER_channel7','LASER: channel7',1,'2015-08-18 07:40:44.020','2015-07-17 22:12:00.000',101,'Analogue','LASER: channel7',0,'---'),(1123,'LLD_channel0','LLD: channel0',1,'2015-08-18 07:40:44.035','2015-07-17 22:12:00.000',99,'Analogue','LLD: channel0',0,'---'),(1124,'LLD_channel1','LLD: channel1',1,'2015-08-18 07:40:44.035','2015-07-17 22:12:00.000',99,'Analogue','LLD: channel1',0,'---'),(1125,'LLD_channel2','LLD: channel2',1,'2015-08-18 07:40:44.051','2015-07-17 22:12:00.000',99,'Analogue','LLD: channel2',0,'---'),(1126,'LLD_channel3','LLD: channel3',1,'2015-08-18 07:40:44.067','2015-07-17 22:12:00.000',99,'Analogue','LLD: channel3',0,'---'),(1127,'LLD_channel4','LLD: channel4',1,'2015-08-18 07:40:44.082','2015-07-17 22:12:00.000',99,'Analogue','LLD: channel4',0,'---'),(1128,'LLD_channel5','LLD: channel5',1,'2015-08-18 07:40:44.098','2015-07-17 22:12:00.000',99,'Analogue','LLD: channel5',0,'---'),(1129,'LLD_channel6','LLD: channel6',1,'2015-08-18 07:40:44.098','2015-07-17 22:12:00.000',99,'Analogue','LLD: channel6',0,'---'),(1130,'LLD_channel7','LLD: channel7',1,'2015-08-18 07:40:44.113','2015-07-17 22:12:00.000',99,'Analogue','LLD: channel7',0,'---'),(1131,'OTB1_IO','OTB1',1,'2015-08-18 07:40:44.129','2015-07-17 22:12:00.000',0,'Analogue','OTB1',0,'---'),(1132,'OTB2_IO','OTB2',1,'2015-08-18 07:40:44.145','2015-07-17 22:12:00.000',0,'Analogue','OTB2',0,'---'),(1133,'OTB3_IO','OTB3',1,'2015-08-18 07:40:44.160','2015-07-17 22:12:00.000',0,'Analogue','OTB3',0,'---'),(1134,'OTB4_IO','OTB4',1,'2015-08-18 07:40:44.160','2015-07-17 22:12:00.000',0,'Analogue','OTB4',0,'---'),(1135,'OTB5_IO','OTB5',1,'2015-08-18 07:40:44.176','2015-07-17 22:12:00.000',0,'Analogue','OTB5',0,'---'),(1136,'OTB6_IO','OTB6',1,'2015-08-18 07:40:44.192','2015-07-17 22:12:00.000',0,'Analogue','OTB6',0,'---'),(1137,'OTB7_IO','OTB7',1,'2015-08-18 07:40:44.207','2015-07-17 22:12:00.000',0,'Analogue','OTB7',0,'---'),(1138,'OTB8_IO','OTB8',1,'2015-08-18 07:40:44.223','2015-07-17 22:12:00.000',0,'Analogue','OTB8',0,'---'),(1139,'OTB9_IO','OTB9',1,'2015-08-18 07:40:44.223','2015-07-17 22:12:00.000',0,'Analogue','OTB9',0,'---'),(1140,'OTB10_IO','OTB10',1,'2015-08-18 07:40:44.238','2015-07-17 22:12:00.000',0,'Analogue','OTB10',0,'---'),(1141,'OTB11_IO','OTB11',1,'2015-08-18 07:40:44.254','2015-07-17 22:12:00.000',0,'Analogue','OTB11',0,'---'),(1142,'OTB12_IO','OTB12',1,'2015-08-18 07:40:44.270','2015-07-17 22:12:00.000',0,'Analogue','OTB12',0,'---'),(1143,'OTB13_IO','OTB13',1,'2015-08-18 07:40:44.285','2015-07-17 22:12:00.000',0,'Analogue','OTB13',0,'---'),(1144,'OTB14_IO','OTB14',1,'2015-08-18 07:40:44.285','2015-07-17 22:12:00.000',0,'Analogue','OTB14',0,'---'),(1145,'OTB15_IO','OTB15',1,'2015-08-18 07:40:44.301','2015-07-17 22:12:00.000',0,'Analogue','OTB15',0,'---'),(1146,'OTB16_IO','OTB16',1,'2015-08-18 07:40:44.317','2015-07-17 22:12:00.000',0,'Analogue','OTB16',0,'---'),(1147,'OTB17_IO','OTB17',1,'2015-08-18 07:40:44.332','2015-07-17 22:12:00.000',0,'Analogue','OTB17',0,'---'),(1148,'OTB18_IO','OTB18',1,'2015-08-18 07:40:44.332','2015-07-17 22:12:00.000',0,'Analogue','OTB18',0,'---'),(1149,'OTB19_IO','OTB19',1,'2015-08-18 07:40:44.348','2015-07-17 22:12:00.000',0,'Analogue','OTB19',0,'---'),(1150,'OTB20_IO','OTB20',1,'2015-08-18 07:40:44.363','2015-07-17 22:12:00.000',0,'Analogue','OTB20',0,'---'),(1151,'OTB21_IO','OTB21',1,'2015-08-18 07:40:44.379','2015-07-17 22:12:00.000',0,'Analogue','OTB21',0,'---'),(1152,'BCM1_BrStatus','BCM1_BrStatus',1,'2015-08-18 07:40:44.395','2015-07-17 22:12:00.000',0,'Analogue','BCM1_BrStatus',0,'---'),(1153,'BCM2_BrStatus','BCM2_BrStatus',1,'2015-08-18 07:40:44.395','2015-07-17 22:12:00.000',0,'Analogue','BCM2_BrStatus',0,'---'),(1154,'BCM3_BrStatus','BCM3_BrStatus',1,'2015-08-18 07:40:44.410','2015-07-17 22:12:00.000',0,'Analogue','BCM3_BrStatus',0,'---'),(1155,'BCM4_BrStatus','BCM4_BrStatus',1,'2015-08-18 07:40:44.426','2015-07-17 22:12:00.000',0,'Analogue','BCM4_BrStatus',0,'---'),(1156,'CCM1_CradleStatus','CCM1_CradleStatus',1,'2015-08-18 07:40:44.442','2015-07-17 22:12:00.000',0,'Analogue','CCM1_CradleStatus',0,'---'),(1157,'CCM2_CradleStatus','CCM2_CradleStatus',1,'2015-08-18 07:40:44.457','2015-07-17 22:12:00.000',0,'Analogue','CCM2_CradleStatus',0,'---'),(1158,'CCM3_CradleStatus','CCM3_CradleStatus',1,'2015-08-18 07:40:44.457','2015-07-17 22:12:00.000',0,'Analogue','CCM3_CradleStatus',0,'---'),(1159,'CCM4_CradleStatus','CCM4_CradleStatus',1,'2015-08-18 07:40:44.473','2015-07-17 22:12:00.000',0,'Analogue','CCM4_CradleStatus',0,'---'),(1160,'PM1_14_kWh','PM710: Energy',1,'2015-08-18 07:40:44.488','2015-07-17 22:12:00.000',0,'Analogue','PM710: Energy',0,'kWh'),(1161,'PM1_14_pf','PM710: Power factor',1,'2015-08-18 07:40:44.504','2015-07-17 22:12:00.000',0,'Analogue','PM710: Power factor',0,'---'),(1162,'PM1_14_kW','PM710: Power',1,'2015-08-18 07:40:44.504','2015-07-17 22:12:00.000',0,'Analogue','PM710: Power',0,'kW'),(1163,'PM1_14_kVA','PM710: apparent power',1,'2015-08-18 07:40:44.520','2015-07-17 22:12:00.000',0,'Analogue','PM710: apparent power',0,'kVA'),(1164,'PM1_14_F','PM710: Frequency',1,'2015-08-18 07:40:44.535','2015-07-17 22:12:00.000',0,'Analogue','PM710: Frequency',0,'Hz'),(1165,'PM1_14_I1','PM710: Current L1',1,'2015-08-18 07:40:44.551','2015-07-17 22:12:00.000',0,'Analogue','PM710: Current L1',0,'A'),(1166,'PM1_14_I2','PM710: Current L2',1,'2015-08-18 07:40:44.567','2015-07-17 22:12:00.000',0,'Analogue','PM710: Current L2',0,'A'),(1167,'PM1_14_I3','PM710: Current L3',1,'2015-08-18 07:40:44.567','2015-07-17 22:12:00.000',0,'Analogue','PM710: Current L3',0,'A'),(1168,'PM1_14_In','PM710: Current',1,'2015-08-18 07:40:44.582','2015-07-17 22:12:00.000',0,'Analogue','PM710: Current',0,'A'),(1169,'PM1_14_V12','PM710: Voltage L12',1,'2015-08-18 07:40:44.598','2015-07-17 22:12:00.000',0,'Analogue','PM710: Voltage L12',0,'V'),(1170,'PM1_14_V23','PM710: Voltage L23',1,'2015-08-18 07:40:44.613','2015-07-17 22:12:00.000',0,'Analogue','PM710: Voltage L23',0,'V'),(1171,'PM1_14_V31','PM710: Voltage L31',1,'2015-08-18 07:40:44.629','2015-07-17 22:12:00.000',0,'Analogue','PM710: Voltage L31',0,'V'),(1172,'PM1_14_V1','PM710: Voltage L1',1,'2015-08-18 07:40:44.629','2015-07-17 22:12:00.000',0,'Analogue','PM710: Voltage L1',0,'V'),(1173,'PM1_14_V2','PM710: Voltage L2',1,'2015-08-18 07:40:44.645','2015-07-17 22:12:00.000',0,'Analogue','PM710: Voltage L2',0,'V'),(1174,'PM1_14_V3','PM710: Voltage L3',1,'2015-08-18 07:40:44.660','2015-07-17 22:12:00.000',0,'Analogue','PM710: Voltage L3',0,'V'),(1175,'PM1_14_kW1','PM710: Power L1',1,'2015-08-18 07:40:44.676','2015-07-17 22:12:00.000',0,'Analogue','PM710: Power L1',0,'kW'),(1176,'PM1_14_kW2','PM710: Power L2',1,'2015-08-18 07:40:44.692','2015-07-17 22:12:00.000',0,'Analogue','PM710: Power L2',0,'kW'),(1177,'PM1_14_kW3','PM710: Power L3',1,'2015-08-18 07:40:44.692','2015-07-17 22:12:00.000',0,'Analogue','PM710: Power L3',0,'kW'),(1178,'PM1_14_kVA1','PM710: apparent power L1',1,'2015-08-18 07:40:44.707','2015-07-17 22:12:00.000',0,'Analogue','PM710: apparent power L1',0,'kVA'),(1179,'PM1_14_kVA2','PM710: apparent power L2',1,'2015-08-18 07:40:44.723','2015-07-17 22:12:00.000',0,'Analogue','PM710: apparent power L2',0,'kVA'),(1180,'PM1_14_kVA3','PM710: apparent power L3',1,'2015-08-18 07:40:44.738','2015-07-17 22:12:00.000',0,'Analogue','PM710: apparent power L3',0,'kVA'),(1181,'PM1_14_THD_I1','PM710: THD Current L1',1,'2015-08-18 07:40:44.738','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Current L1',0,'%'),(1182,'PM1_14_THD_I2','PM710: THD Current L2',1,'2015-08-18 07:40:44.754','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Current L2',0,'%'),(1183,'PM1_14_THD_I3','PM710: THD Current L3',1,'2015-08-18 07:40:44.770','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Current L3',0,'%'),(1184,'PM1_14_THD_V1','PM710: THD Voltage L1',1,'2015-08-18 07:40:44.785','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Voltage L1',0,'%'),(1185,'PM1_14_THD_V2','PM710: THD Voltage L2',1,'2015-08-18 07:40:44.801','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Voltage L2',0,'%'),(1186,'PM1_14_THD_V3','PM710: THD Voltage L3',1,'2015-08-18 07:40:44.801','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Voltage L3',0,'%'),(1187,'PM1_14_THD_V12','PM710: THD Voltage L12',1,'2015-08-18 07:40:44.817','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Voltage L12',0,'%'),(1188,'PM1_14_THD_V23','PM710: THD Voltage L23',1,'2015-08-18 07:40:44.832','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Voltage L23',0,'%'),(1189,'PM1_14_THD_V31','PM710: THD Voltage L31',1,'2015-08-18 07:40:44.848','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Voltage L31',0,'%'),(1190,'PM1_14_Hour','PM710: Hour',1,'2015-08-18 07:40:44.848','2015-07-17 22:12:00.000',0,'Analogue','PM710: Hour',0,'Hour'),(1191,'PM1_14_Min','PM710: Min',1,'2015-08-18 07:40:44.863','2015-07-17 22:12:00.000',0,'Analogue','PM710: Min',0,'Min'),(1192,'PM1_17_kWh','PM710: Energy',1,'2015-08-18 07:40:44.879','2015-07-17 22:12:00.000',0,'Analogue','PM710: Energy',0,'kWh'),(1193,'PM1_17_pf','PM710: Power factor',1,'2015-08-18 07:40:44.895','2015-07-17 22:12:00.000',0,'Analogue','PM710: Power factor',0,'---'),(1194,'PM1_17_kW','PM710: Power',1,'2015-08-18 07:40:44.910','2015-07-17 22:12:00.000',0,'Analogue','PM710: Power',0,'kW'),(1195,'PM1_17_kVA','PM710: apparent power',1,'2015-08-18 07:40:44.910','2015-07-17 22:12:00.000',0,'Analogue','PM710: apparent power',0,'kVA'),(1196,'PM1_17_F','PM710: Frequency',1,'2015-08-18 07:40:44.926','2015-07-17 22:12:00.000',0,'Analogue','PM710: Frequency',0,'Hz'),(1197,'PM1_17_I1','PM710: Current L1',1,'2015-08-18 07:40:44.942','2015-07-17 22:12:00.000',0,'Analogue','PM710: Current L1',0,'A'),(1198,'PM1_17_I2','PM710: Current L2',1,'2015-08-18 07:40:44.957','2015-07-17 22:12:00.000',0,'Analogue','PM710: Current L2',0,'A'),(1199,'PM1_17_I3','PM710: Current L3',1,'2015-08-18 07:40:44.973','2015-07-17 22:12:00.000',0,'Analogue','PM710: Current L3',0,'A'),(1200,'PM1_17_In','PM710: Current',1,'2015-08-18 07:40:44.973','2015-07-17 22:12:00.000',0,'Analogue','PM710: Current',0,'A'),(1201,'PM1_17_V12','PM710: Voltage L12',1,'2015-08-18 07:40:44.988','2015-07-17 22:12:00.000',0,'Analogue','PM710: Voltage L12',0,'V'),(1202,'PM1_17_V23','PM710: Voltage L23',1,'2015-08-18 07:40:45.004','2015-07-17 22:12:00.000',0,'Analogue','PM710: Voltage L23',0,'V'),(1203,'PM1_17_V31','PM710: Voltage L31',1,'2015-08-18 07:40:45.020','2015-07-17 22:12:00.000',0,'Analogue','PM710: Voltage L31',0,'V'),(1204,'PM1_17_V1','PM710: Voltage L1',1,'2015-08-18 07:40:45.020','2015-07-17 22:12:00.000',0,'Analogue','PM710: Voltage L1',0,'V'),(1205,'PM1_17_V2','PM710: Voltage L2',1,'2015-08-18 07:40:45.035','2015-07-17 22:12:00.000',0,'Analogue','PM710: Voltage L2',0,'V'),(1206,'PM1_17_V3','PM710: Voltage L3',1,'2015-08-18 07:40:45.051','2015-07-17 22:12:00.000',0,'Analogue','PM710: Voltage L3',0,'V'),(1207,'PM1_17_kW1','PM710: Power L1',1,'2015-08-18 07:40:45.067','2015-07-17 22:12:00.000',0,'Analogue','PM710: Power L1',0,'kW'),(1208,'PM1_17_kW2','PM710: Power L2',1,'2015-08-18 07:40:45.082','2015-07-17 22:12:00.000',0,'Analogue','PM710: Power L2',0,'kW'),(1209,'PM1_17_kW3','PM710: Power L3',1,'2015-08-18 07:40:45.082','2015-07-17 22:12:00.000',0,'Analogue','PM710: Power L3',0,'kW'),(1210,'PM1_17_kVA1','PM710: apparent power L1',1,'2015-08-18 07:40:45.098','2015-07-17 22:12:00.000',0,'Analogue','PM710: apparent power L1',0,'kVA'),(1211,'PM1_17_kVA2','PM710: apparent power L2',1,'2015-08-18 07:40:45.113','2015-07-17 22:12:00.000',0,'Analogue','PM710: apparent power L2',0,'kVA'),(1212,'PM1_17_kVA3','PM710: apparent power L3',1,'2015-08-18 07:40:45.129','2015-07-17 22:12:00.000',0,'Analogue','PM710: apparent power L3',0,'kVA'),(1213,'PM1_17_THD_I1','PM710: THD Current L1',1,'2015-08-18 07:40:45.145','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Current L1',0,'%'),(1214,'PM1_17_THD_I2','PM710: THD Current L2',1,'2015-08-18 07:40:45.145','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Current L2',0,'%'),(1215,'PM1_17_THD_I3','PM710: THD Current L3',1,'2015-08-18 07:40:45.160','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Current L3',0,'%'),(1216,'PM1_17_THD_V1','PM710: THD Voltage L1',1,'2015-08-18 07:40:45.176','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Voltage L1',0,'%'),(1217,'PM1_17_THD_V2','PM710: THD Voltage L2',1,'2015-08-18 07:40:45.192','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Voltage L2',0,'%'),(1218,'PM1_17_THD_V3','PM710: THD Voltage L3',1,'2015-08-18 07:40:45.207','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Voltage L3',0,'%'),(1219,'PM1_17_THD_V12','PM710: THD Voltage L12',1,'2015-08-18 07:40:45.207','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Voltage L12',0,'%'),(1220,'PM1_17_THD_V23','PM710: THD Voltage L23',1,'2015-08-18 07:40:45.223','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Voltage L23',0,'%'),(1221,'PM1_17_THD_V31','PM710: THD Voltage L31',1,'2015-08-18 07:40:45.238','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Voltage L31',0,'%'),(1222,'PM1_17_Hour','PM710: Hour',1,'2015-08-18 07:40:45.254','2015-07-17 22:12:00.000',0,'Analogue','PM710: Hour',0,'Hour'),(1223,'PM1_17_Min','PM710: Min',1,'2015-08-18 07:40:45.254','2015-07-17 22:12:00.000',0,'Analogue','PM710: Min',0,'Min'),(1224,'PM1_18_kWh','PM710: Energy',1,'2015-08-18 07:40:45.270','2015-07-17 22:12:00.000',0,'Analogue','PM710: Energy',0,'kWh'),(1225,'PM1_18_pf','PM710: Power factor',1,'2015-08-18 07:40:45.285','2015-07-17 22:12:00.000',0,'Analogue','PM710: Power factor',0,'---'),(1226,'PM1_18_kW','PM710: Power',1,'2015-08-18 07:40:45.301','2015-07-17 22:12:00.000',0,'Analogue','PM710: Power',0,'kW'),(1227,'PM1_18_kVA','PM710: apparent power',1,'2015-08-18 07:40:45.317','2015-07-17 22:12:00.000',0,'Analogue','PM710: apparent power',0,'kVA'),(1228,'PM1_18_F','PM710: Frequency',1,'2015-08-18 07:40:45.317','2015-07-17 22:12:00.000',0,'Analogue','PM710: Frequency',0,'Hz'),(1229,'PM1_18_I1','PM710: Current L1',1,'2015-08-18 07:40:45.332','2015-07-17 22:12:00.000',0,'Analogue','PM710: Current L1',0,'A'),(1230,'PM1_18_I2','PM710: Current L2',1,'2015-08-18 07:40:45.348','2015-07-17 22:12:00.000',0,'Analogue','PM710: Current L2',0,'A'),(1231,'PM1_18_I3','PM710: Current L3',1,'2015-08-18 07:40:45.363','2015-07-17 22:12:00.000',0,'Analogue','PM710: Current L3',0,'A'),(1232,'PM1_18_In','PM710: Current',1,'2015-08-18 07:40:45.379','2015-07-17 22:12:00.000',0,'Analogue','PM710: Current',0,'A'),(1233,'PM1_18_V12','PM710: Voltage L12',1,'2015-08-18 07:40:45.379','2015-07-17 22:12:00.000',0,'Analogue','PM710: Voltage L12',0,'V'),(1234,'PM1_18_V23','PM710: Voltage L23',1,'2015-08-18 07:40:45.410','2015-07-17 22:12:00.000',0,'Analogue','PM710: Voltage L23',0,'V'),(1235,'PM1_18_V31','PM710: Voltage L31',1,'2015-08-18 07:40:45.426','2015-07-17 22:12:00.000',0,'Analogue','PM710: Voltage L31',0,'V'),(1236,'PM1_18_V1','PM710: Voltage L1',1,'2015-08-18 07:40:45.442','2015-07-17 22:12:00.000',0,'Analogue','PM710: Voltage L1',0,'V'),(1237,'PM1_18_V2','PM710: Voltage L2',1,'2015-08-18 07:40:45.442','2015-07-17 22:12:00.000',0,'Analogue','PM710: Voltage L2',0,'V'),(1238,'PM1_18_V3','PM710: Voltage L3',1,'2015-08-18 07:40:45.457','2015-07-17 22:12:00.000',0,'Analogue','PM710: Voltage L3',0,'V'),(1239,'PM1_18_kW1','PM710: Power L1',1,'2015-08-18 07:40:45.473','2015-07-17 22:12:00.000',0,'Analogue','PM710: Power L1',0,'kW'),(1240,'PM1_18_kW2','PM710: Power L2',1,'2015-08-18 07:40:45.488','2015-07-17 22:12:00.000',0,'Analogue','PM710: Power L2',0,'kW'),(1241,'PM1_18_kW3','PM710: Power L3',1,'2015-08-18 07:40:45.488','2015-07-17 22:12:00.000',0,'Analogue','PM710: Power L3',0,'kW'),(1242,'PM1_18_kVA1','PM710: apparent power L1',1,'2015-08-18 07:40:45.504','2015-07-17 22:12:00.000',0,'Analogue','PM710: apparent power L1',0,'kVA'),(1243,'PM1_18_kVA2','PM710: apparent power L2',1,'2015-08-18 07:40:45.520','2015-07-17 22:12:00.000',0,'Analogue','PM710: apparent power L2',0,'kVA'),(1244,'PM1_18_kVA3','PM710: apparent power L3',1,'2015-08-18 07:40:45.535','2015-07-17 22:12:00.000',0,'Analogue','PM710: apparent power L3',0,'kVA'),(1245,'PM1_18_THD_I1','PM710: THD Current L1',1,'2015-08-18 07:40:45.551','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Current L1',0,'%'),(1246,'PM1_18_THD_I2','PM710: THD Current L2',1,'2015-08-18 07:40:45.567','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Current L2',0,'%'),(1247,'PM1_18_THD_I3','PM710: THD Current L3',1,'2015-08-18 07:40:45.567','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Current L3',0,'%'),(1248,'PM1_18_THD_V1','PM710: THD Voltage L1',1,'2015-08-18 07:40:45.582','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Voltage L1',0,'%'),(1249,'PM1_18_THD_V2','PM710: THD Voltage L2',1,'2015-08-18 07:40:45.598','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Voltage L2',0,'%'),(1250,'PM1_18_THD_V3','PM710: THD Voltage L3',1,'2015-08-18 07:40:45.614','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Voltage L3',0,'%'),(1251,'PM1_18_THD_V12','PM710: THD Voltage L12',1,'2015-08-18 07:40:45.614','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Voltage L12',0,'%'),(1252,'PM1_18_THD_V23','PM710: THD Voltage L23',1,'2015-08-18 07:40:45.629','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Voltage L23',0,'%'),(1253,'PM1_18_THD_V31','PM710: THD Voltage L31',1,'2015-08-18 07:40:45.645','2015-07-17 22:12:00.000',0,'Analogue','PM710: THD Voltage L31',0,'%'),(1254,'PM1_18_Hour','PM710: Hour',1,'2015-08-18 07:40:45.660','2015-07-17 22:12:00.000',0,'Analogue','PM710: Hour',0,'Hour'),(1255,'PM1_18_Min','PM710: Min',1,'2015-08-18 07:40:45.676','2015-07-17 22:12:00.000',0,'Analogue','PM710: Min',0,'Min'),(1256,'DHCX1_UnitSetpointTemperatureDayW','DHCX1_UnitSetpointTemperatureDayW',1,'2015-08-18 07:40:45.676','2015-07-17 22:12:00.000',0,'Analogue','DHCX1_UnitSetpointTemperatureDayW',1,'---'),(1257,'DHCX1_UnitSetpointTemperatureNightW','DHCX1_UnitSetpointTemperatureNightW',1,'2015-08-18 07:40:45.692','2015-07-17 22:12:00.000',0,'Analogue','DHCX1_UnitSetpointTemperatureNightW',1,'---'),(1258,'DHCX1_UnitSetpointHumidityW','DHCX1_UnitSetpointHumidityW',1,'2015-08-18 07:40:45.707','2015-07-17 22:12:00.000',0,'Analogue','DHCX1_UnitSetpointHumidityW',1,'---'),(1259,'DHCX2_UnitSetpointTemperatureDayW','DHCX2_UnitSetpointTemperatureDayW',1,'2015-08-18 07:40:45.723','2015-07-17 22:12:00.000',0,'Analogue','DHCX2_UnitSetpointTemperatureDayW',1,'---'),(1260,'DHCX2_UnitSetpointTemperatureNightW','DHCX2_UnitSetpointTemperatureNightW',1,'2015-08-18 07:40:45.738','2015-07-17 22:12:00.000',0,'Analogue','DHCX2_UnitSetpointTemperatureNightW',1,'---'),(1261,'DHCX2_UnitSetpointHumidityW','DHCX2_UnitSetpointHumidityW',1,'2015-08-18 07:40:45.738','2015-07-17 22:12:00.000',0,'Analogue','DHCX2_UnitSetpointHumidityW',1,'---'),(1262,'DHCX3_UnitSetpointTemperatureDayW','DHCX3_UnitSetpointTemperatureDayW',1,'2015-08-18 07:40:45.754','2015-07-17 22:12:00.000',0,'Analogue','DHCX3_UnitSetpointTemperatureDayW',1,'---'),(1263,'DHCX3_UnitSetpointTemperatureNightW','DHCX3_UnitSetpointTemperatureNightW',1,'2015-08-18 07:40:45.770','2015-07-17 22:12:00.000',0,'Analogue','DHCX3_UnitSetpointTemperatureNightW',1,'---'),(1264,'DHCX3_UnitSetpointHumidityW','DHCX3_UnitSetpointHumidityW',1,'2015-08-18 07:40:45.785','2015-07-17 22:12:00.000',0,'Analogue','DHCX3_UnitSetpointHumidityW',1,'---'),(1265,'DHCX4_UnitSetpointTemperatureDayW','DHCX4_UnitSetpointTemperatureDayW',1,'2015-08-18 07:40:45.785','2015-07-17 22:12:00.000',0,'Analogue','DHCX4_UnitSetpointTemperatureDayW',1,'---'),(1266,'DHCX4_UnitSetpointTemperatureNightW','DHCX4_UnitSetpointTemperatureNightW',1,'2015-08-18 07:40:45.801','2015-07-17 22:12:00.000',0,'Analogue','DHCX4_UnitSetpointTemperatureNightW',1,'---'),(1267,'DHCX4_UnitSetpointHumidityW','DHCX4_UnitSetpointHumidityW',1,'2015-08-18 07:40:45.817','2015-07-17 22:12:00.000',0,'Analogue','DHCX4_UnitSetpointHumidityW',1,'---'),(1268,'DHCX5_UnitSetpointTemperatureDayW','DHCX5_UnitSetpointTemperatureDayW',1,'2015-08-18 07:40:45.832','2015-07-17 22:12:00.000',0,'Analogue','DHCX5_UnitSetpointTemperatureDayW',1,'---'),(1269,'DHCX5_UnitSetpointTemperatureNightW','DHCX5_UnitSetpointTemperatureNightW',1,'2015-08-18 07:40:45.848','2015-07-17 22:12:00.000',0,'Analogue','DHCX5_UnitSetpointTemperatureNightW',1,'---'),(1270,'DHCX5_UnitSetpointHumidityW','DHCX5_UnitSetpointHumidityW',1,'2015-08-18 07:40:45.848','2015-07-17 22:12:00.000',0,'Analogue','DHCX5_UnitSetpointHumidityW',1,'---'),(1271,'DHCX6_UnitSetpointTemperatureDayW','DHCX6_UnitSetpointTemperatureDayW',1,'2015-08-18 07:40:45.864','2015-07-17 22:12:00.000',0,'Analogue','DHCX6_UnitSetpointTemperatureDayW',1,'---'),(1272,'DHCX6_UnitSetpointTemperatureNightW','DHCX6_UnitSetpointTemperatureNightW',1,'2015-08-18 07:40:45.879','2015-07-17 22:12:00.000',0,'Analogue','DHCX6_UnitSetpointTemperatureNightW',1,'---'),(1273,'DHCX6_UnitSetpointHumidityW','DHCX6_UnitSetpointHumidityW',1,'2015-08-18 07:40:45.895','2015-07-17 22:12:00.000',0,'Analogue','DHCX6_UnitSetpointHumidityW',1,'---'),(1274,'DHCX7_UnitSetpointTemperatureDayW','DHCX7_UnitSetpointTemperatureDayW',1,'2015-08-18 07:40:45.910','2015-07-17 22:12:00.000',0,'Analogue','DHCX7_UnitSetpointTemperatureDayW',1,'---'),(1275,'DHCX7_UnitSetpointTemperatureNightW','DHCX7_UnitSetpointTemperatureNightW',1,'2015-08-18 07:40:45.910','2015-07-17 22:12:00.000',0,'Analogue','DHCX7_UnitSetpointTemperatureNightW',1,'---'),(1276,'DHCX7_UnitSetpointHumidityW','DHCX7_UnitSetpointHumidityW',1,'2015-08-18 07:40:45.926','2015-07-17 22:12:00.000',0,'Analogue','DHCX7_UnitSetpointHumidityW',1,'---'),(1277,'DHCX8_UnitSetpointTemperatureDayW','DHCX8_UnitSetpointTemperatureDayW',1,'2015-08-18 07:40:45.942','2015-07-17 22:12:00.000',0,'Analogue','DHCX8_UnitSetpointTemperatureDayW',1,'---'),(1278,'DHCX8_UnitSetpointTemperatureNightW','DHCX8_UnitSetpointTemperatureNightW',1,'2015-08-18 07:40:45.957','2015-07-17 22:12:00.000',0,'Analogue','DHCX8_UnitSetpointTemperatureNightW',1,'---'),(1279,'DHCX8_UnitSetpointHumidityW','DHCX8_UnitSetpointHumidityW',1,'2015-08-18 07:40:45.973','2015-07-17 22:12:00.000',0,'Analogue','DHCX8_UnitSetpointHumidityW',1,'---');
/*!40000 ALTER TABLE `channel_definition` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `channel_definition_BEFORE_INSERT` BEFORE INSERT ON `channel_definition` FOR EACH ROW begin
    set New.updatedAt = current_timestamp(3);
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `channel_definition_AFTER_INSERT` AFTER INSERT ON `channel_definition` FOR EACH ROW BEGIN
	INSERT INTO `channel_data`(`channelName`,`channel_definition_id`, `controllable`) VALUES(NEW.name, NEW.id, NEW.controllable);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `channel_history`
--

DROP TABLE IF EXISTS `channel_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` float /*!50606 COLUMN_FORMAT FIXED */ DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `channel_definition_id` int(11) NOT NULL /*!50606 STORAGE MEMORY */ /*!50606 COLUMN_FORMAT FIXED */,
  `number_of_sample` int(11) /*!50606 COLUMN_FORMAT FIXED */ DEFAULT '1',
  PRIMARY KEY (`id`,`channel_definition_id`),
  UNIQUE KEY `channeID` (`channel_definition_id`,`updatedAt`,`id`) USING BTREE,
  KEY `updatedAT` (`channel_definition_id`,`updatedAt`,`value`,`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED
/*!50100 PARTITION BY HASH (channel_definition_id + id)
PARTITIONS 10 */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_history`
--

LOCK TABLES `channel_history` WRITE;
/*!40000 ALTER TABLE `channel_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel_history` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `After_Update_ChannelHistory` BEFORE UPDATE ON `channel_history` FOR EACH ROW BEGIN
	set NEW.number_of_sample = OLD.number_of_sample + 1; 
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `channel_issue_snapshot`
--

DROP TABLE IF EXISTS `channel_issue_snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel_issue_snapshot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` float DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `channel_definition_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`channel_definition_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_issue_snapshot`
--

LOCK TABLES `channel_issue_snapshot` WRITE;
/*!40000 ALTER TABLE `channel_issue_snapshot` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel_issue_snapshot` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `channel_issue_snapshot_BEFORE_UPDATE` BEFORE UPDATE ON `channel_issue_snapshot` FOR EACH ROW begin
	Declare TimeInterval int;
    Set TimeInterval = 3600;
	if (New.updatedAt - Old.createdAt > TimeInterval) then
		set New.createdAt = SUBDATE(New.updatedAt, interval 1 hour);
    end if;   
    
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `name` varchar(255) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `keyUnique` (`name`) USING HASH
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES ('alarmMode','false'),('logHistory','true');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `controllable`
--

DROP TABLE IF EXISTS `controllable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `controllable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channelName` varchar(512) NOT NULL,
  `value` int(11) DEFAULT NULL,
  `status` varchar(512) DEFAULT NULL,
  `channel_definition_id` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `controllable`
--

LOCK TABLES `controllable` WRITE;
/*!40000 ALTER TABLE `controllable` DISABLE KEYS */;
INSERT INTO `controllable` VALUES (1,'AC_ServerNumberStandby',1,'0','0'),(2,'AC_ServerMan1',1,'0','0'),(3,'AC_ServerMan2',1,'0','0'),(4,'AC_ServerMan3',1,'0','0'),(5,'AC_ServerManEnable',0,'0','0'),(6,'AC_ServerNextSchedule',0,'0','0'),(7,'AC_ServerRotateTime',28800,'0','0'),(8,'AC_ServerTempHigh',27,'0','0'),(9,'AC_ServerTempReset',25,'0','0'),(10,'ALARM_Bell',0,'0','0');
/*!40000 ALTER TABLE `controllable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `escalation_profile`
--

DROP TABLE IF EXISTS `escalation_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `escalation_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  `displayName` varchar(512) NOT NULL,
  `status` varchar(512) NOT NULL,
  `configuration` text,
  `isReadOnly` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `escalation_profile`
--

LOCK TABLES `escalation_profile` WRITE;
/*!40000 ALTER TABLE `escalation_profile` DISABLE KEYS */;
INSERT INTO `escalation_profile` VALUES (1,'critical','Critical','active','{\"interval\":300}',1),(2,'warning','Warning','active','{\"interval\":600}',1),(3,'advisory','Advisory','active','{\"interval\":1800}',1),(4,'log','Log','active','{\"interval\":7200000}',1);
/*!40000 ALTER TABLE `escalation_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `hum`
--

DROP TABLE IF EXISTS `hum`;
/*!50001 DROP VIEW IF EXISTS `hum`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `hum` AS SELECT 
 1 AS `id`,
 1 AS `value`,
 1 AS `createdAt`,
 1 AS `updatedAt`,
 1 AS `channel_definition_id`,
 1 AS `number_of_sample`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `job`
--

DROP TABLE IF EXISTS `job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  `cronTime` varchar(512) NOT NULL,
  `instruction` text,
  `status` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job`
--

LOCK TABLES `job` WRITE;
/*!40000 ALTER TABLE `job` DISABLE KEYS */;
/*!40000 ALTER TABLE `job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(512) NOT NULL,
  `type` varchar(512) NOT NULL,
  `name` varchar(512) NOT NULL,
  `description` varchar(512) DEFAULT NULL,
  `parentID` int(11) DEFAULT NULL,
  `logo` varchar(512) DEFAULT NULL,
  `images` varchar(512) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `unitParentID` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES (1,'DAR','location','Dar es Salaam','Dar es Salaam, Tanzania',0,'home-icon.png','DAR.png',1,0),(2,'DAR_UP','system','UPS','Uninterruptible power supply',1,'ups-icon.png','UPSsystem.jpg',2,0),(3,'DAR_PI','system','PAC','Precision air-conditioning - Indoor unit',1,'air_conditioning_icon.png','1.png',3,0),(4,'DAR_GS','system','Genset','Generator set',1,'generator-set-icon.jpg','Gensetsystem.jpg',4,0),(5,'DAR_PW','system','PW','Power switchboard',1,'switchboard-power-icon.jpg','Powerswitchboardsystem.jpg',5,0),(6,'DAR_HS','system','HS','High sensitive smoke detection',1,'high-sensitive-smoke-detection.jpg','1.png',6,0),(7,'DAR_RE','system','Rectifier','Rectifier system',1,'rectifier-icon.png','Rectifiersystem.jpg',7,0),(8,'DAR_TF','system','Transformer','Transformer utility',1,'electricity_power_charge_full-icon.png','1.png',8,0),(9,'DAR_LL','system','LL','Liquid leak detection',1,'liquid-leak-detection.png','1.png',9,0),(10,'DAR_UP_T31','unit','UPS 1','RIELLO 60KVA',2,'ups_unit_icon.png','ups.jpg',10,0),(11,'DAR_UP_T32','unit','UPS 2','RIELLO 60KVA',2,'ups_unit_icon.png','ups.jpg',11,0),(12,'DAR_UP_T33','unit','UPS 3','RIELLO 60KVA',2,'ups_unit_icon.png','ups.jpg',12,0),(13,'DAR_UP_T34','unit','UPS 4','RIELLO 60KVA',2,'ups_unit_icon.png','ups.jpg',13,0),(14,'DAR_PI_DX1','unit','DHCX 1','Gas based unit ',3,'nan.png','dhcx.jpg',14,0),(15,'DAR_PI_DX2','unit','DHCX 2','Gas based unit',3,'nan.png','dhcx.jpg',15,0),(16,'DAR_PI_DX3','unit','DHCX 3','Gas based unit',3,'nan.png','dhcx.jpg',16,0),(17,'DAR_PI_DX4','unit','DHCX 4','Gas based unit',3,'nan.png','dhcx.jpg',17,0),(18,'DAR_PI_DX5','unit','DHCX 5','Gas based unit',3,'nan.png','dhcx.jpg',18,0),(19,'DAR_PI_DX6','unit','DHCX 6','Gas based unit',3,'nan.png','dhcx.jpg',19,0),(20,'DAR_PI_DX7','unit','DHCX 7','Gas based unit',3,'nan.png','dhcx.jpg',20,0),(21,'DAR_PI_DX8','unit','DHCX 8','Gas based unit',3,'nan.png','dhcx.jpg',21,0),(22,'DAR_GS_BG1','unit','Genset 1','Bare-set generator',4,'nan.png','genset.png',22,0),(23,'DAR_GS_BG2','unit','Genset 2','Bare-set generator',4,'nan.png','genset.png',23,0),(24,'DAR_PW_LV1','unit','LV-1','Low Voltage 1',5,'nan.png','LV1.jpg',24,0),(25,'DAR_PW_LV2','unit','LV-2','Low Voltage 2',5,'nan.png','LV2.jpg',25,0),(26,'DAR_PW_BU1','unit','TBU-1','TBU-1 switchboard',5,'nan.png','TBU-1.jpg',26,0),(27,'DAR_PW_BU2','unit','TBU-2','TBU-2 switchboard',5,'nan.png','TBU-2.jpg',27,0),(28,'DAR_PW_AT1','unit','ATS-1','ATS-1 switchboard',5,'nan.png','ATS-1.jpg',28,0),(29,'DAR_PW_AT2','unit','ATS-2','ATS-2 switchboard',5,'nan.png','ATS-2.jpg',29,0),(30,'DAR_PW_TC1','unit','TCM','TCM switchboard',5,'nan.png','TCM.jpg',30,0),(31,'DAR_PW_UP2','unit','UPSDB-2','UPSDB-2 switchboard',5,'nan.png','UDB-2.jpg',31,0),(32,'DAR_PW_AC1','unit','ACDB-1','ACDB-1 switchboard',5,'nan.png','ACDB-1.jpg',32,0),(33,'DAR_PW_EM1','unit','ESDB-1','ESDB-1 switchboard',5,'nan.png','TLL.jpg',33,0),(34,'DAR_PW_EM2','unit','ESDB-2','ESDB-2 switchboard',5,'nan.png','TLL.jpg',34,0),(35,'DAR_PW_UD1','unit','UDB-1','UDB-1 switchboard',5,'nan.png','UDB-1.jpg',35,0),(36,'DAR_PW_UD2','unit','UDB-2','UDB-2 switchboard',5,'nan.png','UDB-2.jpg',36,0),(37,'DAR_PW_PU1','unit','PDU-1','PDU-1 switchboard',5,'nan.png','dar_udb_1.png',37,0),(38,'DAR_PW_PU2','unit','PDU-2','PDU-2 switchboard',5,'nan.png','dar_udb_2.png',38,0),(39,'DAR_PW_DB1','unit','DCDB-1','DCDB-1 switchboard',5,'nan.png','UDB-1.jpg',39,0),(40,'DAR_PW_UP1','unit','UPSDB-1','UPSDB-1 switchboard',5,'nan.png','dar_upsdb_1.png',40,0),(41,'DAR_PW_AC2','unit','ACDB-2','ACDB-2 switchboard',5,'nan.png','ACDB-2.jpg',41,0),(42,'DAR_PW_DB2','unit','DCDB-2','DCDB-2 switchboard',5,'nan.png','dar_dcdb_2.png',42,0),(43,'DAR_RE_RE1','unit','REC 1','Rectifier unit ',7,'nan.png','Rectifierunit.jpg',43,0),(44,'DAR_RE_RE2','unit','REC 2','Rectifier unit ',7,'nan.png','Rectifierunit.jpg',44,0),(45,'DAR_RE_RE3','unit','REC 3','Rectifier unit ',7,'nan.png','Rectifierunit.jpg',45,0),(46,'DAR_RE_RE4','unit','REC 4','Rectifier unit ',7,'nan.png','Rectifierunit.jpg',46,0),(47,'DAR_RE_RE5','unit','REC 5','Rectifier unit ',7,'nan.png','Rectifierunit.jpg',47,0),(48,'DAR_RE_RE6','unit','REC 6','Rectifier unit ',7,'nan.png','Rectifierunit.jpg',48,0),(51,'DAR_TF_DT1','unit','Dry-transformer 1','Dry-transformer',8,'dry-transformer-icon.png','Dry-transformer.jpg',51,0),(52,'DAR_TF_DT2','unit','Dry-transformer 2','Dry-transformer',8,'dry-transformer-icon.png','Dry-transformer.jpg',52,0),(53,'DAR_PW_LV1_PM117','component','PM117','PM117',24,'nan.png','nan.png',53,0),(54,'DAR_PW_LV2_PM118','component','PM118','PM118',25,'nan.png','nan.png',54,0),(55,'DAR_PW_BU1_PM111','component','PM111','PM111',26,'nan.png','nan.png',55,0),(56,'DAR_PW_BU1_OTB13','component','OTB13','OTB13',26,'nan.png','nan.png',56,0),(57,'DAR_PW_BU1_OTB14','component','OTB14','OTB14',26,'nan.png','nan.png',57,0),(58,'DAR_PW_BU2_PM114','component','PM116','PM116',27,'nan.png','nan.png',58,0),(59,'DAR_PW_BU2_OTB17','component','OTB17','OTB17',27,'nan.png','nan.png',59,0),(60,'DAR_PW_BU2_OTB18','component','OTB18','OTB18',27,'nan.png','nan.png',60,0),(61,'DAR_PW_AT1_PM201','component','PM870','PM870',28,'nan.png','nan.png',61,0),(62,'DAR_PW_AT1_PM112','component','PM710','PM112',28,'nan.png','nan.png',62,0),(63,'DAR_PW_AT1_OTB15','component','OTB15','OTB15',28,'nan.png','nan.png',63,0),(64,'DAR_PW_AT1_BCM01','component','BCM01','BCM01',28,'nan.png','nan.png',64,0),(65,'DAR_PW_AT1_BCM02','component','BCM02','BCM02',28,'nan.png','nan.png',65,0),(66,'DAR_PW_AT2_PM202','component','PM202','PM202',29,'nan.png','nan.png',66,0),(67,'DAR_PW_AT2_PM113','component','PM113','PM113',29,'nan.png','nan.png',67,0),(68,'DAR_PW_AT2_OTB16','component','OTB16','OTB17',29,'nan.png','nan.png',68,0),(69,'DAR_PW_AT2_BCM03','component','BCM03','BCM03',29,'nan.png','nan.png',69,0),(70,'DAR_PW_AT2_BCM04','component','BCM04','BCM04',29,'nan.png','nan.png',70,0),(71,'DAR_PW_TC1_OTB19','component','OTB19','OTB19',30,'nan.png','nan.png',71,0),(72,'DAR_PW_TC1_OTB20','component','OTB20','OTB20',30,'nan.png','nan.png',72,0),(73,'DAR_PW_TC1_PM115','component','PM115','PM115',30,'nan.png','nan.png',73,0),(74,'DAR_PW_TC1_PM116','component','PM116','PM116',30,'nan.png','nan.png',74,0),(75,'DAR_PW_UP2_PM110','component','PM110','PM110',31,'nan.png','nan.png',75,0),(76,'DAR_PW_UP2_OTB12','component','OTB12','OTB13',31,'nan.png','nan.png',76,0),(77,'DAR_PW_AC1_PM107','component','PM107','PM107',32,'nan.png','nan.png',77,0),(78,'DAR_PW_AC1_OTB05','component','OTB05','OTB06',32,'nan.png','nan.png',78,0),(79,'DAR_PW_EM1_PM108','component','PM108','PM108',33,'nan.png','nan.png',79,0),(80,'DAR_PW_EM1_OTB08','component','OTB08','OTB09',33,'nan.png','nan.png',80,0),(81,'DAR_PW_EM2_PM109','component','PM109','PM109',34,'nan.png','nan.png',81,0),(82,'DAR_PW_EM2_OTB09','component','OTB09','OTB09',34,'nan.png','nan.png',82,0),(83,'DAR_PW_UD1_OTB01','component','OTB01','OTB01',35,'nan.png','nan.png',83,0),(84,'DAR_PW_UD1_PM101','component','PM101','PM101',35,'nan.png','nan.png',84,0),(85,'DAR_PW_UD1_PM102','component','PM102','PM102',35,'nan.png','nan.png',85,0),(86,'DAR_PW_UD2_OTB02','component','OTB02','OTB02',36,'nan.png','nan.png',86,0),(87,'DAR_PW_UD2_OTB03','component','OTB03','OTB03',36,'nan.png','nan.png',87,0),(88,'DAR_PW_UD2_PM103','component','PM103','PM103',36,'nan.png','nan.png',88,0),(89,'DAR_PW_UD2_PM104','component','PM104','PM104',36,'nan.png','nan.png',89,0),(90,'DAR_PW_PU1_PM105','component','PM105','PM105',37,'nan.png','nan.png',90,0),(91,'DAR_PW_PU2_OTB04','component','OTB04','OTB05',38,'nan.png','nan.png',91,0),(92,'DAR_PW_PU2_PM106','component','PM106','PM107',38,'nan.png','nan.png',92,0),(93,'DAR_PW_DB1_OTB24','component','OTB24','OTB24',39,'nan.png','nan.png',93,0),(94,'DAR_PW_UP1_OTB07','component','OTB07','OTB07',40,'nan.png','nan.png',94,0),(95,'DAR_PW_AC2_OTB10','component','OTB10','OTB10',41,'nan.png','nan.png',95,0),(96,'DAR_PW_DB2_OTB11','component','OTB11','OTB11',42,'nan.png','nan.png',96,0),(97,'DAR_PW_TLL','unit','TLL','TLL switchboard',5,'nan.png','TLL.jpg',97,0),(98,'DAR_HS_U1','unit','HS','High sensitive smoke detection',6,'nan.png','1.png',98,0),(99,'DAR_LL_U1','unit','LL','Liquid leak detection',9,'nan.png','1.png',99,0),(100,'DAR_LASER','system','LASER','LASER',1,'nan.png','1.png',100,0),(101,'DAR_LASER_U1','unit','LASER','LASER',100,'nan.png','1.png',101,0);
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(512) NOT NULL,
  `target` varchar(512) NOT NULL,
  `content` varchar(512) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `createdAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES (1,'sms','+255759384573','test',0,NULL);
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission`
--

DROP TABLE IF EXISTS `permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  `status` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission`
--

LOCK TABLES `permission` WRITE;
/*!40000 ALTER TABLE `permission` DISABLE KEYS */;
/*!40000 ALTER TABLE `permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `realtime`
--

DROP TABLE IF EXISTS `realtime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `realtime` (
  `DHCX1_CommonAlarm` double DEFAULT NULL,
  `DHCX1_UnitOnOff` double DEFAULT NULL,
  `DHCX1_UnitCooling` double DEFAULT NULL,
  `DHCX1_UnitHeating` double DEFAULT NULL,
  `DHCX1_UnitHumidification` double DEFAULT NULL,
  `DHCX1_Airflow1` double DEFAULT NULL,
  `DHCX1_Airflow2` double DEFAULT NULL,
  `DHCX1_Airflow3` double DEFAULT NULL,
  `DHCX1_HighPressure1` double DEFAULT NULL,
  `DHCX1_HighPressure2` double DEFAULT NULL,
  `DHCX1_WaterDetector` double DEFAULT NULL,
  `DHCX1_PhaseCheck` double DEFAULT NULL,
  `DHCX1_FireSmoke` double DEFAULT NULL,
  `DHCX1_ReturnAirTempHighAlarm` double DEFAULT NULL,
  `DHCX1_ReturnAirHumidHighAlarm` double DEFAULT NULL,
  `DHCX1_SupplyAirTempHighAlarm` double DEFAULT NULL,
  `DHCX1_SupplyAirHumidHighAlarm` double DEFAULT NULL,
  `DHCX1_WaterTempHighAlarm` double DEFAULT NULL,
  `DHCX1_ReturnAirTempLowAlarm` double DEFAULT NULL,
  `DHCX1_ReturnAirHumidLowAlarm` double DEFAULT NULL,
  `DHCX1_SupplyAirTempLowAlarm` double DEFAULT NULL,
  `DHCX1_SupplyAirHumidLowAlarm` double DEFAULT NULL,
  `DHCX1_WaterTempLowAlarm` double DEFAULT NULL,
  `DHCX1_FreezeAlarm` double DEFAULT NULL,
  `DHCX1_UnitRuntimeUnit` double DEFAULT NULL,
  `DHCX1_UnitSetpointTemperatureDay` double DEFAULT NULL,
  `DHCX1_UnitSetpointTemperatureNight` double DEFAULT NULL,
  `DHCX1_UnitSetpointHumidity` double DEFAULT NULL,
  `DHCX1_UnitReturnAirTemperature` double DEFAULT NULL,
  `DHCX1_UnitReturnAirHumidity` double DEFAULT NULL,
  `DHCX2_CommonAlarm` double DEFAULT NULL,
  `DHCX2_UnitOnOff` double DEFAULT NULL,
  `DHCX2_UnitCooling` double DEFAULT NULL,
  `DHCX2_UnitHeating` double DEFAULT NULL,
  `DHCX2_UnitHumidification` double DEFAULT NULL,
  `DHCX2_Airflow1` double DEFAULT NULL,
  `DHCX2_Airflow2` double DEFAULT NULL,
  `DHCX2_Airflow3` double DEFAULT NULL,
  `DHCX2_HighPressure1` double DEFAULT NULL,
  `DHCX2_HighPressure2` double DEFAULT NULL,
  `DHCX2_WaterDetector` double DEFAULT NULL,
  `DHCX2_PhaseCheck` double DEFAULT NULL,
  `DHCX2_FireSmoke` double DEFAULT NULL,
  `DHCX2_ReturnAirTempHighAlarm` double DEFAULT NULL,
  `DHCX2_ReturnAirHumidHighAlarm` double DEFAULT NULL,
  `DHCX2_SupplyAirTempHighAlarm` double DEFAULT NULL,
  `DHCX2_SupplyAirHumidHighAlarm` double DEFAULT NULL,
  `DHCX2_WaterTempHighAlarm` double DEFAULT NULL,
  `DHCX2_ReturnAirTempLowAlarm` double DEFAULT NULL,
  `DHCX2_ReturnAirHumidLowAlarm` double DEFAULT NULL,
  `DHCX2_SupplyAirTempLowAlarm` double DEFAULT NULL,
  `DHCX2_SupplyAirHumidLowAlarm` double DEFAULT NULL,
  `DHCX2_WaterTempLowAlarm` double DEFAULT NULL,
  `DHCX2_FreezeAlarm` double DEFAULT NULL,
  `DHCX2_UnitRuntimeUnit` double DEFAULT NULL,
  `DHCX2_UnitSetpointTemperatureDay` double DEFAULT NULL,
  `DHCX2_UnitSetpointTemperatureNight` double DEFAULT NULL,
  `DHCX2_UnitSetpointHumidity` double DEFAULT NULL,
  `DHCX2_UnitReturnAirTemperature` double DEFAULT NULL,
  `DHCX2_UnitReturnAirHumidity` double DEFAULT NULL,
  `DHCX3_CommonAlarm` double DEFAULT NULL,
  `DHCX3_UnitOnOff` double DEFAULT NULL,
  `DHCX3_UnitCooling` double DEFAULT NULL,
  `DHCX3_UnitHeating` double DEFAULT NULL,
  `DHCX3_UnitHumidification` double DEFAULT NULL,
  `DHCX3_Airflow1` double DEFAULT NULL,
  `DHCX3_Airflow2` double DEFAULT NULL,
  `DHCX3_Airflow3` double DEFAULT NULL,
  `DHCX3_HighPressure1` double DEFAULT NULL,
  `DHCX3_HighPressure2` double DEFAULT NULL,
  `DHCX3_WaterDetector` double DEFAULT NULL,
  `DHCX3_PhaseCheck` double DEFAULT NULL,
  `DHCX3_FireSmoke` double DEFAULT NULL,
  `DHCX3_ReturnAirTempHighAlarm` double DEFAULT NULL,
  `DHCX3_ReturnAirHumidHighAlarm` double DEFAULT NULL,
  `DHCX3_SupplyAirTempHighAlarm` double DEFAULT NULL,
  `DHCX3_SupplyAirHumidHighAlarm` double DEFAULT NULL,
  `DHCX3_WaterTempHighAlarm` double DEFAULT NULL,
  `DHCX3_ReturnAirTempLowAlarm` double DEFAULT NULL,
  `DHCX3_ReturnAirHumidLowAlarm` double DEFAULT NULL,
  `DHCX3_SupplyAirTempLowAlarm` double DEFAULT NULL,
  `DHCX3_SupplyAirHumidLowAlarm` double DEFAULT NULL,
  `DHCX3_WaterTempLowAlarm` double DEFAULT NULL,
  `DHCX3_FreezeAlarm` double DEFAULT NULL,
  `DHCX3_UnitRuntimeUnit` double DEFAULT NULL,
  `DHCX3_UnitSetpointTemperatureDay` double DEFAULT NULL,
  `DHCX3_UnitSetpointTemperatureNight` double DEFAULT NULL,
  `DHCX3_UnitSetpointHumidity` double DEFAULT NULL,
  `DHCX3_UnitReturnAirTemperature` double DEFAULT NULL,
  `DHCX3_UnitReturnAirHumidity` double DEFAULT NULL,
  `DHCX4_CommonAlarm` double DEFAULT NULL,
  `DHCX4_UnitOnOff` double DEFAULT NULL,
  `DHCX4_UnitCooling` double DEFAULT NULL,
  `DHCX4_UnitHeating` double DEFAULT NULL,
  `DHCX4_UnitHumidification` double DEFAULT NULL,
  `DHCX4_Airflow1` double DEFAULT NULL,
  `DHCX4_Airflow2` double DEFAULT NULL,
  `DHCX4_Airflow3` double DEFAULT NULL,
  `DHCX4_HighPressure1` double DEFAULT NULL,
  `DHCX4_HighPressure2` double DEFAULT NULL,
  `DHCX4_WaterDetector` double DEFAULT NULL,
  `DHCX4_PhaseCheck` double DEFAULT NULL,
  `DHCX4_FireSmoke` double DEFAULT NULL,
  `DHCX4_ReturnAirTempHighAlarm` double DEFAULT NULL,
  `DHCX4_ReturnAirHumidHighAlarm` double DEFAULT NULL,
  `DHCX4_SupplyAirTempHighAlarm` double DEFAULT NULL,
  `DHCX4_SupplyAirHumidHighAlarm` double DEFAULT NULL,
  `DHCX4_WaterTempHighAlarm` double DEFAULT NULL,
  `DHCX4_ReturnAirTempLowAlarm` double DEFAULT NULL,
  `DHCX4_ReturnAirHumidLowAlarm` double DEFAULT NULL,
  `DHCX4_SupplyAirTempLowAlarm` double DEFAULT NULL,
  `DHCX4_SupplyAirHumidLowAlarm` double DEFAULT NULL,
  `DHCX4_WaterTempLowAlarm` double DEFAULT NULL,
  `DHCX4_FreezeAlarm` double DEFAULT NULL,
  `DHCX4_UnitRuntimeUnit` double DEFAULT NULL,
  `DHCX4_UnitSetpointTemperatureDay` double DEFAULT NULL,
  `DHCX4_UnitSetpointTemperatureNight` double DEFAULT NULL,
  `DHCX4_UnitSetpointHumidity` double DEFAULT NULL,
  `DHCX4_UnitReturnAirTemperature` double DEFAULT NULL,
  `DHCX4_UnitReturnAirHumidity` double DEFAULT NULL,
  `DHCX5_CommonAlarm` double DEFAULT NULL,
  `DHCX5_UnitOnOff` double DEFAULT NULL,
  `DHCX5_UnitCooling` double DEFAULT NULL,
  `DHCX5_UnitHeating` double DEFAULT NULL,
  `DHCX5_UnitHumidification` double DEFAULT NULL,
  `DHCX5_Airflow1` double DEFAULT NULL,
  `DHCX5_Airflow2` double DEFAULT NULL,
  `DHCX5_Airflow3` double DEFAULT NULL,
  `DHCX5_HighPressure1` double DEFAULT NULL,
  `DHCX5_HighPressure2` double DEFAULT NULL,
  `DHCX5_WaterDetector` double DEFAULT NULL,
  `DHCX5_PhaseCheck` double DEFAULT NULL,
  `DHCX5_FireSmoke` double DEFAULT NULL,
  `DHCX5_ReturnAirTempHighAlarm` double DEFAULT NULL,
  `DHCX5_ReturnAirHumidHighAlarm` double DEFAULT NULL,
  `DHCX5_SupplyAirTempHighAlarm` double DEFAULT NULL,
  `DHCX5_SupplyAirHumidHighAlarm` double DEFAULT NULL,
  `DHCX5_WaterTempHighAlarm` double DEFAULT NULL,
  `DHCX5_ReturnAirTempLowAlarm` double DEFAULT NULL,
  `DHCX5_ReturnAirHumidLowAlarm` double DEFAULT NULL,
  `DHCX5_SupplyAirTempLowAlarm` double DEFAULT NULL,
  `DHCX5_SupplyAirHumidLowAlarm` double DEFAULT NULL,
  `DHCX5_WaterTempLowAlarm` double DEFAULT NULL,
  `DHCX5_FreezeAlarm` double DEFAULT NULL,
  `DHCX5_UnitRuntimeUnit` double DEFAULT NULL,
  `DHCX5_UnitSetpointTemperatureDay` double DEFAULT NULL,
  `DHCX5_UnitSetpointTemperatureNight` double DEFAULT NULL,
  `DHCX5_UnitSetpointHumidity` double DEFAULT NULL,
  `DHCX5_UnitReturnAirTemperature` double DEFAULT NULL,
  `DHCX5_UnitReturnAirHumidity` double DEFAULT NULL,
  `DHCX6_CommonAlarm` double DEFAULT NULL,
  `DHCX6_UnitOnOff` double DEFAULT NULL,
  `DHCX6_UnitCooling` double DEFAULT NULL,
  `DHCX6_UnitHeating` double DEFAULT NULL,
  `DHCX6_UnitHumidification` double DEFAULT NULL,
  `DHCX6_Airflow1` double DEFAULT NULL,
  `DHCX6_Airflow2` double DEFAULT NULL,
  `DHCX6_Airflow3` double DEFAULT NULL,
  `DHCX6_HighPressure1` double DEFAULT NULL,
  `DHCX6_HighPressure2` double DEFAULT NULL,
  `DHCX6_WaterDetector` double DEFAULT NULL,
  `DHCX6_PhaseCheck` double DEFAULT NULL,
  `DHCX6_FireSmoke` double DEFAULT NULL,
  `DHCX6_ReturnAirTempHighAlarm` double DEFAULT NULL,
  `DHCX6_ReturnAirHumidHighAlarm` double DEFAULT NULL,
  `DHCX6_SupplyAirTempHighAlarm` double DEFAULT NULL,
  `DHCX6_SupplyAirHumidHighAlarm` double DEFAULT NULL,
  `DHCX6_WaterTempHighAlarm` double DEFAULT NULL,
  `DHCX6_ReturnAirTempLowAlarm` double DEFAULT NULL,
  `DHCX6_ReturnAirHumidLowAlarm` double DEFAULT NULL,
  `DHCX6_SupplyAirTempLowAlarm` double DEFAULT NULL,
  `DHCX6_SupplyAirHumidLowAlarm` double DEFAULT NULL,
  `DHCX6_WaterTempLowAlarm` double DEFAULT NULL,
  `DHCX6_FreezeAlarm` double DEFAULT NULL,
  `DHCX6_UnitRuntimeUnit` double DEFAULT NULL,
  `DHCX6_UnitSetpointTemperatureDay` double DEFAULT NULL,
  `DHCX6_UnitSetpointTemperatureNight` double DEFAULT NULL,
  `DHCX6_UnitSetpointHumidity` double DEFAULT NULL,
  `DHCX6_UnitReturnAirTemperature` double DEFAULT NULL,
  `DHCX6_UnitReturnAirHumidity` double DEFAULT NULL,
  `DHCX7_CommonAlarm` double DEFAULT NULL,
  `DHCX7_UnitOnOff` double DEFAULT NULL,
  `DHCX7_UnitCooling` double DEFAULT NULL,
  `DHCX7_UnitHeating` double DEFAULT NULL,
  `DHCX7_UnitHumidification` double DEFAULT NULL,
  `DHCX7_Airflow1` double DEFAULT NULL,
  `DHCX7_Airflow2` double DEFAULT NULL,
  `DHCX7_Airflow3` double DEFAULT NULL,
  `DHCX7_HighPressure1` double DEFAULT NULL,
  `DHCX7_HighPressure2` double DEFAULT NULL,
  `DHCX7_WaterDetector` double DEFAULT NULL,
  `DHCX7_PhaseCheck` double DEFAULT NULL,
  `DHCX7_FireSmoke` double DEFAULT NULL,
  `DHCX7_ReturnAirTempHighAlarm` double DEFAULT NULL,
  `DHCX7_ReturnAirHumidHighAlarm` double DEFAULT NULL,
  `DHCX7_SupplyAirTempHighAlarm` double DEFAULT NULL,
  `DHCX7_SupplyAirHumidHighAlarm` double DEFAULT NULL,
  `DHCX7_WaterTempHighAlarm` double DEFAULT NULL,
  `DHCX7_ReturnAirTempLowAlarm` double DEFAULT NULL,
  `DHCX7_ReturnAirHumidLowAlarm` double DEFAULT NULL,
  `DHCX7_SupplyAirTempLowAlarm` double DEFAULT NULL,
  `DHCX7_SupplyAirHumidLowAlarm` double DEFAULT NULL,
  `DHCX7_WaterTempLowAlarm` double DEFAULT NULL,
  `DHCX7_FreezeAlarm` double DEFAULT NULL,
  `DHCX7_UnitRuntimeUnit` double DEFAULT NULL,
  `DHCX7_UnitSetpointTemperatureDay` double DEFAULT NULL,
  `DHCX7_UnitSetpointTemperatureNight` double DEFAULT NULL,
  `DHCX7_UnitSetpointHumidity` double DEFAULT NULL,
  `DHCX7_UnitReturnAirTemperature` double DEFAULT NULL,
  `DHCX7_UnitReturnAirHumidity` double DEFAULT NULL,
  `DHCX8_CommonAlarm` double DEFAULT NULL,
  `DHCX8_UnitOnOff` double DEFAULT NULL,
  `DHCX8_UnitCooling` double DEFAULT NULL,
  `DHCX8_UnitHeating` double DEFAULT NULL,
  `DHCX8_UnitHumidification` double DEFAULT NULL,
  `DHCX8_Airflow1` double DEFAULT NULL,
  `DHCX8_Airflow2` double DEFAULT NULL,
  `DHCX8_Airflow3` double DEFAULT NULL,
  `DHCX8_HighPressure1` double DEFAULT NULL,
  `DHCX8_HighPressure2` double DEFAULT NULL,
  `DHCX8_WaterDetector` double DEFAULT NULL,
  `DHCX8_PhaseCheck` double DEFAULT NULL,
  `DHCX8_FireSmoke` double DEFAULT NULL,
  `DHCX8_ReturnAirTempHighAlarm` double DEFAULT NULL,
  `DHCX8_ReturnAirHumidHighAlarm` double DEFAULT NULL,
  `DHCX8_SupplyAirTempHighAlarm` double DEFAULT NULL,
  `DHCX8_SupplyAirHumidHighAlarm` double DEFAULT NULL,
  `DHCX8_WaterTempHighAlarm` double DEFAULT NULL,
  `DHCX8_ReturnAirTempLowAlarm` double DEFAULT NULL,
  `DHCX8_ReturnAirHumidLowAlarm` double DEFAULT NULL,
  `DHCX8_SupplyAirTempLowAlarm` double DEFAULT NULL,
  `DHCX8_SupplyAirHumidLowAlarm` double DEFAULT NULL,
  `DHCX8_WaterTempLowAlarm` double DEFAULT NULL,
  `DHCX8_FreezeAlarm` double DEFAULT NULL,
  `DHCX8_UnitRuntimeUnit` double DEFAULT NULL,
  `DHCX8_UnitSetpointTemperatureDay` double DEFAULT NULL,
  `DHCX8_UnitSetpointTemperatureNight` double DEFAULT NULL,
  `DHCX8_UnitSetpointHumidity` double DEFAULT NULL,
  `DHCX8_UnitReturnAirTemperature` double DEFAULT NULL,
  `DHCX8_UnitReturnAirHumidity` double DEFAULT NULL,
  `PM1_1_kWh` double DEFAULT NULL,
  `PM1_1_pf` double DEFAULT NULL,
  `PM1_1_kW` double DEFAULT NULL,
  `PM1_1_kVA` double DEFAULT NULL,
  `PM1_1_F` double DEFAULT NULL,
  `PM1_1_I1` double DEFAULT NULL,
  `PM1_1_I2` double DEFAULT NULL,
  `PM1_1_I3` double DEFAULT NULL,
  `PM1_1_In` double DEFAULT NULL,
  `PM1_1_V12` double DEFAULT NULL,
  `PM1_1_V23` double DEFAULT NULL,
  `PM1_1_V31` double DEFAULT NULL,
  `PM1_1_V1` double DEFAULT NULL,
  `PM1_1_V2` double DEFAULT NULL,
  `PM1_1_V3` double DEFAULT NULL,
  `PM1_1_kW1` double DEFAULT NULL,
  `PM1_1_kW2` double DEFAULT NULL,
  `PM1_1_kW3` double DEFAULT NULL,
  `PM1_1_kVA1` double DEFAULT NULL,
  `PM1_1_kVA2` double DEFAULT NULL,
  `PM1_1_kVA3` double DEFAULT NULL,
  `PM1_1_THD_I1` double DEFAULT NULL,
  `PM1_1_THD_I2` double DEFAULT NULL,
  `PM1_1_THD_I3` double DEFAULT NULL,
  `PM1_1_THD_V1` double DEFAULT NULL,
  `PM1_1_THD_V2` double DEFAULT NULL,
  `PM1_1_THD_V3` double DEFAULT NULL,
  `PM1_1_THD_V12` double DEFAULT NULL,
  `PM1_1_THD_V23` double DEFAULT NULL,
  `PM1_1_THD_V31` double DEFAULT NULL,
  `PM1_1_Hour` double DEFAULT NULL,
  `PM1_1_Min` double DEFAULT NULL,
  `PM1_2_kWh` double DEFAULT NULL,
  `PM1_2_pf` double DEFAULT NULL,
  `PM1_2_kW` double DEFAULT NULL,
  `PM1_2_kVA` double DEFAULT NULL,
  `PM1_2_F` double DEFAULT NULL,
  `PM1_2_I1` double DEFAULT NULL,
  `PM1_2_I2` double DEFAULT NULL,
  `PM1_2_I3` double DEFAULT NULL,
  `PM1_2_In` double DEFAULT NULL,
  `PM1_2_V12` double DEFAULT NULL,
  `PM1_2_V23` double DEFAULT NULL,
  `PM1_2_V31` double DEFAULT NULL,
  `PM1_2_V1` double DEFAULT NULL,
  `PM1_2_V2` double DEFAULT NULL,
  `PM1_2_V3` double DEFAULT NULL,
  `PM1_2_kW1` double DEFAULT NULL,
  `PM1_2_kW2` double DEFAULT NULL,
  `PM1_2_kW3` double DEFAULT NULL,
  `PM1_2_kVA1` double DEFAULT NULL,
  `PM1_2_kVA2` double DEFAULT NULL,
  `PM1_2_kVA3` double DEFAULT NULL,
  `PM1_2_THD_I1` double DEFAULT NULL,
  `PM1_2_THD_I2` double DEFAULT NULL,
  `PM1_2_THD_I3` double DEFAULT NULL,
  `PM1_2_THD_V1` double DEFAULT NULL,
  `PM1_2_THD_V2` double DEFAULT NULL,
  `PM1_2_THD_V3` double DEFAULT NULL,
  `PM1_2_THD_V12` double DEFAULT NULL,
  `PM1_2_THD_V23` double DEFAULT NULL,
  `PM1_2_THD_V31` double DEFAULT NULL,
  `PM1_2_Hour` double DEFAULT NULL,
  `PM1_2_Min` double DEFAULT NULL,
  `PM1_3_kWh` double DEFAULT NULL,
  `PM1_3_pf` double DEFAULT NULL,
  `PM1_3_kW` double DEFAULT NULL,
  `PM1_3_kVA` double DEFAULT NULL,
  `PM1_3_F` double DEFAULT NULL,
  `PM1_3_I1` double DEFAULT NULL,
  `PM1_3_I2` double DEFAULT NULL,
  `PM1_3_I3` double DEFAULT NULL,
  `PM1_3_In` double DEFAULT NULL,
  `PM1_3_V12` double DEFAULT NULL,
  `PM1_3_V23` double DEFAULT NULL,
  `PM1_3_V31` double DEFAULT NULL,
  `PM1_3_V1` double DEFAULT NULL,
  `PM1_3_V2` double DEFAULT NULL,
  `PM1_3_V3` double DEFAULT NULL,
  `PM1_3_kW1` double DEFAULT NULL,
  `PM1_3_kW2` double DEFAULT NULL,
  `PM1_3_kW3` double DEFAULT NULL,
  `PM1_3_kVA1` double DEFAULT NULL,
  `PM1_3_kVA2` double DEFAULT NULL,
  `PM1_3_kVA3` double DEFAULT NULL,
  `PM1_3_THD_I1` double DEFAULT NULL,
  `PM1_3_THD_I2` double DEFAULT NULL,
  `PM1_3_THD_I3` double DEFAULT NULL,
  `PM1_3_THD_V1` double DEFAULT NULL,
  `PM1_3_THD_V2` double DEFAULT NULL,
  `PM1_3_THD_V3` double DEFAULT NULL,
  `PM1_3_THD_V12` double DEFAULT NULL,
  `PM1_3_THD_V23` double DEFAULT NULL,
  `PM1_3_THD_V31` double DEFAULT NULL,
  `PM1_3_Hour` double DEFAULT NULL,
  `PM1_3_Min` double DEFAULT NULL,
  `PM1_4_kWh` double DEFAULT NULL,
  `PM1_4_pf` double DEFAULT NULL,
  `PM1_4_kW` double DEFAULT NULL,
  `PM1_4_kVA` double DEFAULT NULL,
  `PM1_4_F` double DEFAULT NULL,
  `PM1_4_I1` double DEFAULT NULL,
  `PM1_4_I2` double DEFAULT NULL,
  `PM1_4_I3` double DEFAULT NULL,
  `PM1_4_In` double DEFAULT NULL,
  `PM1_4_V12` double DEFAULT NULL,
  `PM1_4_V23` double DEFAULT NULL,
  `PM1_4_V31` double DEFAULT NULL,
  `PM1_4_V1` double DEFAULT NULL,
  `PM1_4_V2` double DEFAULT NULL,
  `PM1_4_V3` double DEFAULT NULL,
  `PM1_4_kW1` double DEFAULT NULL,
  `PM1_4_kW2` double DEFAULT NULL,
  `PM1_4_kW3` double DEFAULT NULL,
  `PM1_4_kVA1` double DEFAULT NULL,
  `PM1_4_kVA2` double DEFAULT NULL,
  `PM1_4_kVA3` double DEFAULT NULL,
  `PM1_4_THD_I1` double DEFAULT NULL,
  `PM1_4_THD_I2` double DEFAULT NULL,
  `PM1_4_THD_I3` double DEFAULT NULL,
  `PM1_4_THD_V1` double DEFAULT NULL,
  `PM1_4_THD_V2` double DEFAULT NULL,
  `PM1_4_THD_V3` double DEFAULT NULL,
  `PM1_4_THD_V12` double DEFAULT NULL,
  `PM1_4_THD_V23` double DEFAULT NULL,
  `PM1_4_THD_V31` double DEFAULT NULL,
  `PM1_4_Hour` double DEFAULT NULL,
  `PM1_4_Min` double DEFAULT NULL,
  `PM1_6_kWh` double DEFAULT NULL,
  `PM1_6_pf` double DEFAULT NULL,
  `PM1_6_kW` double DEFAULT NULL,
  `PM1_6_kVA` double DEFAULT NULL,
  `PM1_6_F` double DEFAULT NULL,
  `PM1_6_I1` double DEFAULT NULL,
  `PM1_6_I2` double DEFAULT NULL,
  `PM1_6_I3` double DEFAULT NULL,
  `PM1_6_In` double DEFAULT NULL,
  `PM1_6_V12` double DEFAULT NULL,
  `PM1_6_V23` double DEFAULT NULL,
  `PM1_6_V31` double DEFAULT NULL,
  `PM1_6_V1` double DEFAULT NULL,
  `PM1_6_V2` double DEFAULT NULL,
  `PM1_6_V3` double DEFAULT NULL,
  `PM1_6_kW1` double DEFAULT NULL,
  `PM1_6_kW2` double DEFAULT NULL,
  `PM1_6_kW3` double DEFAULT NULL,
  `PM1_6_kVA1` double DEFAULT NULL,
  `PM1_6_kVA2` double DEFAULT NULL,
  `PM1_6_kVA3` double DEFAULT NULL,
  `PM1_6_THD_I1` double DEFAULT NULL,
  `PM1_6_THD_I2` double DEFAULT NULL,
  `PM1_6_THD_I3` double DEFAULT NULL,
  `PM1_6_THD_V1` double DEFAULT NULL,
  `PM1_6_THD_V2` double DEFAULT NULL,
  `PM1_6_THD_V3` double DEFAULT NULL,
  `PM1_6_THD_V12` double DEFAULT NULL,
  `PM1_6_THD_V23` double DEFAULT NULL,
  `PM1_6_THD_V31` double DEFAULT NULL,
  `PM1_6_Hour` double DEFAULT NULL,
  `PM1_6_Min` double DEFAULT NULL,
  `PM1_7_kWh` double DEFAULT NULL,
  `PM1_7_pf` double DEFAULT NULL,
  `PM1_7_kW` double DEFAULT NULL,
  `PM1_7_kVA` double DEFAULT NULL,
  `PM1_7_F` double DEFAULT NULL,
  `PM1_7_I1` double DEFAULT NULL,
  `PM1_7_I2` double DEFAULT NULL,
  `PM1_7_I3` double DEFAULT NULL,
  `PM1_7_In` double DEFAULT NULL,
  `PM1_7_V12` double DEFAULT NULL,
  `PM1_7_V23` double DEFAULT NULL,
  `PM1_7_V31` double DEFAULT NULL,
  `PM1_7_V1` double DEFAULT NULL,
  `PM1_7_V2` double DEFAULT NULL,
  `PM1_7_V3` double DEFAULT NULL,
  `PM1_7_kW1` double DEFAULT NULL,
  `PM1_7_kW2` double DEFAULT NULL,
  `PM1_7_kW3` double DEFAULT NULL,
  `PM1_7_kVA1` double DEFAULT NULL,
  `PM1_7_kVA2` double DEFAULT NULL,
  `PM1_7_kVA3` double DEFAULT NULL,
  `PM1_7_THD_I1` double DEFAULT NULL,
  `PM1_7_THD_I2` double DEFAULT NULL,
  `PM1_7_THD_I3` double DEFAULT NULL,
  `PM1_7_THD_V1` double DEFAULT NULL,
  `PM1_7_THD_V2` double DEFAULT NULL,
  `PM1_7_THD_V3` double DEFAULT NULL,
  `PM1_7_THD_V12` double DEFAULT NULL,
  `PM1_7_THD_V23` double DEFAULT NULL,
  `PM1_7_THD_V31` double DEFAULT NULL,
  `PM1_7_Hour` double DEFAULT NULL,
  `PM1_7_Min` double DEFAULT NULL,
  `PM1_8_kWh` double DEFAULT NULL,
  `PM1_8_pf` double DEFAULT NULL,
  `PM1_8_kW` double DEFAULT NULL,
  `PM1_8_kVA` double DEFAULT NULL,
  `PM1_8_F` double DEFAULT NULL,
  `PM1_8_I1` double DEFAULT NULL,
  `PM1_8_I2` double DEFAULT NULL,
  `PM1_8_I3` double DEFAULT NULL,
  `PM1_8_In` double DEFAULT NULL,
  `PM1_8_V12` double DEFAULT NULL,
  `PM1_8_V23` double DEFAULT NULL,
  `PM1_8_V31` double DEFAULT NULL,
  `PM1_8_V1` double DEFAULT NULL,
  `PM1_8_V2` double DEFAULT NULL,
  `PM1_8_V3` double DEFAULT NULL,
  `PM1_8_kW1` double DEFAULT NULL,
  `PM1_8_kW2` double DEFAULT NULL,
  `PM1_8_kW3` double DEFAULT NULL,
  `PM1_8_kVA1` double DEFAULT NULL,
  `PM1_8_kVA2` double DEFAULT NULL,
  `PM1_8_kVA3` double DEFAULT NULL,
  `PM1_8_THD_I1` double DEFAULT NULL,
  `PM1_8_THD_I2` double DEFAULT NULL,
  `PM1_8_THD_I3` double DEFAULT NULL,
  `PM1_8_THD_V1` double DEFAULT NULL,
  `PM1_8_THD_V2` double DEFAULT NULL,
  `PM1_8_THD_V3` double DEFAULT NULL,
  `PM1_8_THD_V12` double DEFAULT NULL,
  `PM1_8_THD_V23` double DEFAULT NULL,
  `PM1_8_THD_V31` double DEFAULT NULL,
  `PM1_8_Hour` double DEFAULT NULL,
  `PM1_8_Min` double DEFAULT NULL,
  `PM1_9_kWh` double DEFAULT NULL,
  `PM1_9_pf` double DEFAULT NULL,
  `PM1_9_kW` double DEFAULT NULL,
  `PM1_9_kVA` double DEFAULT NULL,
  `PM1_9_F` double DEFAULT NULL,
  `PM1_9_I1` double DEFAULT NULL,
  `PM1_9_I2` double DEFAULT NULL,
  `PM1_9_I3` double DEFAULT NULL,
  `PM1_9_In` double DEFAULT NULL,
  `PM1_9_V12` double DEFAULT NULL,
  `PM1_9_V23` double DEFAULT NULL,
  `PM1_9_V31` double DEFAULT NULL,
  `PM1_9_V1` double DEFAULT NULL,
  `PM1_9_V2` double DEFAULT NULL,
  `PM1_9_V3` double DEFAULT NULL,
  `PM1_9_kW1` double DEFAULT NULL,
  `PM1_9_kW2` double DEFAULT NULL,
  `PM1_9_kW3` double DEFAULT NULL,
  `PM1_9_kVA1` double DEFAULT NULL,
  `PM1_9_kVA2` double DEFAULT NULL,
  `PM1_9_kVA3` double DEFAULT NULL,
  `PM1_9_THD_I1` double DEFAULT NULL,
  `PM1_9_THD_I2` double DEFAULT NULL,
  `PM1_9_THD_I3` double DEFAULT NULL,
  `PM1_9_THD_V1` double DEFAULT NULL,
  `PM1_9_THD_V2` double DEFAULT NULL,
  `PM1_9_THD_V3` double DEFAULT NULL,
  `PM1_9_THD_V12` double DEFAULT NULL,
  `PM1_9_THD_V23` double DEFAULT NULL,
  `PM1_9_THD_V31` double DEFAULT NULL,
  `PM1_9_Hour` double DEFAULT NULL,
  `PM1_9_Min` double DEFAULT NULL,
  `PM1_10_kWh` double DEFAULT NULL,
  `PM1_10_pf` double DEFAULT NULL,
  `PM1_10_kW` double DEFAULT NULL,
  `PM1_10_kVA` double DEFAULT NULL,
  `PM1_10_F` double DEFAULT NULL,
  `PM1_10_I1` double DEFAULT NULL,
  `PM1_10_I2` double DEFAULT NULL,
  `PM1_10_I3` double DEFAULT NULL,
  `PM1_10_In` double DEFAULT NULL,
  `PM1_10_V12` double DEFAULT NULL,
  `PM1_10_V23` double DEFAULT NULL,
  `PM1_10_V31` double DEFAULT NULL,
  `PM1_10_V1` double DEFAULT NULL,
  `PM1_10_V2` double DEFAULT NULL,
  `PM1_10_V3` double DEFAULT NULL,
  `PM1_10_kW1` double DEFAULT NULL,
  `PM1_10_kW2` double DEFAULT NULL,
  `PM1_10_kW3` double DEFAULT NULL,
  `PM1_10_kVA1` double DEFAULT NULL,
  `PM1_10_kVA2` double DEFAULT NULL,
  `PM1_10_kVA3` double DEFAULT NULL,
  `PM1_10_THD_I1` double DEFAULT NULL,
  `PM1_10_THD_I2` double DEFAULT NULL,
  `PM1_10_THD_I3` double DEFAULT NULL,
  `PM1_10_THD_V1` double DEFAULT NULL,
  `PM1_10_THD_V2` double DEFAULT NULL,
  `PM1_10_THD_V3` double DEFAULT NULL,
  `PM1_10_THD_V12` double DEFAULT NULL,
  `PM1_10_THD_V23` double DEFAULT NULL,
  `PM1_10_THD_V31` double DEFAULT NULL,
  `PM1_10_Hour` double DEFAULT NULL,
  `PM1_10_Min` double DEFAULT NULL,
  `PM1_11_kWh` double DEFAULT NULL,
  `PM1_11_pf` double DEFAULT NULL,
  `PM1_11_kW` double DEFAULT NULL,
  `PM1_11_kVA` double DEFAULT NULL,
  `PM1_11_F` double DEFAULT NULL,
  `PM1_11_I1` double DEFAULT NULL,
  `PM1_11_I2` double DEFAULT NULL,
  `PM1_11_I3` double DEFAULT NULL,
  `PM1_11_In` double DEFAULT NULL,
  `PM1_11_V12` double DEFAULT NULL,
  `PM1_11_V23` double DEFAULT NULL,
  `PM1_11_V31` double DEFAULT NULL,
  `PM1_11_V1` double DEFAULT NULL,
  `PM1_11_V2` double DEFAULT NULL,
  `PM1_11_V3` double DEFAULT NULL,
  `PM1_11_kW1` double DEFAULT NULL,
  `PM1_11_kW2` double DEFAULT NULL,
  `PM1_11_kW3` double DEFAULT NULL,
  `PM1_11_kVA1` double DEFAULT NULL,
  `PM1_11_kVA2` double DEFAULT NULL,
  `PM1_11_kVA3` double DEFAULT NULL,
  `PM1_11_THD_I1` double DEFAULT NULL,
  `PM1_11_THD_I2` double DEFAULT NULL,
  `PM1_11_THD_I3` double DEFAULT NULL,
  `PM1_11_THD_V1` double DEFAULT NULL,
  `PM1_11_THD_V2` double DEFAULT NULL,
  `PM1_11_THD_V3` double DEFAULT NULL,
  `PM1_11_THD_V12` double DEFAULT NULL,
  `PM1_11_THD_V23` double DEFAULT NULL,
  `PM1_11_THD_V31` double DEFAULT NULL,
  `PM1_11_Hour` double DEFAULT NULL,
  `PM1_11_Min` double DEFAULT NULL,
  `PM2_1_pf` double DEFAULT NULL,
  `PM2_1_F` double DEFAULT NULL,
  `PM2_1_I1` double DEFAULT NULL,
  `PM2_1_I2` double DEFAULT NULL,
  `PM2_1_I3` double DEFAULT NULL,
  `PM2_1_In` double DEFAULT NULL,
  `PM2_1_V12` double DEFAULT NULL,
  `PM2_1_V23` double DEFAULT NULL,
  `PM2_1_V31` double DEFAULT NULL,
  `PM2_1_V1` double DEFAULT NULL,
  `PM2_1_V2` double DEFAULT NULL,
  `PM2_1_V3` double DEFAULT NULL,
  `PM2_1_kW` double DEFAULT NULL,
  `PM2_1_kW1` double DEFAULT NULL,
  `PM2_1_kW2` double DEFAULT NULL,
  `PM2_1_kW3` double DEFAULT NULL,
  `PM2_1_kVA` double DEFAULT NULL,
  `PM2_1_kVA1` double DEFAULT NULL,
  `PM2_1_kVA2` double DEFAULT NULL,
  `PM2_1_kVA3` double DEFAULT NULL,
  `PM2_1_THD_I1` double DEFAULT NULL,
  `PM2_1_THD_I2` double DEFAULT NULL,
  `PM2_1_THD_I3` double DEFAULT NULL,
  `PM2_1_THD_V1` double DEFAULT NULL,
  `PM2_1_THD_V2` double DEFAULT NULL,
  `PM2_1_THD_V3` double DEFAULT NULL,
  `PM2_1_THD_V12` double DEFAULT NULL,
  `PM2_1_THD_V23` double DEFAULT NULL,
  `PM2_1_THD_V31` double DEFAULT NULL,
  `PM1_12_kWh` double DEFAULT NULL,
  `PM1_12_pf` double DEFAULT NULL,
  `PM1_12_kW` double DEFAULT NULL,
  `PM1_12_kVA` double DEFAULT NULL,
  `PM1_12_F` double DEFAULT NULL,
  `PM1_12_I1` double DEFAULT NULL,
  `PM1_12_I2` double DEFAULT NULL,
  `PM1_12_I3` double DEFAULT NULL,
  `PM1_12_In` double DEFAULT NULL,
  `PM1_12_V12` double DEFAULT NULL,
  `PM1_12_V23` double DEFAULT NULL,
  `PM1_12_V31` double DEFAULT NULL,
  `PM1_12_V1` double DEFAULT NULL,
  `PM1_12_V2` double DEFAULT NULL,
  `PM1_12_V3` double DEFAULT NULL,
  `PM1_12_kW1` double DEFAULT NULL,
  `PM1_12_kW2` double DEFAULT NULL,
  `PM1_12_kW3` double DEFAULT NULL,
  `PM1_12_kVA1` double DEFAULT NULL,
  `PM1_12_kVA2` double DEFAULT NULL,
  `PM1_12_kVA3` double DEFAULT NULL,
  `PM1_12_THD_I1` double DEFAULT NULL,
  `PM1_12_THD_I2` double DEFAULT NULL,
  `PM1_12_THD_I3` double DEFAULT NULL,
  `PM1_12_THD_V1` double DEFAULT NULL,
  `PM1_12_THD_V2` double DEFAULT NULL,
  `PM1_12_THD_V3` double DEFAULT NULL,
  `PM1_12_THD_V12` double DEFAULT NULL,
  `PM1_12_THD_V23` double DEFAULT NULL,
  `PM1_12_THD_V31` double DEFAULT NULL,
  `PM1_12_Hour` double DEFAULT NULL,
  `PM1_12_Min` double DEFAULT NULL,
  `PM2_2_pf` double DEFAULT NULL,
  `PM2_2_F` double DEFAULT NULL,
  `PM2_2_I1` double DEFAULT NULL,
  `PM2_2_I2` double DEFAULT NULL,
  `PM2_2_I3` double DEFAULT NULL,
  `PM2_2_In` double DEFAULT NULL,
  `PM2_2_V12` double DEFAULT NULL,
  `PM2_2_V23` double DEFAULT NULL,
  `PM2_2_V31` double DEFAULT NULL,
  `PM2_2_V1` double DEFAULT NULL,
  `PM2_2_V2` double DEFAULT NULL,
  `PM2_2_V3` double DEFAULT NULL,
  `PM2_2_kW` double DEFAULT NULL,
  `PM2_2_kW1` double DEFAULT NULL,
  `PM2_2_kW2` double DEFAULT NULL,
  `PM2_2_kW3` double DEFAULT NULL,
  `PM2_2_kVA` double DEFAULT NULL,
  `PM2_2_kVA1` double DEFAULT NULL,
  `PM2_2_kVA2` double DEFAULT NULL,
  `PM2_2_kVA3` double DEFAULT NULL,
  `PM2_2_THD_I1` double DEFAULT NULL,
  `PM2_2_THD_I2` double DEFAULT NULL,
  `PM2_2_THD_I3` double DEFAULT NULL,
  `PM2_2_THD_V1` double DEFAULT NULL,
  `PM2_2_THD_V2` double DEFAULT NULL,
  `PM2_2_THD_V3` double DEFAULT NULL,
  `PM2_2_THD_V12` double DEFAULT NULL,
  `PM2_2_THD_V23` double DEFAULT NULL,
  `PM2_2_THD_V31` double DEFAULT NULL,
  `PM1_13_kWh` double DEFAULT NULL,
  `PM1_13_pf` double DEFAULT NULL,
  `PM1_13_kW` double DEFAULT NULL,
  `PM1_13_kVA` double DEFAULT NULL,
  `PM1_13_F` double DEFAULT NULL,
  `PM1_13_I1` double DEFAULT NULL,
  `PM1_13_I2` double DEFAULT NULL,
  `PM1_13_I3` double DEFAULT NULL,
  `PM1_13_In` double DEFAULT NULL,
  `PM1_13_V12` double DEFAULT NULL,
  `PM1_13_V23` double DEFAULT NULL,
  `PM1_13_V31` double DEFAULT NULL,
  `PM1_13_V1` double DEFAULT NULL,
  `PM1_13_V2` double DEFAULT NULL,
  `PM1_13_V3` double DEFAULT NULL,
  `PM1_13_kW1` double DEFAULT NULL,
  `PM1_13_kW2` double DEFAULT NULL,
  `PM1_13_kW3` double DEFAULT NULL,
  `PM1_13_kVA1` double DEFAULT NULL,
  `PM1_13_kVA2` double DEFAULT NULL,
  `PM1_13_kVA3` double DEFAULT NULL,
  `PM1_13_THD_I1` double DEFAULT NULL,
  `PM1_13_THD_I2` double DEFAULT NULL,
  `PM1_13_THD_I3` double DEFAULT NULL,
  `PM1_13_THD_V1` double DEFAULT NULL,
  `PM1_13_THD_V2` double DEFAULT NULL,
  `PM1_13_THD_V3` double DEFAULT NULL,
  `PM1_13_THD_V12` double DEFAULT NULL,
  `PM1_13_THD_V23` double DEFAULT NULL,
  `PM1_13_THD_V31` double DEFAULT NULL,
  `PM1_13_Hour` double DEFAULT NULL,
  `PM1_13_Min` double DEFAULT NULL,
  `PM1_14_kWh` double DEFAULT NULL,
  `PM1_14_pf` double DEFAULT NULL,
  `PM1_14_kW` double DEFAULT NULL,
  `PM1_14_kVA` double DEFAULT NULL,
  `PM1_14_F` double DEFAULT NULL,
  `PM1_14_I1` double DEFAULT NULL,
  `PM1_14_I2` double DEFAULT NULL,
  `PM1_14_I3` double DEFAULT NULL,
  `PM1_14_In` double DEFAULT NULL,
  `PM1_14_V12` double DEFAULT NULL,
  `PM1_14_V23` double DEFAULT NULL,
  `PM1_14_V31` double DEFAULT NULL,
  `PM1_14_V1` double DEFAULT NULL,
  `PM1_14_V2` double DEFAULT NULL,
  `PM1_14_V3` double DEFAULT NULL,
  `PM1_14_kW1` double DEFAULT NULL,
  `PM1_14_kW2` double DEFAULT NULL,
  `PM1_14_kW3` double DEFAULT NULL,
  `PM1_14_kVA1` double DEFAULT NULL,
  `PM1_14_kVA2` double DEFAULT NULL,
  `PM1_14_kVA3` double DEFAULT NULL,
  `PM1_14_THD_I1` double DEFAULT NULL,
  `PM1_14_THD_I2` double DEFAULT NULL,
  `PM1_14_THD_I3` double DEFAULT NULL,
  `PM1_14_THD_V1` double DEFAULT NULL,
  `PM1_14_THD_V2` double DEFAULT NULL,
  `PM1_14_THD_V3` double DEFAULT NULL,
  `PM1_14_THD_V12` double DEFAULT NULL,
  `PM1_14_THD_V23` double DEFAULT NULL,
  `PM1_14_THD_V31` double DEFAULT NULL,
  `PM1_14_Hour` double DEFAULT NULL,
  `PM1_14_Min` double DEFAULT NULL,
  `PM1_15_kWh` double DEFAULT NULL,
  `PM1_15_pf` double DEFAULT NULL,
  `PM1_15_kW` double DEFAULT NULL,
  `PM1_15_kVA` double DEFAULT NULL,
  `PM1_15_F` double DEFAULT NULL,
  `PM1_15_I1` double DEFAULT NULL,
  `PM1_15_I2` double DEFAULT NULL,
  `PM1_15_I3` double DEFAULT NULL,
  `PM1_15_In` double DEFAULT NULL,
  `PM1_15_V12` double DEFAULT NULL,
  `PM1_15_V23` double DEFAULT NULL,
  `PM1_15_V31` double DEFAULT NULL,
  `PM1_15_V1` double DEFAULT NULL,
  `PM1_15_V2` double DEFAULT NULL,
  `PM1_15_V3` double DEFAULT NULL,
  `PM1_15_kW1` double DEFAULT NULL,
  `PM1_15_kW2` double DEFAULT NULL,
  `PM1_15_kW3` double DEFAULT NULL,
  `PM1_15_kVA1` double DEFAULT NULL,
  `PM1_15_kVA2` double DEFAULT NULL,
  `PM1_15_kVA3` double DEFAULT NULL,
  `PM1_15_THD_I1` double DEFAULT NULL,
  `PM1_15_THD_I2` double DEFAULT NULL,
  `PM1_15_THD_I3` double DEFAULT NULL,
  `PM1_15_THD_V1` double DEFAULT NULL,
  `PM1_15_THD_V2` double DEFAULT NULL,
  `PM1_15_THD_V3` double DEFAULT NULL,
  `PM1_15_THD_V12` double DEFAULT NULL,
  `PM1_15_THD_V23` double DEFAULT NULL,
  `PM1_15_THD_V31` double DEFAULT NULL,
  `PM1_15_Hour` double DEFAULT NULL,
  `PM1_15_Min` double DEFAULT NULL,
  `PM1_16_kWh` double DEFAULT NULL,
  `PM1_16_pf` double DEFAULT NULL,
  `PM1_16_kW` double DEFAULT NULL,
  `PM1_16_kVA` double DEFAULT NULL,
  `PM1_16_F` double DEFAULT NULL,
  `PM1_16_I1` double DEFAULT NULL,
  `PM1_16_I2` double DEFAULT NULL,
  `PM1_16_I3` double DEFAULT NULL,
  `PM1_16_In` double DEFAULT NULL,
  `PM1_16_V12` double DEFAULT NULL,
  `PM1_16_V23` double DEFAULT NULL,
  `PM1_16_V31` double DEFAULT NULL,
  `PM1_16_V1` double DEFAULT NULL,
  `PM1_16_V2` double DEFAULT NULL,
  `PM1_16_V3` double DEFAULT NULL,
  `PM1_16_kW1` double DEFAULT NULL,
  `PM1_16_kW2` double DEFAULT NULL,
  `PM1_16_kW3` double DEFAULT NULL,
  `PM1_16_kVA1` double DEFAULT NULL,
  `PM1_16_kVA2` double DEFAULT NULL,
  `PM1_16_kVA3` double DEFAULT NULL,
  `PM1_16_THD_I1` double DEFAULT NULL,
  `PM1_16_THD_I2` double DEFAULT NULL,
  `PM1_16_THD_I3` double DEFAULT NULL,
  `PM1_16_THD_V1` double DEFAULT NULL,
  `PM1_16_THD_V2` double DEFAULT NULL,
  `PM1_16_THD_V3` double DEFAULT NULL,
  `PM1_16_THD_V12` double DEFAULT NULL,
  `PM1_16_THD_V23` double DEFAULT NULL,
  `PM1_16_THD_V31` double DEFAULT NULL,
  `PM1_16_Hour` double DEFAULT NULL,
  `PM1_16_Min` double DEFAULT NULL,
  `GENSET1_V12` double DEFAULT NULL,
  `GENSET1_V23` double DEFAULT NULL,
  `GENSET1_V31` double DEFAULT NULL,
  `GENSET1_V1` double DEFAULT NULL,
  `GENSET1_V2` double DEFAULT NULL,
  `GENSET1_V3` double DEFAULT NULL,
  `GENSET1_F1` double DEFAULT NULL,
  `GENSET1_F2` double DEFAULT NULL,
  `GENSET1_F3` double DEFAULT NULL,
  `GENSET1_I1` double DEFAULT NULL,
  `GENSET1_I2` double DEFAULT NULL,
  `GENSET1_I3` double DEFAULT NULL,
  `GENSET1_kW1` double DEFAULT NULL,
  `GENSET1_kW2` double DEFAULT NULL,
  `GENSET1_kW3` double DEFAULT NULL,
  `GENSET1_kW` double DEFAULT NULL,
  `GENSET1_kVA1` double DEFAULT NULL,
  `GENSET1_kVA2` double DEFAULT NULL,
  `GENSET1_kVA3` double DEFAULT NULL,
  `GENSET1_kVA` double DEFAULT NULL,
  `GENSET1_kWh` double DEFAULT NULL,
  `GENSET1_pf` double DEFAULT NULL,
  `GENSET1_Hour` double DEFAULT NULL,
  `GENSET1_Alarms` double DEFAULT NULL,
  `GENSET2_V12` double DEFAULT NULL,
  `GENSET2_V23` double DEFAULT NULL,
  `GENSET2_V31` double DEFAULT NULL,
  `GENSET2_V1` double DEFAULT NULL,
  `GENSET2_V2` double DEFAULT NULL,
  `GENSET2_V3` double DEFAULT NULL,
  `GENSET2_F1` double DEFAULT NULL,
  `GENSET2_F2` double DEFAULT NULL,
  `GENSET2_F3` double DEFAULT NULL,
  `GENSET2_I1` double DEFAULT NULL,
  `GENSET2_I2` double DEFAULT NULL,
  `GENSET2_I3` double DEFAULT NULL,
  `GENSET2_kW1` double DEFAULT NULL,
  `GENSET2_kW2` double DEFAULT NULL,
  `GENSET2_kW3` double DEFAULT NULL,
  `GENSET2_kW` double DEFAULT NULL,
  `GENSET2_kVA1` double DEFAULT NULL,
  `GENSET2_kVA2` double DEFAULT NULL,
  `GENSET2_kVA3` double DEFAULT NULL,
  `GENSET2_kVA` double DEFAULT NULL,
  `GENSET2_kWh` double DEFAULT NULL,
  `GENSET2_pf` double DEFAULT NULL,
  `GENSET2_Hour` double DEFAULT NULL,
  `GENSET2_Alarms` double DEFAULT NULL,
  `PM1_17_pf` double DEFAULT NULL,
  `PM1_17_F` double DEFAULT NULL,
  `PM1_17_I1` double DEFAULT NULL,
  `PM1_17_I2` double DEFAULT NULL,
  `PM1_17_I3` double DEFAULT NULL,
  `PM1_17_V12` double DEFAULT NULL,
  `PM1_17_V23` double DEFAULT NULL,
  `PM1_17_V31` double DEFAULT NULL,
  `PM1_17_V1` double DEFAULT NULL,
  `PM1_17_V2` double DEFAULT NULL,
  `PM1_17_V3` double DEFAULT NULL,
  `PM1_18_pf` double DEFAULT NULL,
  `PM1_18_F` double DEFAULT NULL,
  `PM1_18_I1` double DEFAULT NULL,
  `PM1_18_I2` double DEFAULT NULL,
  `PM1_18_I3` double DEFAULT NULL,
  `PM1_18_V12` double DEFAULT NULL,
  `PM1_18_V23` double DEFAULT NULL,
  `PM1_18_V31` double DEFAULT NULL,
  `PM1_18_V1` double DEFAULT NULL,
  `PM1_18_V2` double DEFAULT NULL,
  `PM1_18_V3` double DEFAULT NULL,
  `HSSD_channel0` double DEFAULT NULL,
  `HSSD_channel1` double DEFAULT NULL,
  `HSSD_channel2` double DEFAULT NULL,
  `HSSD_channel3` double DEFAULT NULL,
  `HSSD_channel4` double DEFAULT NULL,
  `HSSD_channel5` double DEFAULT NULL,
  `HSSD_channel6` double DEFAULT NULL,
  `HSSD_channel7` double DEFAULT NULL,
  `LASER_channel0` double DEFAULT NULL,
  `LASER_channel1` double DEFAULT NULL,
  `LASER_channel2` double DEFAULT NULL,
  `LASER_channel3` double DEFAULT NULL,
  `LASER_channel4` double DEFAULT NULL,
  `LASER_channel5` double DEFAULT NULL,
  `LASER_channel6` double DEFAULT NULL,
  `LASER_channel7` double DEFAULT NULL,
  `LLD_channel0` double DEFAULT NULL,
  `LLD_channel1` double DEFAULT NULL,
  `LLD_channel2` double DEFAULT NULL,
  `LLD_channel3` double DEFAULT NULL,
  `LLD_channel4` double DEFAULT NULL,
  `LLD_channel5` double DEFAULT NULL,
  `LLD_channel6` double DEFAULT NULL,
  `LLD_channel7` double DEFAULT NULL,
  `UPS1_EstimatedChargeRemaining` double DEFAULT NULL,
  `UPS1_OutputSource` double DEFAULT NULL,
  `UPS1_BypassFrequency` double DEFAULT NULL,
  `UPS1_OutputFrequency` double DEFAULT NULL,
  `UPS1_BatteryStatus` double DEFAULT NULL,
  `UPS1_BatteryTemperature` double DEFAULT NULL,
  `UPS1_BatteryVoltage` double DEFAULT NULL,
  `UPS1_BatteryCurrent` double DEFAULT NULL,
  `UPS2_EstimatedMinutesRemaining` double DEFAULT NULL,
  `UPS2_EstimatedChargeRemaining` double DEFAULT NULL,
  `UPS2_OutputSource` double DEFAULT NULL,
  `UPS2_BypassFrequency` double DEFAULT NULL,
  `UPS2_OutputFrequency` double DEFAULT NULL,
  `UPS2_BatteryStatus` double DEFAULT NULL,
  `UPS2_BatteryTemperature` double DEFAULT NULL,
  `UPS2_BatteryVoltage` double DEFAULT NULL,
  `UPS2_BatteryCurrent` double DEFAULT NULL,
  `UPS3_EstimatedMinutesRemaining` double DEFAULT NULL,
  `UPS3_EstimatedChargeRemaining` double DEFAULT NULL,
  `UPS3_OutputSource` double DEFAULT NULL,
  `UPS3_BypassFrequency` double DEFAULT NULL,
  `UPS3_OutputFrequency` double DEFAULT NULL,
  `UPS3_BatteryStatus` double DEFAULT NULL,
  `UPS3_BatteryTemperature` double DEFAULT NULL,
  `UPS3_BatteryVoltage` double DEFAULT NULL,
  `UPS3_BatteryCurrent` double DEFAULT NULL,
  `UPS4_EstimatedMinutesRemaining` double DEFAULT NULL,
  `UPS4_EstimatedChargeRemaining` double DEFAULT NULL,
  `UPS4_OutputSource` double DEFAULT NULL,
  `UPS4_BypassFrequency` double DEFAULT NULL,
  `UPS4_OutputFrequency` double DEFAULT NULL,
  `UPS4_BatteryStatus` double DEFAULT NULL,
  `UPS4_BatteryTemperature` double DEFAULT NULL,
  `UPS4_BatteryVoltage` double DEFAULT NULL,
  `UPS4_BatteryCurrent` double DEFAULT NULL,
  `REC1_systemStatus` double DEFAULT NULL,
  `REC1_systemVoltage` double DEFAULT NULL,
  `REC1_systemCurrent` double DEFAULT NULL,
  `REC1_systemUsedCapacity` double DEFAULT NULL,
  `REC1_psStatusCommunication` double DEFAULT NULL,
  `REC1_psTemperature1` double DEFAULT NULL,
  `REC1_psBatteryVoltage` double DEFAULT NULL,
  `REC1_psTotalBatteryCurrent` double DEFAULT NULL,
  `REC2_systemStatus` double DEFAULT NULL,
  `REC2_systemVoltage` double DEFAULT NULL,
  `REC2_systemCurrent` double DEFAULT NULL,
  `REC2_systemUsedCapacity` double DEFAULT NULL,
  `REC2_psStatusCommunication` double DEFAULT NULL,
  `REC2_psTemperature1` double DEFAULT NULL,
  `REC2_psBatteryVoltage` double DEFAULT NULL,
  `REC2_psTotalBatteryCurrent` double DEFAULT NULL,
  `REC3_systemStatus` double DEFAULT NULL,
  `REC3_systemVoltage` double DEFAULT NULL,
  `REC3_systemCurrent` double DEFAULT NULL,
  `REC3_systemUsedCapacity` double DEFAULT NULL,
  `REC3_psStatusCommunication` double DEFAULT NULL,
  `REC3_psTemperature1` double DEFAULT NULL,
  `REC3_psBatteryVoltage` double DEFAULT NULL,
  `REC3_psTotalBatteryCurrent` double DEFAULT NULL,
  `REC4_systemStatus` double DEFAULT NULL,
  `REC4_systemVoltage` double DEFAULT NULL,
  `REC4_systemCurrent` double DEFAULT NULL,
  `REC4_systemUsedCapacity` double DEFAULT NULL,
  `REC4_psStatusCommunication` double DEFAULT NULL,
  `REC4_psTemperature1` double DEFAULT NULL,
  `REC4_psBatteryVoltage` double DEFAULT NULL,
  `REC4_psTotalBatteryCurrent` double DEFAULT NULL,
  `REC5_systemStatus` double DEFAULT NULL,
  `REC5_systemVoltage` double DEFAULT NULL,
  `REC5_systemCurrent` double DEFAULT NULL,
  `REC5_systemUsedCapacity` double DEFAULT NULL,
  `REC5_psStatusCommunication` double DEFAULT NULL,
  `REC5_psTemperature1` double DEFAULT NULL,
  `REC5_psBatteryVoltage` double DEFAULT NULL,
  `REC5_psTotalBatteryCurrent` double DEFAULT NULL,
  `REC6_systemStatus` double DEFAULT NULL,
  `REC6_systemVoltage` double DEFAULT NULL,
  `REC6_systemCurrent` double DEFAULT NULL,
  `REC6_systemUsedCapacity` double DEFAULT NULL,
  `REC6_psStatusCommunication` double DEFAULT NULL,
  `REC6_psTemperature1` double DEFAULT NULL,
  `REC6_psBatteryVoltage` double DEFAULT NULL,
  `REC6_psTotalBatteryCurrent` double DEFAULT NULL,
  `REC1_psInputLineAVoltage` double DEFAULT NULL,
  `REC1_psInputLineBVoltage` double DEFAULT NULL,
  `REC1_psInputLineCVoltage` double DEFAULT NULL,
  `REC1_psStatusBatteryMode` double DEFAULT NULL,
  `REC2_psInputLineAVoltage` double DEFAULT NULL,
  `REC2_psInputLineBVoltage` double DEFAULT NULL,
  `REC2_psInputLineCVoltage` double DEFAULT NULL,
  `REC2_psStatusBatteryMode` double DEFAULT NULL,
  `REC3_psInputLineAVoltage` double DEFAULT NULL,
  `REC3_psInputLineBVoltage` double DEFAULT NULL,
  `REC3_psInputLineCVoltage` double DEFAULT NULL,
  `REC3_psStatusBatteryMode` double DEFAULT NULL,
  `REC4_psInputLineAVoltage` double DEFAULT NULL,
  `REC4_psInputLineBVoltage` double DEFAULT NULL,
  `REC4_psInputLineCVoltage` double DEFAULT NULL,
  `REC4_psStatusBatteryMode` double DEFAULT NULL,
  `REC5_psInputLineAVoltage` double DEFAULT NULL,
  `REC5_psInputLineBVoltage` double DEFAULT NULL,
  `REC5_psInputLineCVoltage` double DEFAULT NULL,
  `REC5_psStatusBatteryMode` double DEFAULT NULL,
  `REC6_psInputLineAVoltage` double DEFAULT NULL,
  `REC6_psInputLineBVoltage` double DEFAULT NULL,
  `REC6_psInputLineCVoltage` double DEFAULT NULL,
  `REC6_psStatusBatteryMode` double DEFAULT NULL,
  `UPS1_InputFrequency01` double DEFAULT NULL,
  `UPS1_InputFrequency02` double DEFAULT NULL,
  `UPS1_InputFrequency03` double DEFAULT NULL,
  `UPS1_InputVoltage01` double DEFAULT NULL,
  `UPS1_InputVoltage02` double DEFAULT NULL,
  `UPS1_InputVoltage03` double DEFAULT NULL,
  `UPS1_InputCurrent01` double DEFAULT NULL,
  `UPS1_InputCurrent02` double DEFAULT NULL,
  `UPS1_InputCurrent03` double DEFAULT NULL,
  `UPS1_InputTruePower01` double DEFAULT NULL,
  `UPS1_InputTruePower02` double DEFAULT NULL,
  `UPS1_InputTruePower03` double DEFAULT NULL,
  `UPS1_BypassVoltage01` double DEFAULT NULL,
  `UPS1_BypassVoltage02` double DEFAULT NULL,
  `UPS1_BypassVoltage03` double DEFAULT NULL,
  `UPS1_BypassCurrent01` double DEFAULT NULL,
  `UPS1_BypassCurrent02` double DEFAULT NULL,
  `UPS1_BypassCurrent03` double DEFAULT NULL,
  `UPS1_BypassPower01` double DEFAULT NULL,
  `UPS1_BypassPower02` double DEFAULT NULL,
  `UPS1_BypassPower03` double DEFAULT NULL,
  `UPS1_OutputVoltage01` double DEFAULT NULL,
  `UPS1_OutputVoltage02` double DEFAULT NULL,
  `UPS1_OutputVoltage03` double DEFAULT NULL,
  `UPS1_OutputCurrent01` double DEFAULT NULL,
  `UPS1_OutputCurrent02` double DEFAULT NULL,
  `UPS1_OutputCurrent03` double DEFAULT NULL,
  `UPS1_OutputPower01` double DEFAULT NULL,
  `UPS1_OutputPower02` double DEFAULT NULL,
  `UPS1_OutputPower03` double DEFAULT NULL,
  `UPS1_OutputPercentLoad01` double DEFAULT NULL,
  `UPS1_OutputPercentLoad02` double DEFAULT NULL,
  `UPS1_OutputPercentLoad03` double DEFAULT NULL,
  `UPS2_InputFrequency01` double DEFAULT NULL,
  `UPS2_InputFrequency02` double DEFAULT NULL,
  `UPS2_InputFrequency03` double DEFAULT NULL,
  `UPS2_InputVoltage01` double DEFAULT NULL,
  `UPS2_InputVoltage02` double DEFAULT NULL,
  `UPS2_InputVoltage03` double DEFAULT NULL,
  `UPS2_InputCurrent01` double DEFAULT NULL,
  `UPS2_InputCurrent02` double DEFAULT NULL,
  `UPS2_InputCurrent03` double DEFAULT NULL,
  `UPS2_InputTruePower01` double DEFAULT NULL,
  `UPS2_InputTruePower02` double DEFAULT NULL,
  `UPS2_InputTruePower03` double DEFAULT NULL,
  `UPS2_BypassVoltage01` double DEFAULT NULL,
  `UPS2_BypassVoltage02` double DEFAULT NULL,
  `UPS2_BypassVoltage03` double DEFAULT NULL,
  `UPS2_BypassCurrent01` double DEFAULT NULL,
  `UPS2_BypassCurrent02` double DEFAULT NULL,
  `UPS2_BypassCurrent03` double DEFAULT NULL,
  `UPS2_BypassPower01` double DEFAULT NULL,
  `UPS2_BypassPower02` double DEFAULT NULL,
  `UPS2_BypassPower03` double DEFAULT NULL,
  `UPS2_OutputVoltage01` double DEFAULT NULL,
  `UPS2_OutputVoltage02` double DEFAULT NULL,
  `UPS2_OutputVoltage03` double DEFAULT NULL,
  `UPS2_OutputCurrent01` double DEFAULT NULL,
  `UPS2_OutputCurrent02` double DEFAULT NULL,
  `UPS2_OutputCurrent03` double DEFAULT NULL,
  `UPS2_OutputPower01` double DEFAULT NULL,
  `UPS2_OutputPower02` double DEFAULT NULL,
  `UPS2_OutputPower03` double DEFAULT NULL,
  `UPS2_OutputPercentLoad01` double DEFAULT NULL,
  `UPS2_OutputPercentLoad02` double DEFAULT NULL,
  `UPS2_OutputPercentLoad03` double DEFAULT NULL,
  `UPS3_InputFrequency01` double DEFAULT NULL,
  `UPS3_InputFrequency02` double DEFAULT NULL,
  `UPS3_InputFrequency03` double DEFAULT NULL,
  `UPS3_InputVoltage01` double DEFAULT NULL,
  `UPS3_InputVoltage02` double DEFAULT NULL,
  `UPS3_InputVoltage03` double DEFAULT NULL,
  `UPS3_InputCurrent01` double DEFAULT NULL,
  `UPS3_InputCurrent02` double DEFAULT NULL,
  `UPS3_InputCurrent03` double DEFAULT NULL,
  `UPS3_InputTruePower01` double DEFAULT NULL,
  `UPS3_InputTruePower02` double DEFAULT NULL,
  `UPS3_InputTruePower03` double DEFAULT NULL,
  `UPS3_BypassVoltage01` double DEFAULT NULL,
  `UPS3_BypassVoltage02` double DEFAULT NULL,
  `UPS3_BypassVoltage03` double DEFAULT NULL,
  `UPS3_BypassCurrent01` double DEFAULT NULL,
  `UPS3_BypassCurrent02` double DEFAULT NULL,
  `UPS3_BypassCurrent03` double DEFAULT NULL,
  `UPS3_BypassPower01` double DEFAULT NULL,
  `UPS3_BypassPower02` double DEFAULT NULL,
  `UPS3_BypassPower03` double DEFAULT NULL,
  `UPS3_OutputVoltage01` double DEFAULT NULL,
  `UPS3_OutputVoltage02` double DEFAULT NULL,
  `UPS3_OutputVoltage03` double DEFAULT NULL,
  `UPS3_OutputCurrent01` double DEFAULT NULL,
  `UPS3_OutputCurrent02` double DEFAULT NULL,
  `UPS3_OutputCurrent03` double DEFAULT NULL,
  `UPS3_OutputPower01` double DEFAULT NULL,
  `UPS3_OutputPower02` double DEFAULT NULL,
  `UPS3_OutputPower03` double DEFAULT NULL,
  `UPS3_OutputPercentLoad01` double DEFAULT NULL,
  `UPS3_OutputPercentLoad02` double DEFAULT NULL,
  `UPS3_OutputPercentLoad03` double DEFAULT NULL,
  `UPS4_InputFrequency01` double DEFAULT NULL,
  `UPS4_InputFrequency02` double DEFAULT NULL,
  `UPS4_InputFrequency03` double DEFAULT NULL,
  `UPS4_InputVoltage01` double DEFAULT NULL,
  `UPS4_InputVoltage02` double DEFAULT NULL,
  `UPS4_InputVoltage03` double DEFAULT NULL,
  `UPS4_InputCurrent01` double DEFAULT NULL,
  `UPS4_InputCurrent02` double DEFAULT NULL,
  `UPS4_InputCurrent03` double DEFAULT NULL,
  `UPS4_InputTruePower01` double DEFAULT NULL,
  `UPS4_InputTruePower02` double DEFAULT NULL,
  `UPS4_InputTruePower03` double DEFAULT NULL,
  `UPS4_BypassVoltage01` double DEFAULT NULL,
  `UPS4_BypassVoltage02` double DEFAULT NULL,
  `UPS4_BypassVoltage03` double DEFAULT NULL,
  `UPS4_BypassCurrent01` double DEFAULT NULL,
  `UPS4_BypassCurrent02` double DEFAULT NULL,
  `UPS4_BypassCurrent03` double DEFAULT NULL,
  `UPS4_BypassPower01` double DEFAULT NULL,
  `UPS4_BypassPower02` double DEFAULT NULL,
  `UPS4_BypassPower03` double DEFAULT NULL,
  `UPS4_OutputVoltage01` double DEFAULT NULL,
  `UPS4_OutputVoltage02` double DEFAULT NULL,
  `UPS4_OutputVoltage03` double DEFAULT NULL,
  `UPS4_OutputCurrent01` double DEFAULT NULL,
  `UPS4_OutputCurrent02` double DEFAULT NULL,
  `UPS4_OutputCurrent03` double DEFAULT NULL,
  `UPS4_OutputPower01` double DEFAULT NULL,
  `UPS4_OutputPower02` double DEFAULT NULL,
  `UPS4_OutputPower03` double DEFAULT NULL,
  `UPS4_OutputPercentLoad01` double DEFAULT NULL,
  `UPS4_OutputPercentLoad02` double DEFAULT NULL,
  `UPS4_OutputPercentLoad03` double DEFAULT NULL,
  `OTB1_IO` double DEFAULT NULL,
  `OTB2_IO` double DEFAULT NULL,
  `OTB3_IO` double DEFAULT NULL,
  `OTB4_IO` double DEFAULT NULL,
  `OTB5_IO` double DEFAULT NULL,
  `OTB6_IO` double DEFAULT NULL,
  `OTB7_IO` double DEFAULT NULL,
  `OTB8_IO` double DEFAULT NULL,
  `OTB9_IO` double DEFAULT NULL,
  `OTB10_IO` double DEFAULT NULL,
  `OTB11_IO` double DEFAULT NULL,
  `OTB12_IO` double DEFAULT NULL,
  `OTB13_IO` double DEFAULT NULL,
  `OTB14_IO` double DEFAULT NULL,
  `OTB15_IO` double DEFAULT NULL,
  `CCM1_CradleStatus` double DEFAULT NULL,
  `BCM1_BrStatus` double DEFAULT NULL,
  `CCM2_CradleStatus` double DEFAULT NULL,
  `BCM2_BrStatus` double DEFAULT NULL,
  `OTB16_IO` double DEFAULT NULL,
  `OTB17_IO` double DEFAULT NULL,
  `OTB18_IO` double DEFAULT NULL,
  `CCM3_CradleStatus` double DEFAULT NULL,
  `BCM3_BrStatus` double DEFAULT NULL,
  `CCM4_CradleStatus` double DEFAULT NULL,
  `BCM4_BrStatus` double DEFAULT NULL,
  `OTB19_IO` double DEFAULT NULL,
  `OTB20_IO` double DEFAULT NULL,
  `OTB21_IO` double DEFAULT NULL,
  `UPS1_EstimatedMinutesRemaining` double DEFAULT NULL,
  `BCM1_CbStatus_Bit0` double DEFAULT NULL,
  `BCM1_CbTrip_Bit2` double DEFAULT NULL,
  `BCM1_CbCharged_Bit4` double DEFAULT NULL,
  `BCM2_CbStatus_Bit0` double DEFAULT NULL,
  `BCM2_CbTrip_Bit2` double DEFAULT NULL,
  `BCM2_CbCharged_Bit4` double DEFAULT NULL,
  `BCM3_CbStatus_Bit0` double DEFAULT NULL,
  `BCM3_CbTrip_Bit2` double DEFAULT NULL,
  `BCM3_CbCharged_Bit4` double DEFAULT NULL,
  `BCM4_CbStatus_Bit0` double DEFAULT NULL,
  `BCM4_CbTrip_Bit2` double DEFAULT NULL,
  `BCM4_CbCharged_Bit4` double DEFAULT NULL,
  `CCM1_DeviceDisconnected_Bit8` double DEFAULT NULL,
  `CCM1_DeviceConnected_Bit9` double DEFAULT NULL,
  `CCM1_DeviceInTest_Bit10` double DEFAULT NULL,
  `CCM2_DeviceDisconnected_Bit8` double DEFAULT NULL,
  `CCM2_DeviceConnected_Bit9` double DEFAULT NULL,
  `CCM2_DeviceInTest_Bit10` double DEFAULT NULL,
  `CCM3_DeviceDisconnected_Bit8` double DEFAULT NULL,
  `CCM3_DeviceConnected_Bit9` double DEFAULT NULL,
  `CCM3_DeviceInTest_Bit10` double DEFAULT NULL,
  `CCM4_DeviceDisconnected_Bit8` double DEFAULT NULL,
  `CCM4_DeviceConnected_Bit9` double DEFAULT NULL,
  `CCM4_DeviceInTest_Bit10` double DEFAULT NULL,
  `OTB1_I0` double DEFAULT NULL,
  `OTB1_I1` double DEFAULT NULL,
  `OTB1_I2` double DEFAULT NULL,
  `OTB1_I3` double DEFAULT NULL,
  `OTB1_I4` double DEFAULT NULL,
  `OTB1_I5` double DEFAULT NULL,
  `OTB1_I6` double DEFAULT NULL,
  `OTB1_I7` double DEFAULT NULL,
  `OTB2_I0` double DEFAULT NULL,
  `OTB2_I1` double DEFAULT NULL,
  `OTB2_I2` double DEFAULT NULL,
  `OTB2_I3` double DEFAULT NULL,
  `OTB2_I4` double DEFAULT NULL,
  `OTB2_I5` double DEFAULT NULL,
  `OTB2_I6` double DEFAULT NULL,
  `OTB2_I7` double DEFAULT NULL,
  `OTB3_I0` double DEFAULT NULL,
  `OTB3_I1` double DEFAULT NULL,
  `OTB3_I2` double DEFAULT NULL,
  `OTB3_I3` double DEFAULT NULL,
  `OTB3_I4` double DEFAULT NULL,
  `OTB3_I5` double DEFAULT NULL,
  `OTB3_I6` double DEFAULT NULL,
  `OTB3_I7` double DEFAULT NULL,
  `OTB4_I0` double DEFAULT NULL,
  `OTB4_I1` double DEFAULT NULL,
  `OTB4_I2` double DEFAULT NULL,
  `OTB4_I3` double DEFAULT NULL,
  `OTB4_I4` double DEFAULT NULL,
  `OTB4_I5` double DEFAULT NULL,
  `OTB4_I6` double DEFAULT NULL,
  `OTB4_I7` double DEFAULT NULL,
  `OTB5_I0` double DEFAULT NULL,
  `OTB5_I1` double DEFAULT NULL,
  `OTB5_I2` double DEFAULT NULL,
  `OTB5_I3` double DEFAULT NULL,
  `OTB5_I4` double DEFAULT NULL,
  `OTB5_I5` double DEFAULT NULL,
  `OTB5_I6` double DEFAULT NULL,
  `OTB5_I7` double DEFAULT NULL,
  `OTB6_I0` double DEFAULT NULL,
  `OTB6_I1` double DEFAULT NULL,
  `OTB6_I2` double DEFAULT NULL,
  `OTB6_I3` double DEFAULT NULL,
  `OTB6_I4` double DEFAULT NULL,
  `OTB6_I5` double DEFAULT NULL,
  `OTB6_I6` double DEFAULT NULL,
  `OTB6_I7` double DEFAULT NULL,
  `OTB7_I0` double DEFAULT NULL,
  `OTB7_I1` double DEFAULT NULL,
  `OTB7_I2` double DEFAULT NULL,
  `OTB7_I3` double DEFAULT NULL,
  `OTB7_I4` double DEFAULT NULL,
  `OTB7_I5` double DEFAULT NULL,
  `OTB7_I6` double DEFAULT NULL,
  `OTB7_I7` double DEFAULT NULL,
  `OTB8_I0` double DEFAULT NULL,
  `OTB8_I1` double DEFAULT NULL,
  `OTB8_I2` double DEFAULT NULL,
  `OTB8_I3` double DEFAULT NULL,
  `OTB8_I4` double DEFAULT NULL,
  `OTB8_I5` double DEFAULT NULL,
  `OTB8_I6` double DEFAULT NULL,
  `OTB8_I7` double DEFAULT NULL,
  `OTB9_I0` double DEFAULT NULL,
  `OTB9_I1` double DEFAULT NULL,
  `OTB9_I2` double DEFAULT NULL,
  `OTB9_I3` double DEFAULT NULL,
  `OTB9_I4` double DEFAULT NULL,
  `OTB9_I5` double DEFAULT NULL,
  `OTB9_I6` double DEFAULT NULL,
  `OTB9_I7` double DEFAULT NULL,
  `OTB10_I0` double DEFAULT NULL,
  `OTB10_I1` double DEFAULT NULL,
  `OTB10_I2` double DEFAULT NULL,
  `OTB10_I3` double DEFAULT NULL,
  `OTB10_I4` double DEFAULT NULL,
  `OTB10_I5` double DEFAULT NULL,
  `OTB10_I6` double DEFAULT NULL,
  `OTB10_I7` double DEFAULT NULL,
  `OTB11_I0` double DEFAULT NULL,
  `OTB11_I1` double DEFAULT NULL,
  `OTB11_I2` double DEFAULT NULL,
  `OTB11_I3` double DEFAULT NULL,
  `OTB11_I4` double DEFAULT NULL,
  `OTB11_I5` double DEFAULT NULL,
  `OTB11_I6` double DEFAULT NULL,
  `OTB11_I7` double DEFAULT NULL,
  `OTB12_I0` double DEFAULT NULL,
  `OTB12_I1` double DEFAULT NULL,
  `OTB12_I2` double DEFAULT NULL,
  `OTB12_I3` double DEFAULT NULL,
  `OTB12_I4` double DEFAULT NULL,
  `OTB12_I5` double DEFAULT NULL,
  `OTB12_I6` double DEFAULT NULL,
  `OTB12_I7` double DEFAULT NULL,
  `OTB13_I0` double DEFAULT NULL,
  `OTB13_I1` double DEFAULT NULL,
  `OTB13_I2` double DEFAULT NULL,
  `OTB13_I3` double DEFAULT NULL,
  `OTB13_I4` double DEFAULT NULL,
  `OTB13_I5` double DEFAULT NULL,
  `OTB13_I6` double DEFAULT NULL,
  `OTB13_I7` double DEFAULT NULL,
  `OTB14_I0` double DEFAULT NULL,
  `OTB14_I1` double DEFAULT NULL,
  `OTB14_I2` double DEFAULT NULL,
  `OTB14_I3` double DEFAULT NULL,
  `OTB14_I4` double DEFAULT NULL,
  `OTB14_I5` double DEFAULT NULL,
  `OTB14_I6` double DEFAULT NULL,
  `OTB14_I7` double DEFAULT NULL,
  `OTB15_I0` double DEFAULT NULL,
  `OTB15_I1` double DEFAULT NULL,
  `OTB15_I2` double DEFAULT NULL,
  `OTB15_I3` double DEFAULT NULL,
  `OTB15_I4` double DEFAULT NULL,
  `OTB15_I5` double DEFAULT NULL,
  `OTB15_I6` double DEFAULT NULL,
  `OTB15_I7` double DEFAULT NULL,
  `OTB16_I0` double DEFAULT NULL,
  `OTB16_I1` double DEFAULT NULL,
  `OTB16_I2` double DEFAULT NULL,
  `OTB16_I3` double DEFAULT NULL,
  `OTB16_I4` double DEFAULT NULL,
  `OTB16_I5` double DEFAULT NULL,
  `OTB16_I6` double DEFAULT NULL,
  `OTB16_I7` double DEFAULT NULL,
  `OTB17_I0` double DEFAULT NULL,
  `OTB17_I1` double DEFAULT NULL,
  `OTB17_I2` double DEFAULT NULL,
  `OTB17_I3` double DEFAULT NULL,
  `OTB17_I4` double DEFAULT NULL,
  `OTB17_I5` double DEFAULT NULL,
  `OTB17_I6` double DEFAULT NULL,
  `OTB17_I7` double DEFAULT NULL,
  `OTB18_I0` double DEFAULT NULL,
  `OTB18_I1` double DEFAULT NULL,
  `OTB18_I2` double DEFAULT NULL,
  `OTB18_I3` double DEFAULT NULL,
  `OTB18_I4` double DEFAULT NULL,
  `OTB18_I5` double DEFAULT NULL,
  `OTB18_I6` double DEFAULT NULL,
  `OTB18_I7` double DEFAULT NULL,
  `OTB19_I0` double DEFAULT NULL,
  `OTB19_I1` double DEFAULT NULL,
  `OTB19_I2` double DEFAULT NULL,
  `OTB19_I3` double DEFAULT NULL,
  `OTB19_I4` double DEFAULT NULL,
  `OTB19_I5` double DEFAULT NULL,
  `OTB19_I6` double DEFAULT NULL,
  `OTB19_I7` double DEFAULT NULL,
  `OTB20_I0` double DEFAULT NULL,
  `OTB20_I1` double DEFAULT NULL,
  `OTB20_I2` double DEFAULT NULL,
  `OTB20_I3` double DEFAULT NULL,
  `OTB20_I4` double DEFAULT NULL,
  `OTB20_I5` double DEFAULT NULL,
  `OTB20_I6` double DEFAULT NULL,
  `OTB20_I7` double DEFAULT NULL,
  `OTB21_I0` double DEFAULT NULL,
  `OTB21_I1` double DEFAULT NULL,
  `OTB21_I2` double DEFAULT NULL,
  `OTB21_I3` double DEFAULT NULL,
  `OTB21_I4` double DEFAULT NULL,
  `OTB21_I5` double DEFAULT NULL,
  `OTB21_I6` double DEFAULT NULL,
  `OTB21_I7` double DEFAULT NULL,
  `PM1_5_kWh` double DEFAULT NULL,
  `PM1_5_pf` double DEFAULT NULL,
  `PM1_5_kW` double DEFAULT NULL,
  `PM1_5_kVA` double DEFAULT NULL,
  `PM1_5_F` double DEFAULT NULL,
  `PM1_5_I1` double DEFAULT NULL,
  `PM1_5_I2` double DEFAULT NULL,
  `PM1_5_I3` double DEFAULT NULL,
  `PM1_5_In` double DEFAULT NULL,
  `PM1_5_V12` double DEFAULT NULL,
  `PM1_5_V23` double DEFAULT NULL,
  `PM1_5_V31` double DEFAULT NULL,
  `PM1_5_V1` double DEFAULT NULL,
  `PM1_5_V2` double DEFAULT NULL,
  `PM1_5_V3` double DEFAULT NULL,
  `PM1_5_kW1` double DEFAULT NULL,
  `PM1_5_kW2` double DEFAULT NULL,
  `PM1_5_kW3` double DEFAULT NULL,
  `PM1_5_kVA1` double DEFAULT NULL,
  `PM1_5_kVA2` double DEFAULT NULL,
  `PM1_5_kVA3` double DEFAULT NULL,
  `PM1_5_THD_I1` double DEFAULT NULL,
  `PM1_5_THD_I2` double DEFAULT NULL,
  `PM1_5_THD_I3` double DEFAULT NULL,
  `PM1_5_THD_V1` double DEFAULT NULL,
  `PM1_5_THD_V2` double DEFAULT NULL,
  `PM1_5_THD_V3` double DEFAULT NULL,
  `PM1_5_THD_V12` double DEFAULT NULL,
  `PM1_5_THD_V23` double DEFAULT NULL,
  `PM1_5_THD_V31` double DEFAULT NULL,
  `PM1_5_Hour` double DEFAULT NULL,
  `PM1_5_Min` double DEFAULT NULL,
  `DHCX1_UnitSetpointHumidityW` double DEFAULT NULL,
  `DHCX1_UnitSetpointTemperatureDayW` double DEFAULT NULL,
  `DHCX1_UnitSetpointTemperatureNightW` double DEFAULT NULL,
  `DHCX2_UnitSetpointTemperatureDayW` double DEFAULT NULL,
  `DHCX2_UnitSetpointTemperatureNightW` double DEFAULT NULL,
  `DHCX2_UnitSetpointHumidityW` double DEFAULT NULL,
  `DHCX3_UnitSetpointTemperatureDayW` double DEFAULT NULL,
  `DHCX3_UnitSetpointTemperatureNightW` double DEFAULT NULL,
  `DHCX3_UnitSetpointHumidityW` double DEFAULT NULL,
  `DHCX4_UnitSetpointTemperatureDayW` double DEFAULT NULL,
  `DHCX4_UnitSetpointTemperatureNightW` double DEFAULT NULL,
  `DHCX4_UnitSetpointHumidityW` double DEFAULT NULL,
  `DHCX5_UnitSetpointTemperatureDayW` double DEFAULT NULL,
  `DHCX5_UnitSetpointTemperatureNightW` double DEFAULT NULL,
  `DHCX5_UnitSetpointHumidityW` double DEFAULT NULL,
  `DHCX6_UnitSetpointTemperatureDayW` double DEFAULT NULL,
  `DHCX6_UnitSetpointTemperatureNightW` double DEFAULT NULL,
  `DHCX6_UnitSetpointHumidityW` double DEFAULT NULL,
  `DHCX7_UnitSetpointTemperatureDayW` double DEFAULT NULL,
  `DHCX7_UnitSetpointTemperatureNightW` double DEFAULT NULL,
  `DHCX7_UnitSetpointHumidityW` double DEFAULT NULL,
  `DHCX8_UnitSetpointTemperatureDayW` double DEFAULT NULL,
  `DHCX8_UnitSetpointTemperatureNightW` double DEFAULT NULL,
  `DHCX8_UnitSetpointHumidityW` double DEFAULT NULL,
  `DHCX1_UnitDehumidification` double DEFAULT NULL,
  `DHCX1_HighPressure3` double DEFAULT NULL,
  `DHCX2_UnitDehumidification` double DEFAULT NULL,
  `DHCX2_HighPressure3` double DEFAULT NULL,
  `DHCX3_UnitDehumidification` double DEFAULT NULL,
  `DHCX3_HighPressure3` double DEFAULT NULL,
  `DHCX4_UnitDehumidification` double DEFAULT NULL,
  `DHCX4_HighPressure3` double DEFAULT NULL,
  `DHCX5_UnitDehumidification` double DEFAULT NULL,
  `DHCX5_HighPressure3` double DEFAULT NULL,
  `DHCX8_UnitDehumidification` double DEFAULT NULL,
  `DHCX8_HighPressure3` double DEFAULT NULL,
  `DHCX7_UnitDehumidification` double DEFAULT NULL,
  `DHCX7_HighPressure3` double DEFAULT NULL,
  `DHCX6_UnitDehumidification` double DEFAULT NULL,
  `DHCX6_HighPressure3` double DEFAULT NULL,
  `OTB1_I8` double DEFAULT NULL,
  `OTB1_I9` double DEFAULT NULL,
  `OTB1_I10` double DEFAULT NULL,
  `OTB1_I11` double DEFAULT NULL,
  `OTB2_I8` double DEFAULT NULL,
  `OTB2_I9` double DEFAULT NULL,
  `OTB2_I10` double DEFAULT NULL,
  `OTB2_I11` double DEFAULT NULL,
  `OTB3_I8` double DEFAULT NULL,
  `OTB3_I9` double DEFAULT NULL,
  `OTB3_I10` double DEFAULT NULL,
  `OTB3_I11` double DEFAULT NULL,
  `OTB4_I8` double DEFAULT NULL,
  `OTB4_I9` double DEFAULT NULL,
  `OTB4_I10` double DEFAULT NULL,
  `OTB4_I11` double DEFAULT NULL,
  `OTB5_I8` double DEFAULT NULL,
  `OTB5_I9` double DEFAULT NULL,
  `OTB5_I10` double DEFAULT NULL,
  `OTB5_I11` double DEFAULT NULL,
  `OTB6_I8` double DEFAULT NULL,
  `OTB6_I9` double DEFAULT NULL,
  `OTB6_I10` double DEFAULT NULL,
  `OTB6_I11` double DEFAULT NULL,
  `OTB7_I8` double DEFAULT NULL,
  `OTB7_I9` double DEFAULT NULL,
  `OTB7_I10` double DEFAULT NULL,
  `OTB7_I11` double DEFAULT NULL,
  `OTB8_I8` double DEFAULT NULL,
  `OTB8_I9` double DEFAULT NULL,
  `OTB8_I10` double DEFAULT NULL,
  `OTB8_I11` double DEFAULT NULL,
  `OTB9_I8` double DEFAULT NULL,
  `OTB9_I9` double DEFAULT NULL,
  `OTB9_I10` double DEFAULT NULL,
  `OTB9_I11` double DEFAULT NULL,
  `OTB10_I8` double DEFAULT NULL,
  `OTB10_I9` double DEFAULT NULL,
  `OTB10_I10` double DEFAULT NULL,
  `OTB10_I11` double DEFAULT NULL,
  `OTB11_I8` double DEFAULT NULL,
  `OTB11_I9` double DEFAULT NULL,
  `OTB11_I10` double DEFAULT NULL,
  `OTB11_I11` double DEFAULT NULL,
  `OTB12_I8` double DEFAULT NULL,
  `OTB12_I9` double DEFAULT NULL,
  `OTB12_I10` double DEFAULT NULL,
  `OTB12_I11` double DEFAULT NULL,
  `OTB13_I8` double DEFAULT NULL,
  `OTB13_I9` double DEFAULT NULL,
  `OTB13_I10` double DEFAULT NULL,
  `OTB13_I11` double DEFAULT NULL,
  `OTB14_I8` double DEFAULT NULL,
  `OTB14_I9` double DEFAULT NULL,
  `OTB14_I10` double DEFAULT NULL,
  `OTB14_I11` double DEFAULT NULL,
  `OTB15_I8` double DEFAULT NULL,
  `OTB15_I9` double DEFAULT NULL,
  `OTB15_I10` double DEFAULT NULL,
  `OTB15_I11` double DEFAULT NULL,
  `OTB16_I8` double DEFAULT NULL,
  `OTB16_I9` double DEFAULT NULL,
  `OTB16_I10` double DEFAULT NULL,
  `OTB16_I11` double DEFAULT NULL,
  `OTB17_I8` double DEFAULT NULL,
  `OTB17_I9` double DEFAULT NULL,
  `OTB17_I10` double DEFAULT NULL,
  `OTB17_I11` double DEFAULT NULL,
  `OTB18_I8` double DEFAULT NULL,
  `OTB18_I9` double DEFAULT NULL,
  `OTB18_I10` double DEFAULT NULL,
  `OTB18_I11` double DEFAULT NULL,
  `OTB19_I8` double DEFAULT NULL,
  `OTB19_I9` double DEFAULT NULL,
  `OTB19_I10` double DEFAULT NULL,
  `OTB19_I11` double DEFAULT NULL,
  `OTB20_I8` double DEFAULT NULL,
  `OTB20_I9` double DEFAULT NULL,
  `OTB20_I10` double DEFAULT NULL,
  `OTB20_I11` double DEFAULT NULL,
  `OTB21_I8` double DEFAULT NULL,
  `OTB21_I9` double DEFAULT NULL,
  `OTB21_I10` double DEFAULT NULL,
  `OTB21_I11` double DEFAULT NULL,
  `PM1_18_pf1` double DEFAULT NULL,
  `PM1_18_pf2` double DEFAULT NULL,
  `PM1_18_pf3` double DEFAULT NULL,
  `PM1_17_pf1` double DEFAULT NULL,
  `PM1_17_pf2` double DEFAULT NULL,
  `PM1_17_pf3` double DEFAULT NULL,
  `UPS1_AlarmsPresent` double DEFAULT NULL,
  `UPS2_AlarmsPresent` double DEFAULT NULL,
  `UPS3_AlarmsPresent` double DEFAULT NULL,
  `UPS4_AlarmsPresent` double DEFAULT NULL,
  `PM2_1_kWh` double DEFAULT NULL,
  `PM2_2_kWh` double DEFAULT NULL,
  `id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `realtime`
--

LOCK TABLES `realtime` WRITE;
/*!40000 ALTER TABLE `realtime` DISABLE KEYS */;
INSERT INTO `realtime` VALUES (0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1192,24,27,50,24.5,66.69999694824,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1009,24,27,60,23.89999961853,65.69999694824,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1262,24,27,60,24.29999923706,65.09999847412,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,746,25,27,60,26.79999923706,55.09999847412,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1059,25,27,60,25.79999923706,58.40000152588,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,382,24,27,60,24.20000076294,66.09999847412,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1704,24,27,60,24.10000038147,67.40000152588,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,582,24,27,45,25.20000076294,62.59999847412,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,22331.77148438,0.9287250638008,12.1,13,49.99,14,24.7,17.8,NULL,398.8,397.6,398.9,230.2,229.7,230.1,2.9,5.3,3.9,3.1,5.7,4.1,1.08,0.96,1.85,0.11,0.14,0.12,0,0,0,2011,18,11117.04980469,0.9312783479691,6.1,6.6,50,9.1,12,6.9,NULL,399.4,383.2,398.8,232.8,224.7,224.8,1.9,2.5,1.5,2.1,2.8,1.6,2.3,1.05,1.45,0.16,0.27,0.16,0.23,0.23,0.11,2010,50,11581.65722656,0.9120027422905,6.2,6.8,50.02,9.8,12.5,7.8,NULL,399.2,398.9,397.8,229.9,230.7,229.8,1.9,2.6,1.6,2.1,2.9,1.8,2.16,1.11,1.85,0.11,0.12,0.11,0.11,0.11,0.1,2010,51,23052.78320313,0.9231396317482,12.2,13.2,50,18,24,15.6,NULL,398.9,398.8,398.6,230,230.8,230.2,3.9,5.3,3.3,4.3,5.6,3.5,1.96,0.85,1.6,0.13,0.1,0.13,0.1,0.11,0.11,2010,51,60759.55859375,0.9167513847351,19.6,21.4,49.99,35.5,29,27.3,NULL,390.5,391,392.5,226.2,225.1,227.1,7.4,6.3,5.9,8.1,6.8,6.3,1.62,2.08,1.83,0.17,0.21,0.17,0.17,0.15,0.15,1865,37,74988.9140625,0,0,0,327.68,0,0,0,NULL,0,0,0,0,0,0,0,0,0,0,0,0,327.68,327.68,327.68,327.68,327.68,327.68,327.68,327.68,327.68,750,30,209361.546875,0.969092488289,143,147,49.96,220.6,218,216.1,NULL,390.8,391.6,392.3,225.7,225.1,226.9,49,48,47,50,49,49,1.29,1.28,1.29,0.16,0.19,0.18,0.17,0.13,0.16,1435,9,30429.125,0.8301666975021,18.7,22.5,49.92,34.6,39.6,30.5,NULL,390,391.2,391.7,225.3,225,226.8,7.1,7.2,5.7,8.4,8.6,6.6,1.39,1.51,1.27,0.15,0.21,0.17,0.17,0.14,0.14,1999,58,0.0072369636036,0,0,0,327.68,0,0,0,NULL,0,0,0,0,0,0,0,0,0,0,0,0,327.68,327.68,327.68,327.68,327.68,327.68,327.68,327.68,327.68,0,2,32.768,49.92,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,327.68,327.68,327.68,327.68,327.68,327.68,327.68,327.68,327.68,16297.05566406,0,0,0,327.68,0,0,0,NULL,0,0,0,0,0,0,0,0,0,0,0,0,327.68,327.68,327.68,327.68,327.68,327.68,327.68,327.68,327.68,208,11,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,327.68,0,0,0,NULL,0,0,0,6.6,6.6,6.4,0,0,0,0,0,0,327.68,327.68,327.68,327.68,327.68,327.68,327.68,327.68,327.68,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,4739.744140625,0,0,0,327.68,0,0,0,NULL,0,0,0,0,0,0,0,0,0,0,0,0,327.68,327.68,327.68,327.68,327.68,327.68,327.68,327.68,327.68,220,2,39532.38671875,0.872218132019,45,51.8,49.93,113.4,36.5,80.3,NULL,390.2,390.6,391.3,225.6,224.7,226.1,22.3,7.8,14.6,25.6,8.1,18.3,1.34,2.42,1.07,0.14,0.18,0.16,0.16,0.13,0.12,1426,34,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,100,2,49.9,50,2,29,272.6,0,310,100,3,50,49.9,2,29,272.6,0,720,100,3,49.9,49.9,2,28,272.4,0,720,100,3,50,49.9,2,28,272.4,0,3,54.031,152.606,7,2,4294694212,54.03,0,3,54.052,161.136,8,2,4294694296,54.05,0,3,53.796,106.06,5,2,4294694296,53.793,0,3,53.956,195.43,9,2,4294694213,53.955,0,3,53.93,243.543,12,2,4294694296,53.933,0,3,53.949,319.796,15,2,4294694296,53.942,0,393.218,392.031,390.062,2,392.562,392.343,391.343,2,394.406,390,391.656,2,391.687,393.437,392.187,2,391.781,391.843,392.375,2,393.437,389.156,393.031,2,49.9,49.9,49.9,226,225,227,1.4,1.4,1.4,0,0,0,226,224,227,0,0,0,0,0,0,231,232,231,0,0,0,0,0,0,0,0,0,50,50,50,227,225,228,17.2,16.4,17.2,0,0,0,227,225,228,0,0,0,0,0,0,230,230,230,13.9,25.4,17.8,2.456,5.042,3.428,16,29,20,49.8,49.8,49.8,227,226,226,7.8,7.7,8.2,0,0,0,227,225,228,0,0,0,0,0,0,229,230,230,8.9,11.9,7.4,1.486,2.182,1.196,10,13,7,49.8,49.8,49.8,228,226,227,8.1,8.1,8.3,0,0,0,226,225,227,0,0,0,0,0,0,231,229,230,9.5,12.2,8,1.44,2.156,1.164,10,14,8,325,272,276,65,341,169,320,516,5,20,169,341,1296,1365,1349,35594,120,35593,120,1365,341,1297,35329,89,NULL,NULL,1364,85,8,720,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,1,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,1,0,1,0,1,0,1,0,1,0,1,0,0,1,0,1,0,1,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,1,0,1,0,0,0,1,0,0,1,0,1,0,1,1,0,1,0,1,0,1,0,0,0,0,0,1,0,0,0,1,0,1,0,1,0,1,0,1,0,1,0,0,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,0,0,1,0,0,0,0,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,0,0,0,1,0,0,0,0,22041.42578125,0.9295544028282,12.2,13.1,49.97,13.7,25.1,18,NULL,399.3,397.9,398.4,230.1,229.9,229.8,2.9,5.3,3.8,3.1,5.7,4.1,1.16,0.96,1.86,0.11,0.15,0.13,0.11,0,0.1,1956,39,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,0,0,1,0,1,0,1,0,1,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,2,0,0,0,414850.726,319103.57,1);
/*!40000 ALTER TABLE `realtime` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  `parentRoleID` int(11) DEFAULT NULL,
  `description` varchar(512) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'admin',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rolepermissionmapper`
--

DROP TABLE IF EXISTS `rolepermissionmapper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rolepermissionmapper` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(512) DEFAULT NULL,
  `options` text,
  `roleID` int(11) DEFAULT NULL,
  `permissionID` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rolepermissionmapper`
--

LOCK TABLES `rolepermissionmapper` WRITE;
/*!40000 ALTER TABLE `rolepermissionmapper` DISABLE KEYS */;
/*!40000 ALTER TABLE `rolepermissionmapper` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unit`
--

DROP TABLE IF EXISTS `unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `unit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(512) NOT NULL,
  `name` varchar(512) NOT NULL,
  `description` varchar(512) DEFAULT NULL,
  `type` varchar(512) DEFAULT NULL,
  `parentID` int(11) NOT NULL,
  `unitParentID` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unit`
--

LOCK TABLES `unit` WRITE;
/*!40000 ALTER TABLE `unit` DISABLE KEYS */;
INSERT INTO `unit` VALUES (10,'DAR_UP_T31','UPS 1','Tower frame, 3 in, 3 out','unit',2,0),(11,'DAR_UP_T32','UPS 2','Tower frame, 3 in, 3 out','unit',2,0),(12,'DAR_UP_T33','UPS 3','Tower frame, 3 in, 3 out','unit',2,0),(13,'DAR_UP_T34','UPS 4','Tower frame, 3 in, 3 out','unit',2,0),(14,'DAR_PI_DX1','DHCX 1','Gas based unit','unit',3,0),(15,'DAR_PI_DX2','DHCX 2','Gas based unit','unit',3,0),(16,'DAR_PI_DX3','DHCX 3','Gas based unit','unit',3,0),(17,'DAR_PI_DX4','DHCX 4','Gas based unit','unit',3,0),(18,'DAR_PI_DX5','DHCX 5','Gas based unit','unit',3,0),(19,'DAR_PI_DX6','DHCX 6','Gas based unit','unit',3,0),(20,'DAR_PI_DX7','DHCX 7','Gas based unit','unit',3,0),(21,'DAR_PI_DX8','DHCX 8','Gas based unit','unit',3,0),(22,'DAR_GS_BG1','Genset 1','Bare-set generator','unit',4,0),(23,'DAR_GS_BG2','Genset 2','Bare-set generator','unit',4,0),(24,'DAR_PW_LV1','LV-1','Low Voltage 1','unit',5,0),(25,'DAR_PW_LV2','LV-2','Low Voltage 2','unit',5,0),(26,'DAR_PW_BU1','TBU-1','TBU-1 switchboard','unit',5,0),(27,'DAR_PW_BU2','TBU-2','TBU-2 switchboard','unit',5,0),(28,'DAR_PW_AT1','ATS-1','ATS-1 switchboard','unit',5,0),(29,'DAR_PW_AT2','ATS-2','ATS-2 switchboard','unit',5,0),(30,'DAR_PW_TC1','TCM','TCM switchboard','unit',5,0),(31,'DAR_PW_UP2','UPSDB-2','UPSDB-2 switchboard','unit',5,0),(32,'DAR_PW_AC1','ACDB-1','ACDB-1 switchboard','unit',5,0),(33,'DAR_PW_EM1','EMDB-1','EMDB-1 switchboard','unit',5,0),(34,'DAR_PW_EM2','EMDB-2','EMDB-2 switchboard','unit',5,0),(35,'DAR_PW_UD1','UDB-1','UDB-1 switchboard','unit',5,0),(36,'DAR_PW_UD2','UDB-2','UDB-2 switchboard','unit',5,0),(37,'DAR_PW_PU1','PDU-1','PDU-1 switchboard','unit',5,0),(38,'DAR_PW_PU2','PDU-2','PDU-2 switchboard','unit',5,0),(39,'DAR_PW_DB1','DCDB-1','DCDB-1 switchboard','unit',5,0),(40,'DAR_PW_UP1','UPSDB-1','UPSDB-1 switchboard','unit',5,0),(41,'DAR_PW_AC2','ACDB-2','ACDB-2 switchboard','unit',5,0),(42,'DAR_PW_DB2','DCDB-2','DCDB-2 switchboard','unit',5,0),(43,'DAR_RE_RE1','REC 1','Rectifier unit','unit',7,0),(44,'DAR_RE_RE2','REC 2','Rectifier unit','unit',7,0),(45,'DAR_RE_RE3','REC 3','Rectifier unit','unit',7,0),(46,'DAR_RE_RE4','REC 4','Rectifier unit','unit',7,0),(47,'DAR_RE_RE5','REC 5','Rectifier unit','unit',7,0),(48,'DAR_RE_RE6','REC 6','Rectifier unit','unit',7,0),(49,'DAR_RE_RE7','REC 7','Rectifier unit','unit',7,0),(50,'DAR_RE_RE8','REC 8','Rectifier unit','unit',7,0),(51,'DAR_TF_DT1','Dry-transformer 1','Dry-transformer','unit',8,0),(52,'DAR_TF_DT2','Dry-transformer 2','Dry-transformer','unit',8,0),(53,'DAR_PW_LV1_PM117','PM117','PM117','component',24,24),(54,'DAR_PW_LV2_PM118','PM118','PM118','component',25,25),(55,'DAR_PW_BU1_PM111','PM111','PM112','component',26,26),(56,'DAR_PW_BU1_OTB13','OTB13','OTB13','component',26,26),(57,'DAR_PW_BU1_OTB14','OTB14','OTB14','component',26,26),(58,'DAR_PW_BU2_PM114','PM114','PM115','component',27,27),(59,'DAR_PW_BU2_OTB17','OTB17','OTB17','component',27,27),(60,'DAR_PW_BU2_OTB18','OTB18','OTB18','component',27,27),(61,'DAR_PW_AT1_PM201','PM201','PM201','component',28,28),(62,'DAR_PW_AT1_PM112','PM112','PM112','component',28,28),(63,'DAR_PW_AT1_OTB15','OTB15','OTB16','component',28,28),(64,'DAR_PW_AT1_BCM01','BCM01','BCM01','component',28,28),(65,'DAR_PW_AT1_BCM02','BCM02','BCM02','component',28,28),(66,'DAR_PW_AT2_PM202','PM202','PM202','component',29,29),(67,'DAR_PW_AT2_PM113','PM113','PM113','component',29,29),(68,'DAR_PW_AT2_OTB16','OTB16','OTB17','component',29,29),(69,'DAR_PW_AT2_BCM03','BCM03','BCM03','component',29,29),(70,'DAR_PW_AT2_BCM04','BCM04','BCM04','component',29,29),(71,'DAR_PW_TC1_OTB19','OTB19','OTB19','component',30,30),(72,'DAR_PW_TC1_OTB20','OTB20','OTB20','component',30,30),(73,'DAR_PW_TC1_PM115','PM115','PM115','component',30,30),(74,'DAR_PW_TC1_PM116','PM116','PM116','component',30,30),(75,'DAR_PW_UP2_PM110','PM110','PM110','component',31,31),(76,'DAR_PW_UP2_OTB12','OTB12','OTB13','component',31,31),(77,'DAR_PW_AC1_PM107','PM107','PM108','component',32,32),(78,'DAR_PW_AC1_OTB05','OTB05','OTB06','component',32,32),(79,'DAR_PW_EM1_PM108','PM108','PM109','component',33,33),(80,'DAR_PW_EM1_OTB08','OTB08','OTB09','component',33,33),(81,'DAR_PW_EM2_PM109','PM109','PM110','component',34,34),(82,'DAR_PW_EM2_OTB09','OTB09','OTB09','component',34,34),(83,'DAR_PW_UD1_OTB01','OTB01','OTB01','component',35,35),(84,'DAR_PW_UD1_PM101','PM101','PM101','component',35,35),(85,'DAR_PW_UD1_PM102','PM102','PM102','component',35,35),(86,'DAR_PW_UD2_OTB02','OTB02','OTB02','component',36,36),(87,'DAR_PW_UD2_OTB03','OTB03','OTB03','component',36,36),(88,'DAR_PW_UD2_PM103','PM103','PM103','component',36,36),(89,'DAR_PW_UD2_PM104','PM104','PM104','component',36,36),(90,'DAR_PW_PU1_PM105','PM105','PM105','component',37,37),(91,'DAR_PW_PU2_OTB04','OTB04','OTB05','component',38,38),(92,'DAR_PW_PU2_PM106','PM106','PM107','component',38,38),(93,'DAR_PW_DB1_OTB24','OTB24','OTB24','component',39,39),(94,'DAR_PW_UP1_OTB07','OTB07','OTB07','component',40,40),(95,'DAR_PW_AC2_OTB10','OTB10','OTB10','component',41,41),(96,'DAR_PW_DB2_OTB11','OTB11','OTB11','component',42,42);
/*!40000 ALTER TABLE `unit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting` text,
  `activityCode` varchar(512) DEFAULT NULL,
  `group` varchar(512) DEFAULT NULL,
  `realm` varchar(512) DEFAULT NULL,
  `username` varchar(512) DEFAULT NULL,
  `password` varchar(512) NOT NULL,
  `credentials` text,
  `challenges` text,
  `email` varchar(512) NOT NULL,
  `emailVerified` tinyint(1) DEFAULT NULL,
  `verificationToken` varchar(512) DEFAULT NULL,
  `status` varchar(512) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,NULL,NULL,NULL,NULL,'admin','$2a$10$FHYYqgRBrU5HME7Z/zGxNuUGPU/LPgt8d8rNWLQ4oL1H90b5.eBq.',NULL,NULL,'admin@cmas.com',NULL,NULL,NULL,NULL,NULL),(2,NULL,NULL,NULL,NULL,'operator','$2a$10$mq6DTfhTN80AOUsBVPyG4Og7AsKA65BNCWvlnczuze2rlHrWBGp7i',NULL,NULL,'operator@cmas.com',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'cmas'
--

--
-- Dumping routines for database 'cmas'
--
/*!50003 DROP PROCEDURE IF EXISTS `getChannelHistoryAvgByTimeRange` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getChannelHistoryAvgByTimeRange`(IN startDate datetime, IN endDate datetime, IN channelDenifitionID int)
    DETERMINISTIC
BEGIN
  select avg(value) from `channel_history` where channel_definition_id = channelDenifitionID AND (`channel_history`.createdAt BETWEEN startDate AND endDate OR  (`channel_history`.updatedAt BETWEEN startDate AND endDate));
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `selectChannelHistoryByTimeRange` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `selectChannelHistoryByTimeRange`(IN startDate datetime, IN endDate datetime, IN channelDenifitionID int, IN limitRecords int)
    DETERMINISTIC
BEGIN
	DECLARE totalRows INT unsigned DEFAULT 1;
	DECLARE intervalStep INT unsigned DEFAULT 1;
	DECLARE tempTableName VARCHAR(255) DEFAULT "";
	set @selectedHistory:= null;
	

	SET tempTableName = CONCAT("temp",channelDenifitionID);

	/*select count(*) from `channel_history` where channel_definition_id = 1826 AND (`channel_history`.createdAt BETWEEN "2015-05-18 00:00:00" AND "2015-05-18 11:00:00" OR  (`channel_history`.updatedAt BETWEEN "2015-05-18 00:00:00" AND "2015-05-18 11:00:00"));*/
	DROP TEMPORARY TABLE IF EXISTS `temp`;
	CREATE TEMPORARY TABLE `temp` select * from `channel_history` where channel_definition_id = channelDenifitionID AND (`channel_history`.createdAt BETWEEN startDate AND endDate OR  (`channel_history`.updatedAt BETWEEN startDate AND endDate));
	
	set totalRows:= (select count(*) from `temp`);

	if (totalRows > limitRecords) THEN
		set intervalStep = round(totalRows/limitRecords);
	end if;
	Set @currentRow = 0;

	SELECT `channel_history`.*
	FROM 
		`channel_history`
		INNER JOIN
		(
			SELECT id
			FROM
				(
					SELECT @currentRow := @currentRow+1 AS rownum, id 
					FROM
						`temp` AS sorted
				) as ranked
			WHERE rownum % intervalStep = 0
		) AS subset
			ON subset.id = `channel_history`.id;
	DROP TEMPORARY TABLE `temp`;
	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_channel` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_channel`(channelname varchar(255), channelvalue float)
BEGIN
	SET SQL_SAFE_UPDATES = 0;
	UPDATE `channel_data` set `value` = channelvalue where `channel_data`.channelName = channelname;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `a`
--

/*!50001 DROP VIEW IF EXISTS `a`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `a` AS (select `channel_history`.`id` AS `id`,`channel_history`.`value` AS `value`,`channel_history`.`createdAt` AS `createdAt`,`channel_history`.`updatedAt` AS `updatedAt`,`channel_history`.`channel_definition_id` AS `channel_definition_id`,`channel_history`.`number_of_sample` AS `number_of_sample` from `channel_history` where (`channel_history`.`channel_definition_id` = 458)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hum`
--

/*!50001 DROP VIEW IF EXISTS `hum`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hum` AS (select `channel_history`.`id` AS `id`,`channel_history`.`value` AS `value`,`channel_history`.`createdAt` AS `createdAt`,`channel_history`.`updatedAt` AS `updatedAt`,`channel_history`.`channel_definition_id` AS `channel_definition_id`,`channel_history`.`number_of_sample` AS `number_of_sample` from `channel_history` where (`channel_history`.`channel_definition_id` = 459)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-08-22 11:35:52
