/**
 * Created by tanvo on 4/25/15.
 */
module.exports = function (instruction) {
    var me = this;

    me.execute = function () {
        console.log("This is the report");
    };

    return me;
};