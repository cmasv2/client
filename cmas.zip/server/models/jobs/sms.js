/**
 * Created by tanvo on 4/25/15.
 */

module.exports = function () {

    var me = this,
        Action = me.app.models.Action;

    me.execute = function () {
        Action.create({name: "SMS", type: "SMS", content: "[SendTo][0928377664]This is an example message", options: {}, status: Action.Status.Active, createdAt: new Date()}, function (err, obj) {
            if (err){
                console.log(err);
            } else {
                console.log("SMS CREATED");
                console.log(obj);
            }
        });
    };

    return me;
};