var CronJob = require('cron').CronJob;

module.exports = function(instruction) {
    var job = this,
        me = job,
        modelMapping = {
            Instruction: "instruction",
            App: "app"
        };

    me.name = "";
    me.execute = function () {
        console.log("This is default execute functions");
    };
    me.start = start;
    me.stop = stop;

    if (!validateInstruction(instruction)) {
        console.log("Wrong Intruction");
    }


    initialize(instruction);


    var Job = require("./jobs/" + me.name);

    if (!Job) {
        console.log("Wrong Job Name");
    } else {
        // Create Job
        Job.apply(me, arguments);
    }

    var cronJob = new CronJob({
        cronTime: me.cronTime,
        onTick: me.execute,
        start: false
    });

    function start() {
        cronJob.start();
    }

    function stop() {
        cronJob.stop();
    }

    function validateInstruction(instruction) {
        var result = true;
        if (!instruction) {
            return !result;
        } else {
            result = result && (instruction.hasOwnProperty("name"));
            result = result && (instruction.hasOwnProperty(modelMapping.Instruction));
            result = result && (instruction.hasOwnProperty(modelMapping.App));
            result = result && (instruction.hasOwnProperty(modelMapping.cronTime));
        }
        return result;
    }

    function initialize(config) {
        me.name = config.name;
        me.instructionData = config[modelMapping.Instruction];
        me.app = config.app;
        me.cronTime = config.cronTime;
    }

    return job;
};