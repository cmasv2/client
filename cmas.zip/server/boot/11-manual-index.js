module.exports = function mountRestApi(server) {
	var fs = require("node-fs");
    var router = server.loopback.Router();
    router.get('/status', server.loopback.status());
    server.use(router);

    var path = require('path');  /* REMOVE COMMENTS ON THESE LINES */
    var serveIndex = require("serve-index");

    fs.exists(path.resolve(__dirname, '../../public/'), function (exists) {
        if (!exists) {
            fs.mkdirSync(path.resolve(__dirname, '../../public/'), "0777", true);
        }
        server.use("/public", serveIndex(path.resolve(__dirname, '../../public/'), {icons: true}));
    });
};
