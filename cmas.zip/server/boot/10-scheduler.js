﻿var EventEmitter = require("events").EventEmitter;

if (!GLOBAL.eventEmitter) {
    GLOBAL.eventEmitter = new EventEmitter();
}

module.exports = function startScheduler(app) {

    var JobModel = app.models.Job;
    var Job = require("./../models/job");

    var runningJobs = {};

    JobModel.find({}, function (err, jobs) {
        for (var i in jobs) {

            var job = jobs[i];

            if (!runningJobs[job.id]) {
                runningJobs[job.id] = new Job({
                    name: job.name,
                    instruction: job.instruction,
                    app: app,
                    cronTime: job.cronTime
                });
                runningJobs[job.id].start();
            }

        }
    });


    GLOBAL.eventEmitter.on("job-updated", function (jobInstance) {
        var job = runningJobs[jobInstance.id];
        if (!job) {
            JobModel.findOne({ where: { id: jobInstance.id }}, function (err, job) {
                if (err) {return;}
                else {
                    runningJobs[jobInstance.id] = new Job({name: job.name, instruction: job.instruction, app: app, cronTime: job.cronTime});
                    runningJobs[jobInstance.id].start();
                }

            });
        } else {
            job.stop();

            JobModel.findOne({ where: { id: jobInstance.id }}, function (err, job) {
                if (err) {return;}
                else {
                    runningJobs[jobInstance.id] = new Job({name: job.name, instruction: job.instruction, app: app, cronTime: job.cronTime});
                    runningJobs[jobInstance.id].start();
                }
            });
        }
    });
};
