var EventEmitter = require("events").EventEmitter;

if (!GLOBAL.eventEmitter) {
    GLOBAL.eventEmitter = new EventEmitter();
}

module.exports = function enableFileWatcher(app) {
    return;
    var fs = require("fs");

    var logPath = 'C:\\DAQFactory\\Log\\channel\\';
    var t = Date.now();
    var totalFile = 0;
    var min = 10000;
    var CHANNEL_VALUE_INDEX = 1;
    var CHANNEL_NAME_INDEX = 0;
    
    fs.watch(logPath, function (event, filename) {
        //console.log('event is: ' + event);
        if (filename) {
            //var buffer = [];
            //fs.read(logPath + filename, buffer, 0, 10, 0, function (error, bytesRead, buffer) {
            //    console.log(buffer);
            //});
            //var readStream = fs.createReadStream(logPath + filename, {autoClose: true, encoding: "utf8", start: 0, end: 20 });
            //readStream.on('data', function (chunk) {
            //    console.log(chunk.trim());
            //});
            fs.readFile(logPath + filename, 'utf8', function (err, data) {
                try {
                    if (err) {
                        return console.log(err);
                    }

                    var channelDatas = data.trim().split(";");
                    var channelName = filename.split(".")[CHANNEL_NAME_INDEX];
                    var channelValue = parseFloat(channelDatas[CHANNEL_VALUE_INDEX], 0);

                    totalFile++;
                    //console.log("update-channel-" + channelName);
                    GLOBAL.eventEmitter.emit("update-channel-" + channelName, channelValue);
                    //console.log(totalFile / (Date.now() - t) * 1000)
                } catch (e) {
                    console.error(e);
                }
            });
            //console.log('filename provided: ' + filename);
        } else {
            //console.log('filename not provided');
        }
    });
};
