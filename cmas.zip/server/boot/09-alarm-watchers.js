﻿var moment = require("moment");
var EventEmitter = require("events").EventEmitter;

if (!GLOBAL.eventEmitter) {
    GLOBAL.eventEmitter = new EventEmitter();
}

function emitEvent() {
    GLOBAL.eventEmitter.emit.apply(GLOBAL.eventEmitter, arguments);
}

function removeListener() {
    GLOBAL.eventEmitter.removeListener.apply(GLOBAL.eventEmitter, arguments);
}

function listen() {
    GLOBAL.eventEmitter.on.apply(GLOBAL.eventEmitter, arguments);
}

module.exports = function startAlarmWatchers(app) {

    var cmasConfig = app.get("cmas") || {};
    var dateFormat = "DD/MM/YYYY HH:mm:ss";
    app.AlarmWatcherService = this;

    var AlarmWatcher = app.models.AlarmWatcher;
    var Messages = app.models.Messages;
    var AlarmLog = app.models.AlarmLog;
    var alarmWatchersCache = {};

    var conditions = {
        "greaterthan": function(a, b) {
            return a > b;
        },
        "lessthan": function(a, b) {
            return a < b;
        },
        "equalto": function(a, b) {
            return a === b;
        },
        "notequalto": function(a, b) {
            return a !== b;
        },
        "greaterthanorequalto": function(a, b) {
            return a >= b;
        },
        "lessthanorequalto": function(a, b) {
            return a <= b;
        }
    };

    var AlarmStatus = AlarmWatcher.AlarmStatus || {
            INACTIVE: "inactive",
            ACTIVE: "active",
            ACKNOWLEDGE: "acknowledge",
            RESET: "reset"
        };

    AlarmWatcher.prototype.setEnable = function(id, cb) {
        if (alarmWatchersCache[id]) {
            if (!alarmWatchersCache[id].enable) {
                alarmWatchersCache[id].stoplistenChannel();
                alarmWatchersCache[id].enable = true;
                alarmWatchersCache[id].save(function(err, instance) {
                    updateAlarmWatchers([instance]);
                    cb(null, "Alarm " + id + "is enable");
                })
            } else {
                cb(null, "Alarm " + id + " already enable");
            }
        } else {
            AlarmWatcher.findOne({
                where: {
                    id: id
                }
            }, function(err, alarmWatcherInstance) {
                if (err) {
                    cb(err);
                } else if (alarmWatcherInstance) {
                    if (alarmWatcherInstance.enable) {
                        cb(null, "Alarm " + id +
                        " already enable");
                    } else {
                        alarmWatcherInstance.enable = true;
                        alarmWatcherInstance.save(function(err,
                                                           instance) {
                            updateAlarmWatchers([
                                instance
                            ]);
                            cb(200, "Alarm " + id +
                            "is enable");
                        })
                    }
                }
            })
        }
    };

    AlarmWatcher.prototype.disable = function(id, cb) {
        if (alarmWatchersCache[id]) {
            if (alarmWatchersCache[id].enable) {
                alarmWatchersCache[id].stoplistenChannel();
                alarmWatchersCache[id].enable = false;
                alarmWatchersCache[id].save(function(err, instance) {
                    cb(null, "Alarm " + id + "is disable");
                })
            }
        } else {
            cb(null, "Alarm is not enable yet");
        }
    };

    AlarmWatcher.prototype.acknowledge = function(id, cb) {
        if (alarmWatchersCache[id]) {
            var alarmWatcher = alarmWatchersCache[id];
            if (alarmWatcher) {
                if (alarmWatcher.status === "reset") {
                    alarmWatcher.status = "inactive";
                    alarmWatcher.acknowledgeAt = new Date();
                    alarmWatcher.save(function(err, instance) {
                        if (err) console.log(err);
                        alarmWatcher.alarmLogs.create({
                            alarmAt: alarmWatcher.alarmAt,
                            resetAt: alarmWatcher.resetAt,
                            acknowledgeAt: alarmWatcher.acknowledgeAt,
                            acknowledgeBy: "admin"
                        }, function(err, alarmLog) {
                            if (err) {
                                console.log(err);
                            }
                            console.log(alarmLog);
                        });
                        GLOBAL.eventEmitter.emit("update-alarm",
                            alarmWatcher);
                    });
                } else if (alarmWatcher.status === "active") {
                    alarmWatcher.status = "acknowledge";
                    alarmWatcher.acknowledgeAt = new Date();
                    alarmWatcher.save(function(err, instance) {
                        if (err) console.log(err);
                        GLOBAL.eventEmitter.emit("update-alarm",
                            alarmWatcher);
                    });
                }
            }
        } else {
            AlarmWatcher.find({
                where: {
                    id: id
                }
            }, function(error, alarmWatchers) {
                console.log(alarmWatchers);
                for (var i in alarmWatchers) {
                    var alarmWatcher = alarmWatchers[i];
                    if (alarmWatcher) {
                        if (alarmWatcher.status === "reset") {
                            alarmWatcher.status = "inactive";
                            alarmWatcher.acknowledgeAt = new Date();
                            alarmWatcher.save(function(err,
                                                       instance) {
                                if (err) {console.log(err);}
                                alarmWatcher.alarmLogs.create({
                                    alarmAt: alarmWatcher.alarmAt,
                                    resetAt: alarmWatcher.resetAt,
                                    acknowledgeAt: alarmWatcher.acknowledgeAt,
                                    acknowledgeBy: "admin"
                                }, function(err, alarmLog) {
                                    if (err) {console.log(err);}
                                    console.log(alarmLog);
                                });
                                emitEvent("update-alarm", alarmWatcher);
                            });
                        } else if (alarmWatcher.status === "active") {
                            alarmWatcher.status = "acknowledge";
                            alarmWatcher.acknowledgeAt = new Date();
                            alarmWatcher.save(function(err,
                                                       instance) {
                                if (err) {console.log(err);}
                                emitEvent("update-alarm", alarmWatcher);
                            });
                        }
                    }
                }
            });
        }
        cb(null, "Acknowledge... " + id);
    };

    AlarmWatcher.prototype.stoplistenChannel = function() {
        "use strict";
        var alarmWatcher = this;
        if (alarmWatcher) {
            if (alarmWatcher.channelUpdateHandler) {
                console.log("Remove Listenner");
                //removeListener
                removeListener("update-channel-" +
                    alarmWatcher.channel().name, alarmWatcher.channelUpdateHandler
                );
            }
        }
    };

    AlarmWatcher.prototype.listenChannel = function() {
        "use strict";
        var alarmWatcher = this;
        console.log(alarmWatcher.escalationProfile());
        var escalationProfile = alarmWatcher.escalationProfile().configuration || {interval: 300};

        if (!alarmWatcher.channel()) {
            return;
        }
        if (alarmWatcher) {
            if (alarmWatcher.channelUpdateHandler) {
                //removeListener
                removeListener("update-channel-" +
                    alarmWatcher.channel().name, alarmWatcher.channelUpdateHandler
                );
            } else {
                alarmWatcher.channelUpdateHandler = function(data) {
                    alarmWatcher.lastUpdated = Date.now();
                    if (alarmWatcher.alarmConditionChecker(data, alarmWatcher.alarmThreshold)) {
                        console.log("ALARM : " + alarmWatcher.id);
                        if (alarmWatcher.status === AlarmStatus.INACTIVE) {
                            alarmWatcher.status = AlarmStatus.ACTIVE;
                            alarmWatcher.alarmAt = Date.now();
                            alarmWatcher.resetAt = null;
                            alarmWatcher.acknowledgeAt = null;
                            alarmWatcher.lastEscalationAt = Date.now();
                            alarmWatcher.save(function(err,
                                                       instance) {
                                if (err) console.log(err);
                                GLOBAL.eventEmitter.emit(
                                    "update-alarm",
                                    alarmWatcher);
                            });
                            if (alarmWatcher.notificationMethod && alarmWatcher.notificationMethod.sms &&
                                (alarmWatcher.notificationMethod.notifyWhen === "all" ||
                                alarmWatcher.notificationMethod.notifyWhen === "alarm")) {
                                // Send message
                                var alarmMessage = alarmWatcher.msg.alarm  + " - " + data + " - " + moment(alarmWatcher.alarmAt).format(dateFormat);
                                emitEvent("sms", {
                                    content: alarmMessage
                                });
                                Messages.create({
                                    type: "sms",
                                    target: cmasConfig.sms || "",
                                    content: alarmMessage,
                                    createAt: Date.now()
                                });
                                Messages.create({
                                    type: "sms",
                                    target: cmasConfig.sms1 || "",
                                    content: alarmMessage,
                                    createAt: Date.now()
                                });
                                Messages.create({
                                    type: "sms",
                                    target: cmasConfig.sms2 || "",
                                    content: alarmMessage,
                                    createAt: Date.now()
                                });
                                Messages.create({
                                    type: "sms",
                                    target: cmasConfig.sms3 || "",
                                    content: alarmMessage,
                                    createAt: Date.now()
                                });
                            }

                            if (alarmWatcher.notificationMethod && alarmWatcher.notificationMethod.email &&
                                (alarmWatcher.notificationMethod.notifyWhen === "all" ||
                                alarmWatcher.notificationMethod.notifyWhen === "alarm")) {
                                // Send email
                                var alarmLocation = alarmWatcher.channel().unit().location();
                                var emailSubject = alarmWatcher.msg.alarm;
                                var emailContent = alarmWatcher.msg.alarm  + " - " + data + " - " + moment(alarmWatcher.alarmAt).format(dateFormat);
                                var email = {
                                    destination: cmasConfig.alarmEmailAddress,
                                    subject: emailSubject,
                                    content: emailContent
                                }
                                GLOBAL.eventEmitter.emit("mailTo", email);
                                var email = {
                                    destination: cmasConfig.alarmEmailAddress1,
                                    subject: emailSubject,
                                    content: emailContent
                                }
                                GLOBAL.eventEmitter.emit("mailTo", email);
                                var email = {
                                    destination: cmasConfig.alarmEmailAddress2,
                                    subject: emailSubject,
                                    content: emailContent
                                }
                                GLOBAL.eventEmitter.emit("mailTo", email);
                            }
                        } else if (alarmWatcher.status ===
                            AlarmStatus.RESET) {
                            alarmWatcher.status = AlarmStatus.ACTIVE;

                            if (escalationProfile.interval > 0 && (Date.now() - alarmWatcher.lastEscalationAt > escalationProfile.interval * 1000)) {
                                // Send escalation
                                if (alarmWatcher.notificationMethod && alarmWatcher.notificationMethod.sms) {
                                    // Send SMS
                                    var alarmMessage = alarmWatcher.msg.alarm  + " - " + data + " - " + moment(alarmWatcher.alarmAt).format(dateFormat);
                                    emitEvent("sms", {
                                        content: alarmMessage
                                    });
                                    alarmWatcher.lastEscalationAt = Date.now();
                                    Messages.create({
                                        type: "sms",
                                        target: cmasConfig.sms || "",
                                        content: alarmMessage,
                                        createAt: Date.now()
                                    });
                                    Messages.create({
                                        type: "sms",
                                        target: cmasConfig.sms1 || "",
                                        content: alarmMessage,
                                        createAt: Date.now()
                                    });
                                    Messages.create({
                                        type: "sms",
                                        target: cmasConfig.sms2 || "",
                                        content: alarmMessage,
                                        createAt: Date.now()
                                    });
                                    Messages.create({
                                        type: "sms",
                                        target: cmasConfig.sms3 || "",
                                        content: alarmMessage,
                                        createAt: Date.now()
                                    });
                                }

                                if (alarmWatcher.notificationMethod && alarmWatcher.notificationMethod.email) {
                                    // Send email
                                    var alarmLocation = alarmWatcher.channel().unit().location();
                                    var emailSubject = alarmWatcher.msg.alarm;
                                    var emailContent = alarmWatcher.msg.alarm  + " - " + data + " - " + moment(alarmWatcher.alarmAt).format(dateFormat);
                                    var email = {
                                        destination: cmasConfig.alarmEmailAddress,
                                        subject: emailSubject,
                                        content: emailContent
                                    }
                                    GLOBAL.eventEmitter.emit("mailTo", email);
                                    var email = {
                                        destination: cmasConfig.alarmEmailAddress1,
                                        subject: emailSubject,
                                        content: emailContent
                                    }
                                    GLOBAL.eventEmitter.emit("mailTo", email);
                                    var email = {
                                        destination: cmasConfig.alarmEmailAddress2,
                                        subject: emailSubject,
                                        content: emailContent
                                    }
                                    GLOBAL.eventEmitter.emit("mailTo", email);
                                }
                            }

                            alarmWatcher.save(function(err,
                                                       instance) {
                                if (err) console.log(err);
                                GLOBAL.eventEmitter.emit(
                                    "update-alarm",
                                    alarmWatcher);
                            });
                        } else {
                            if (escalationProfile.interval > 0 && (Date.now() - alarmWatcher.lastEscalationAt > escalationProfile.interval * 1000)) {
                                // Send escalation
                                if (alarmWatcher.notificationMethod && alarmWatcher.notificationMethod.sms) {
                                    var alarmMessage = alarmWatcher.msg.alarm  + " - " + data + " - " + moment(alarmWatcher.alarmAt).format(dateFormat);
                                    emitEvent("sms", {
                                        content: alarmMessage
                                    });
                                    alarmWatcher.lastEscalationAt = Date.now();
                                    Messages.create({
                                        type: "sms",
                                        target: cmasConfig.sms || "",
                                        content: alarmMessage,
                                        createAt: Date.now()
                                    });
                                    Messages.create({
                                        type: "sms",
                                        target: cmasConfig.sms1 || "",
                                        content: alarmMessage,
                                        createAt: Date.now()
                                    });
                                    Messages.create({
                                        type: "sms",
                                        target: cmasConfig.sms2 || "",
                                        content: alarmMessage,
                                        createAt: Date.now()
                                    });
                                    Messages.create({
                                        type: "sms",
                                        target: cmasConfig.sms3 || "",
                                        content: alarmMessage,
                                        createAt: Date.now()
                                    });
                                }

                                if (alarmWatcher.notificationMethod && alarmWatcher.notificationMethod.email) {
                                    // Send email
                                    var alarmLocation = alarmWatcher.channel().unit().location();
                                    var emailSubject = alarmWatcher.msg.alarm;
                                    var emailContent = alarmWatcher.msg.alarm  + " - " + data + " - " + moment(alarmWatcher.alarmAt).format(dateFormat);
                                    var email = {
                                        destination: cmasConfig.alarmEmailAddress,
                                        subject: emailSubject,
                                        content: emailContent
                                    }
                                    GLOBAL.eventEmitter.emit("mailTo", email);
                                    var email = {
                                        destination: cmasConfig.alarmEmailAddress1,
                                        subject: emailSubject,
                                        content: emailContent
                                    }
                                    GLOBAL.eventEmitter.emit("mailTo", email);
                                    var email = {
                                        destination: cmasConfig.alarmEmailAddress2,
                                        subject: emailSubject,
                                        content: emailContent
                                    }
                                    GLOBAL.eventEmitter.emit("mailTo", email);
                                }
                                alarmWatcher.save(function(err,
                                                           instance) {
                                    if (err) console.log(err);
                                    GLOBAL.eventEmitter.emit(
                                        "update-alarm",
                                        alarmWatcher);
                                });
                            }
                        }
                    } else if (alarmWatcher.resetConditionChecker(data, alarmWatcher.resetThreshold)) {
                        if (alarmWatcher.status === AlarmStatus.ACTIVE) {
                            console.log("RESET: " + alarmWatcher.id);
                            alarmWatcher.status = AlarmStatus.RESET;
                            alarmWatcher.resetAt = Date.now();

                            if (alarmWatcher.notificationMethod && alarmWatcher.notificationMethod.sms && (alarmWatcher.notificationMethod.notifyWhen === "all" ||
                                alarmWatcher.notificationMethod.notifyWhen === "reset")) {
                                var alarmMessage = alarmWatcher.msg.reset  + " - " + data + " - " + moment(alarmWatcher.alarmAt).format(dateFormat);
                                emitEvent("sms", {
                                    content: alarmMessage
                                });
                                alarmWatcher.lastEscalationAt = Date.now();
                                Messages.create({
                                    type: "sms",
                                    target: cmasConfig.sms || "",
                                    content: alarmMessage,
                                    createAt: Date.now()
                                });
                                Messages.create({
                                    type: "sms",
                                    target: cmasConfig.sms1 || "",
                                    content: alarmMessage,
                                    createAt: Date.now()
                                });
                                Messages.create({
                                    type: "sms",
                                    target: cmasConfig.sms2 || "",
                                    content: alarmMessage,
                                    createAt: Date.now()
                                });
                                Messages.create({
                                    type: "sms",
                                    target: cmasConfig.sms3 || "",
                                    content: alarmMessage,
                                    createAt: Date.now()
                                });
                            }

                            if (alarmWatcher.notificationMethod && alarmWatcher.notificationMethod.email && (alarmWatcher.notificationMethod.notifyWhen === "all" ||
                                alarmWatcher.notificationMethod.notifyWhen === "reset")) {
                                // Send email
                                var alarmLocation = alarmWatcher.channel().unit().location();
                                var emailSubject = alarmWatcher.msg.reset;
                                var emailContent = alarmWatcher.msg.reset  + " - " + data + " - " + moment(alarmWatcher.alarmAt).format(dateFormat);
                                var email = {
                                    destination: cmasConfig.alarmEmailAddress,
                                    subject: emailSubject,
                                    content: emailContent
                                }
                                GLOBAL.eventEmitter.emit("mailTo", email);
                                var email = {
                                    destination: cmasConfig.alarmEmailAddress1,
                                    subject: emailSubject,
                                    content: emailContent
                                }
                                GLOBAL.eventEmitter.emit("mailTo", email);
                                var email = {
                                    destination: cmasConfig.alarmEmailAddress2,
                                    subject: emailSubject,
                                    content: emailContent
                                }
                                GLOBAL.eventEmitter.emit("mailTo", email);
                            }

                            alarmWatcher.save(function(err,
                                                       instance) {
                                if (err) console.log(err);
                                emitEvent(
                                    "update-alarm",
                                    alarmWatcher);
                            });
                            return;
                        } else if (alarmWatcher.status === AlarmStatus.ACKNOWLEDGE) {
                            console.log("INACTIVE: " + alarmWatcher.id);
                            alarmWatcher.status = AlarmStatus.INACTIVE;
                            alarmWatcher.resetAt = Date.now();

                            if (alarmWatcher.notificationMethod && alarmWatcher.notificationMethod.sms && (alarmWatcher.notificationMethod.notifyWhen === "all" ||
                                alarmWatcher.notificationMethod.notifyWhen === "reset")) {
                                var alarmMessage = alarmWatcher.msg.reset  + " - " + data + " - " + moment(alarmWatcher.alarmAt).format(dateFormat);
                                emitEvent("sms", {
                                    content: alarmMessage
                                });
                                alarmWatcher.lastEscalationAt = Date.now();
                                Messages.create({
                                    type: "sms",
                                    target: cmasConfig.sms || "",
                                    content: alarmMessage,
                                    createAt: Date.now()
                                });
                                Messages.create({
                                    type: "sms",
                                    target: cmasConfig.sms1 || "",
                                    content: alarmMessage,
                                    createAt: Date.now()
                                });
                                Messages.create({
                                    type: "sms",
                                    target: cmasConfig.sms2 || "",
                                    content: alarmMessage,
                                    createAt: Date.now()
                                });
                                Messages.create({
                                    type: "sms",
                                    target: cmasConfig.sms3 || "",
                                    content: alarmMessage,
                                    createAt: Date.now()
                                });
                            }

                            if (alarmWatcher.notificationMethod && alarmWatcher.notificationMethod.email && (alarmWatcher.notificationMethod.notifyWhen === "all" ||
                                alarmWatcher.notificationMethod.notifyWhen === "reset")) {
                                // Send email
                                var alarmLocation = alarmWatcher.channel().unit().location();
                                var emailSubject = alarmWatcher.msg.reset;
                                var emailContent = alarmWatcher.msg.reset  + " - " + data + " - " + moment(alarmWatcher.alarmAt).format(dateFormat);
                                var email = {
                                    destination: cmasConfig.alarmEmailAddress,
                                    subject: emailSubject,
                                    content: emailContent
                                }
                                GLOBAL.eventEmitter.emit("mailTo", email);
                                var email = {
                                    destination: cmasConfig.alarmEmailAddress1,
                                    subject: emailSubject,
                                    content: emailContent
                                }
                                GLOBAL.eventEmitter.emit("mailTo", email);
                                var email = {
                                    destination: cmasConfig.alarmEmailAddress2,
                                    subject: emailSubject,
                                    content: emailContent
                                }
                                GLOBAL.eventEmitter.emit("mailTo", email);
                            }
                            alarmWatcher.save(function(err, instance) {
                                if (err) console.log(err);
                                alarmWatcher.alarmLogs.create({
                                    alarmAt: alarmWatcher.alarmAt,
                                    resetAt: alarmWatcher.resetAt,
                                    acknowledgeAt: alarmWatcher.acknowledgeAt,
                                    acknowledgeBy: "admin"
                                }, function(err, alarmLog) {
                                    if (err) {console.log(err);}
                                });
                                emitEvent("update-alarm", alarmWatcher);
                            });
                            return;
                        }
                    }
                }
            }
            if (alarmWatcher.channel()) {
                listen("update-channel-" + alarmWatcher.channel().name, alarmWatcher.channelUpdateHandler);
            }
        }
    };

    var updateAlarmWatchers = function(alarmWatchers) {
        for (var i in alarmWatchers) {
            var alarmWatcher = alarmWatchers[i];
            if (!alarmWatcher.enable) {
                continue;
            }
            if (alarmWatchersCache[alarmWatcher.id]) {
                alarmWatchersCache[alarmWatcher.id].stoplistenChannel();
            }
            alarmWatcher.alarmConditionChecker = conditions[
                alarmWatcher.alarmCondition] || function() {
                return false
            };
            alarmWatcher.resetConditionChecker = conditions[
                alarmWatcher.resetCondition] || function() {
                return false
            };
            alarmWatchersCache[alarmWatcher.id] = alarmWatcher;
            alarmWatcher.listenChannel();
        }
    };

    AlarmWatcher.find({
            "include": [{
                channel: [{
                    unit: [{
                        location: "location"
                    }]
                }]
            }, {
                escalationProfile: {}
            }]
        }
        , function(err, alarmWatchers) {
            updateAlarmWatchers(alarmWatchers);
        });

    listen("alarm-watcher-updated", function(alarmWatcherInstance) {
        var alarmWatcher = alarmWatchersCache[alarmWatcherInstance.id];
        if (!alarmWatcher) {
            AlarmWatcher.find({
                where: {
                    id: alarmWatcherInstance.id
                },
                "include": [{
                    channel: [{
                        unit: [{
                            location: "location"
                        }]
                    }]
                }, {
                    escalationProfile: {}
                }]
            }, function(err, alarmWatchers) {
                updateAlarmWatchers(alarmWatchers);
            });
        } else {
            console.log("Update Alarm Watcher");
            alarmWatcher.stoplistenChannel();
            AlarmWatcher.find({
                where: {
                    id: alarmWatcherInstance.id
                },
                "include": [{
                    channel: [{
                        unit: [{
                            location: "location"
                        }]
                    }]
                }, {
                    escalationProfile: {}
                }]
            }, function(err, alarmWatchers) {
                console.log(alarmWatchers.length);
                updateAlarmWatchers(alarmWatchers);
            });
        }
    });
};