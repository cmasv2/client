module.exports = function mountRestApi(server) {
    var restApiRoot = server.get('restApiRoot');
    var path = require('path');
    var jsonfile = require("jsonfile");
    jsonfile.spaces = 4;

    var file = path.resolve(__dirname, '../config.json');


    jsonfile.readFile(file, function(err, obj) {

        var config = obj;
        server.get(restApiRoot + "/configuration/:id", function(req, res, next) {
            switch (req.params.id) {
                case "alarmEmailAddress":
                    res.status(200).json({
                        "alarmEmailAddress": server.get("cmas")["alarmEmailAddress"]
                    });
                    break;
                default:
                    res.status(404).send();
                    break;
            }
        });

        server.post(restApiRoot + "/configuration/:id", function(req, res, next) {
            switch (req.params.id) {
                case "alarmEmailAddress":
                    if (req.body && req.body["alarmEmailAddress"]) {
                        config.cmas["alarmEmailAddress"] = req.body["alarmEmailAddress"];
                        jsonfile.writeFile(file, config, function(err) {
                            console.error(err)
                        })
                        server.set("cmas", config.cmas);
                    } else {
                        res.status(300).send();
                    }

                    res.status(200).send();
                    break;
                default:
                    res.status(404).send();
                    break;
            }
        });

        server.use(restApiRoot, server.loopback.rest());
    })

};
