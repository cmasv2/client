var Q = require("q");
var path = require("path");

/**
 * Created by Tan on 2/8/15.
 */
module.exports = function(app) {

    var dataSource = app.dataSources.cmasDatabase;
    console.log(app.resetDataBase);

    console.log(app.dataSources.cmasDatabase.settings);

    if (app.resetDataBase) {
        console.log("ResetDataBase");
        var mysql = require('mysql');

        var pool = mysql.createPool(dataSource.settings);

        pool.getConnection(function(err, connection) {
            var fs = require("fs");

            fs.readFile('cmas.sql', 'utf8', function(err, data) {
                if (err) {
                    return console.log(err);
                }

                var query = data;

                dataSource.autoupdate(["EscalationProfile","Controllable", "AlarmWatcher", "Messages", "Location", "Unit", "CMASUser", "CMASRole", "Permission", "RolePermissionMapper", "CMASUser", "Activity", "Action", "Job"], function(err) {
                    if (err) console.log(err);

                    createUserData()
                        .then(createEscalationProfile)
                        .then(createUnitData)
                        .then(createAlarmWatcher)
                        .catch(function(error) {
                            console.log(error)
                        })
                        .done(function() {
                            console.log("Done");
                        });
                });
            });
        });

    } else {
        dataSource.autoupdate(["EscalationProfile","Controllable", "AlarmWatcher", "Messages", "Location", "Unit", "CMASUser", "CMASRole", "Permission", "RolePermissionMapper", "CMASUser", "Activity", "Action", "Job"], function(err) {
            if (err) console.log(err);
        });
    }

    function createUserData() {
        var deferred = Q.defer();
        var User = app.models.CMASUser;
        var Role = app.models.CMASRole;
        var RoleMapping = app.models.RoleMapping;

        User.destroyAll({}, function(err) {
            if (err) {
                console.log(err);
                deferred.resolve();
                return;
            }
            
            User.create([{
                username: 'admin',
                email: 'admin@cmas.com',
                password: 'admin'
            }, {
                username: 'operator',
                email: 'operator@cmas.com',
                password: 'operator'
            }], function(err, users) {
                if (err) {
                    console.log(err);
                    deferred.resolve();
                    return;
                }

                // Create projects, assign project owners and project team members

                // Create the admin role
                // 
                Role.create({
                    name: 'admin'
                }, function(err, role) {
                    if (err) {
                        console.log(err);
                        deferred.resolve();
                        return;
                    }
                    //debug(role);

                    // Make Admin an admin
                    role.principals.create({
                       principalType: RoleMapping.USER,
                       principalId: users[0].id
                    }, function (err, principal) {
                       if (err) return;
                       //debug(principal);
                    });

                    deferred.resolve();
                });
            });
        });


        //CMASUser.create({email: 'admin@admin.com', password: 'admin'}, function (err, user) {
        //    console.log(user);
        //    deferred.resolve();
        //});
        return deferred.promise;
    }

    function createUnitData() {
        console.log("Create Unit data");
        var deferred = Q.defer();

        var Location = app.models.Location;
        var Unit = app.models.Unit;
        var Channel = app.models.Channel;
        var ChannelData = app.models.ChannelData;

        //Converter Class
        var Converter = require("csvtojson").core.Converter;
        var fs = require("fs");
        /* REMOVE COMMENTS ON THESE LINES */
        var unitStructureFileName = path.resolve(__dirname, "./../data/unit_structure.csv");
        var channelStructureFileName = path.resolve(__dirname, "./../data/channel_structure.csv");
        var unitStructureFs = fs.createReadStream(unitStructureFileName);
        var channelStructureFs = fs.createReadStream(channelStructureFileName);

        var csvConverter = new Converter({
            constructResult: true
        });
        var count = 0;

        csvConverter.on("end_parsed", function(locations) {
            console.log(locations);
            var channelCSVConverter = new Converter({});

            count += locations.length;

            channelCSVConverter.on("end_parsed", function(channels) {
                console.log(channels);
                count += channels.length;

                ChannelData.destroyAll({}, function(err) {
                    if (err) {
                        console.error(err);
                    } else {
                        Channel.destroyAll({}, function(err) {
                            if (err) {
                                console.error(err);
                            } else {
                                Unit.destroyAll({}, function(err) {
                                    if (err) {
                                        console.error(err);
                                    } else {
                                        Location.destroyAll({}, function(err) {
                                            if (err) {
                                                console.error(err);
                                            } else {
                                                locations.forEach(function(location) {
                                                    Location.create(location, function(err, locationInstance) {
                                                        if (err) {
                                                            console.error(err);
                                                            count--;

                                                            if (count === 0) {
                                                                deferred.resolve();
                                                                console.log('Done');
                                                            }
                                                        } else {
                                                            if (locationInstance.type === "unit" || locationInstance.type === "component") {
                                                                // save to unit entry
                                                                Unit.create(location, function(err, unitInstance) {
                                                                    if (err) {
                                                                        console.error(err);
                                                                    } else {
                                                                        // Do nothing
                                                                    }
                                                                    count--;

                                                                    if (count === 0) {
                                                                        deferred.resolve();
                                                                        console.log('Done');
                                                                    }
                                                                })
                                                            } else {
                                                                count--;

                                                                if (count === 0) {
                                                                    deferred.resolve();
                                                                    console.log('Done');
                                                                }

                                                            }
                                                        }


                                                    });
                                                });

                                                function newChannel(channel, callback) {
                                                    channel.historyInterval = channel["History Interval"] || 1;
                                                    channel.name = channel["name"] ? channel.name : channel["Name"];
                                                    Channel.create(channel, function(err, channelInstance) {
                                                        if (err) {
                                                            console.error(err);
                                                            console.error(channel);
                                                        } else {
                                                            // Do nothing
                                                            console.log(channelInstance);
                                                        }
                                                        if (callback) {
                                                            callback()
                                                        };
                                                        count--;

                                                        if (count === 0) {
                                                            deferred.resolve();
                                                            console.log('Done');
                                                        }
                                                    });
                                                }
                                                channels.forEach(function(channel) {
                                                    newChannel(channel);
                                                });
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    }
                });
            });

            channelStructureFs.pipe(channelCSVConverter);

        });

        unitStructureFs.pipe(csvConverter);

        return deferred.promise;
    };

    function createAlarmWatcher() {
        var deferred = Q.defer();
        var AlarmWatcher = app.models.AlarmWatcher;
        AlarmWatcher.destroyAll({}, function(err) {
            var Channel = app.models.Channel;
            Channel.findOne({}, function(err, channel) {
                if (err) {
                    return;
                } else {
                    AlarmWatcher.create({
                        "channelID": channel.id,
                        "enable": false,
                        "status": AlarmWatcher.AlarmStatus.INACTIVE,
                        "type": "critical",
                        "escalationProfileID": 1,
                        "alarmCondition": "greaterthan",
                        "alarmThreshold": 22,
                        "resetCondition": "lessthan",
                        "resetThreshold": 21,
                        "notificationMethod": {sms: true, notifyWhen: "all"},
                        "msg": {"alarm":"Alarm !","reset":"Reset !"}
                    }, function(err, alarmWatcher) {
                        console.log(alarmWatcher);
                        deferred.resolve();
                    });

                    AlarmWatcher.create({
                        "channelID": channel.id,
                        "enable": false,
                        "status": AlarmWatcher.AlarmStatus.INACTIVE,
                        "type": "critical",
                        "escalationProfileID": 1,
                        "alarmCondition": "lessthan",
                        "alarmThreshold": 15,
                        "resetCondition": "greaterthan",
                        "resetThreshold": 18,
                        "notificationMethod": {sms: true, notifyWhen: "reset"},
                        "msg": {"alarm":"Alarm !","reset":"Reset !"}
                    }, function(err, alarmWatcher) {
                        console.log(alarmWatcher);
                        deferred.resolve();
                    });
                }
            });
        })
        return deferred.promise;
    }

    function createEscalationProfile() {
        var deferred = Q.defer();
        var EscalationProfile = app.models.EscalationProfile;
        var escalationProfileData = require(path.resolve(__dirname, "./../data/escalation-profiles.json"));
        EscalationProfile.destroyAll({}, function(err) {
            deferred.resolve();
            if (err) {
                console.log(err);
                deferred.resolve();
            } else {
                EscalationProfile.create(escalationProfileData, function (err, instances) {
                    if (err) {
                        console.log(err);
                    }
                    console.log("Resolve");
                    deferred.resolve();
                })
            }
        });
        return deferred.promise;
    }


};
