module.exports = function(server) {

    var Unit = server.models.Unit;
    var Location = server.models.Location;
    var AlarmLog = server.models.AlarmLog;
    var Q = require("q");
    var _ = require("underscore");
    var ChannelHistory = server.models.ChannelHistory;
    var mysql = require("mysql");
    var moment = require("moment");
    var dataSource = server.dataSources.cmasDatabase;
    var pool = mysql.createPool(dataSource.settings);

    ChannelHistory.prototype.findByTimeRange = function(id, limit, startDate, endDate, cb) {
        //console.log(arguments);

        var sqlDateTimeFormat = "YYYY-MM-DD HH:mm:ss.SSS";

        //console.log(cb.res);
        var filter = {};
        filter.limit = filter.limit || limit || 500;
        filter.startDate = filter.startDate || startDate;
        filter.endDate = filter.endDate || endDate;

        var startDate = moment(Date.parse(filter.startDate)).format(sqlDateTimeFormat);
        var endDate = moment(Date.parse(filter.endDate)).format(sqlDateTimeFormat);

        var queryString = 'call selectChannelHistoryByTimeRange("' + startDate + '","' + endDate + '",' + id + ', ' + filter.limit + ');';
        //console.log(queryString);
        pool.query(queryString, function(err, result) {
            if (err) {
                cb(null, err);
            } else {
                cb(null, result[0]);
            }
        });

    };

    ChannelHistory.beforeRemote('_findByTimeRange', function(ctx, unused, next) {
        //console.log(ctx.args);
        if (typeof(ctx.args.id) !== "number") {
            ctx.res.status(400).send("Invalid Channel ID");
            return;
        }

        if (typeof(ctx.args.startDate) !== "string") {
            ctx.res.status(400).send("startDate should be string");
            return;
        } else if (!moment(Date.parse(ctx.args.startDate)).isValid()) {
            ctx.res.status(400).send("startDate invalid");
            return;
        }

        if (typeof(ctx.args.endDate) !== "string") {
            ctx.res.status(400).send("endDate should be string");
            return;
        } else if (!moment(Date.parse(ctx.args.endDate)).isValid()) {
            ctx.res.status(400).send("endDate invalid");
            return;
        }

        if (typeof(ctx.args.limit) !== "number") {
            ctx.res.status(400).send("limit should be number");
            return;
        } else if (ctx.args.limit <= 0 || ctx.args.limit > 10000) {
            ctx.res.status(400).send("Limit should > 0 and <= 9999");
            return;
        }

        next();
    });

    ChannelHistory.prototype.averageByTimeRange = function(id, startDate, endDate, cb) {
        //console.log(arguments);

        var sqlDateTimeFormat = "YYYY-MM-DD HH:mm:ss.SSS";

        //console.log(cb.res);
        var filter = {};
        filter.startDate = filter.startDate || startDate;
        filter.endDate = filter.endDate || endDate;

        var startDate = moment(Date.parse(filter.startDate)).format(sqlDateTimeFormat);
        var endDate = moment(Date.parse(filter.endDate)).format(sqlDateTimeFormat);

        var queryString = 'call getChannelHistoryAvgByTimeRange("' + startDate + '","' + endDate + '",' + id + ');';
        //console.log(queryString);
        pool.query(queryString, function(err, result) {
            console.log(result);
            if (err) {
                cb(null, err);
            } else {
                cb(null, result[0][0]["avg(value)"]);
            }
        });
    };

    ChannelHistory.beforeRemote('_averageByTimeRange', function(ctx, unused, next) {
        //console.log(ctx.args);
        if (typeof(ctx.args.id) !== "number") {
            ctx.res.status(400).send("Invalid Channel ID");
            return;
        }

        if (typeof(ctx.args.startDate) !== "string") {
            ctx.res.status(400).send("startDate should be string");
            return;
        } else if (!moment(Date.parse(ctx.args.startDate)).isValid()) {
            ctx.res.status(400).send("startDate invalid");
            return;
        }

        if (typeof(ctx.args.endDate) !== "string") {
            ctx.res.status(400).send("endDate should be string");
            return;
        } else if (!moment(Date.parse(ctx.args.endDate)).isValid()) {
            ctx.res.status(400).send("endDate invalid");
            return;
        }

        next();
    });

    Location.prototype.getAlarmLogs = function(id, startDate, endDate, cb) {

        getUnitsOfLocation(id, []).then(function(units) {
            var deferred = Q.defer();

            var promises = [];
            var channels = [];
            units.forEach(function(unit) {
                promises.push(getChannelsOfUnit(unit.id, channels));
            });

            Q.allSettled(promises).then(function(results) {
                deferred.resolve(results);
            }, function(error) {
                deferred.reject(error);
            });

            return deferred.promise;
        }).then(function(channels) {
            //console.log(channels);
            var results = []
            _.forEach(channels, function(channel) {
                results.push(channel.value);
            })

            results = _.flatten(results);

            var channelIDs = [];
            var alarmWatcherIDs = [];
            _.forEach(results, function(channel) {
                if (channelIDs.indexOf(channel.id) < 0) {
                    channelIDs.push(channel.id);
                }

                _.forEach(channel.alarmWatcher(), function(alarmWatcher) {
                    if (alarmWatcherIDs.indexOf(alarmWatcher.id) < 0) {
                        alarmWatcherIDs.push(alarmWatcher.id);
                    }
                });
            });

            console.log(startDate);

            AlarmLog.find({
                where: {
                    and: [
                        {
                            alarmWatcherId: {
                                inq: alarmWatcherIDs
                            }
                        }, {
                            or: [
                                {
                                    and: [
                                        {
                                            alarmAt: {
                                                gte: new Date(startDate).getTime()
                                            }
                                        }, {
                                            alarmAt: {
                                                lte: new Date(endDate).getTime()
                                            }    
                                        }
                                    ]
                                },
                                {
                                    and: [
                                        {
                                            resetAt: {
                                                gte: new Date(startDate).getTime()
                                            }
                                        }, {
                                            resetAt: {
                                                lte: new Date(endDate).getTime()
                                            }    
                                        }
                                    ]
                                },
                                {
                                    and: [
                                        {
                                            acknowledgeAt: {
                                                gte: new Date(startDate).getTime()
                                            }
                                        }, {
                                            acknowledgeAt: {
                                                lte: new Date(endDate).getTime()
                                            }    
                                        }
                                    ]
                                },
                            ]
                        }
                    ]
                }
            }, function(err, alarmLogs) {
                if (err) {
                    cb(null, err);
                } else {
                    cb(null, alarmLogs);
                }
            });
        }).fail(function(error) {
            cb(null, error);
        });
    };

    Location.prototype.countAlarmLogs = function(id, startDate, endDate, cb) {

        getUnitsOfLocation(id, []).then(function(units) {
            var deferred = Q.defer();

            var promises = [];
            var channels = [];
            units.forEach(function(unit) {
                promises.push(getChannelsOfUnit(unit.id, channels));
            });

            Q.allSettled(promises).then(function(results) {
                deferred.resolve(results);
            }, function(error) {
                deferred.reject(error);
            });

            return deferred.promise;
        }).then(function(channels) {
            //console.log(channels);
            var results = []
            _.forEach(channels, function(channel) {
                results.push(channel.value);
            })

            results = _.flatten(results);

            var channelIDs = [];
            var alarmWatcherIDs = [];
            _.forEach(results, function(channel) {
                if (channelIDs.indexOf(channel.id) < 0) {
                    channelIDs.push(channel.id);
                }

                _.forEach(channel.alarmWatcher(), function(alarmWatcher) {
                    if (alarmWatcherIDs.indexOf(alarmWatcher.id) < 0) {
                        alarmWatcherIDs.push(alarmWatcher.id);
                    }
                });
            });

            console.log(startDate);

            AlarmLog.find({
                where: {
                    and: [
                        {
                            alarmWatcherId: {
                                inq: alarmWatcherIDs
                            }
                        }, {
                            or: [
                                {
                                    and: [
                                        {
                                            alarmAt: {
                                                gte: new Date(startDate).getTime()
                                            }
                                        }, {
                                            alarmAt: {
                                                lte: new Date(endDate).getTime()
                                            }    
                                        }
                                    ]
                                },
                                {
                                    and: [
                                        {
                                            resetAt: {
                                                gte: new Date(startDate).getTime()
                                            }
                                        }, {
                                            resetAt: {
                                                lte: new Date(endDate).getTime()
                                            }    
                                        }
                                    ]
                                },
                                {
                                    and: [
                                        {
                                            acknowledgeAt: {
                                                gte: new Date(startDate).getTime()
                                            }
                                        }, {
                                            acknowledgeAt: {
                                                lte: new Date(endDate).getTime()
                                            }    
                                        }
                                    ]
                                },
                            ]
                        }
                    ]
                }
            }, function(err, alarmLogs) {
                if (err) {
                    cb(null, err);
                } else {
                    cb(null, alarmLogs.length);
                }
            });
        }).fail(function(error) {
            cb(null, error);
        });
    };

    Location.beforeRemote('_getAlarmLogs', function(ctx, unused, next) {
        //console.log(ctx.args);
        if (typeof(ctx.args.id) !== "number") {
            ctx.res.status(400).send("Invalid Channel ID");
            return;
        }

        if (typeof(ctx.args.startDate) !== "string") {
            ctx.res.status(400).send("startDate should be string");
            return;
        } else if (!moment(Date.parse(ctx.args.startDate)).isValid()) {
            ctx.res.status(400).send("startDate invalid");
            return;
        }

        if (typeof(ctx.args.endDate) !== "string") {
            ctx.res.status(400).send("endDate should be string");
            return;
        } else if (!moment(Date.parse(ctx.args.endDate)).isValid()) {
            ctx.res.status(400).send("endDate invalid");
            return;
        }

        next();
    });

    Location.beforeRemote('_countAlarmLogs', function(ctx, unused, next) {
        //console.log(ctx.args);
        if (typeof(ctx.args.id) !== "number") {
            ctx.res.status(400).send("Invalid Channel ID");
            return;
        }

        if (typeof(ctx.args.startDate) !== "string") {
            ctx.res.status(400).send("startDate should be string");
            return;
        } else if (!moment(Date.parse(ctx.args.startDate)).isValid()) {
            ctx.res.status(400).send("startDate invalid");
            return;
        }

        if (typeof(ctx.args.endDate) !== "string") {
            ctx.res.status(400).send("endDate should be string");
            return;
        } else if (!moment(Date.parse(ctx.args.endDate)).isValid()) {
            ctx.res.status(400).send("endDate invalid");
            return;
        }

        next();
    });

    function getUnitsOfLocation(locationID, units) {
        var deferred = Q.defer();
        Location.findById(locationID, {
            include: ["units", "children"]
        }, function(err, location) {
            if (location) {
                var currentUnits = location.units();
                currentUnits.forEach(function(unit) {
                    units.push(unit);
                });
                //console.log(units);
                var subLocations = location.children();
                var promises = [];

                subLocations.forEach(function(subLocation) {
                    if (subLocation.type !== "unit" && subLocation.type !== "component") {
                        promises.push(getUnitsOfLocation(subLocation.id, units));
                    }
                });

                Q.allSettled(promises).then(function(results) {
                    deferred.resolve(units);
                }, function(error) {
                    deferred.reject(error);
                });
            }
        });

        return deferred.promise;
    };

    function getChannelsOfUnit(unitID, resultChannels) {
        var deferred = Q.defer();
        Unit.findById(unitID, {
            include: [{
                channels: ["alarmWatcher"]
            }, "componentChildren"]
        }, function(err, unit) {
            if (unit) {
                var currentChannels = unit.channels();
                currentChannels.forEach(function(channel) {
                    resultChannels.push(channel);
                });
                var subComponents = unit.componentChildren();
                var promises = [];

                subComponents.forEach(function(subComponent) {
                    promises.push(getChannelsOfUnit(subComponent.id, resultChannels));
                });
                console.log(currentChannels.length);
                Q.allSettled(promises).then(function(results) {
                    deferred.resolve(resultChannels);
                }, function(error) {
                    deferred.reject(error);
                });
            }
        });

        return deferred.promise;
    }
};
