var EventEmitter = require("events").EventEmitter;
var Cluster = require('cluster');

// var influx = require('influx')

// var client = influx({

//     //cluster configuration
//     // hosts: [{
//     //     host: 'http://misterfusion-hilldale-1.c.influxdb.com',
//     //     port: 8060, //optional. default 8086
//     //     protocol: 'http' //optional. default 'http'
//     // }],
//     // or single-host configuration
//     host: 'misterfusion-hilldale-1.c.influxdb.com',
//     port: 8086, // optional, default 8086
//     protocol: 'http', // optional, default 'http'
//     username: 'root',
//     password: 'cbc0ff7161cc7035',
//     database: 'CMAS'
// })

if (Cluster.isMaster) {
    console.log("It is master");
    if (!GLOBAL.eventEmitter) {
        GLOBAL.eventEmitter = new EventEmitter();
    }
    var fs = require("node-fs");
    var mysql = require('mysql');
    var Q = require("q");

    var TEMP_FOLDER = {
        CHANNEL_DATA: "temps/channel-data"
    };

    fs.exists(TEMP_FOLDER.CHANNEL_DATA, function(exists) {
        if (!exists) {
            fs.mkdirSync(TEMP_FOLDER.CHANNEL_DATA, "0777", true);
        }
    });

    var moment = require("moment");

    module.exports = function enableDBWatcher(app) {
        var dataSource = app.dataSources.cmasDatabase;
        var Channel = app.models.Channel;
        var channelMapper = {};
        var pool = mysql.createPool(dataSource.settings);

        Channel.find({
            include: "channelData"
        }, function(err, channels) {
            for (var i in channels) {
                channelMapper[channels[i].name] = channels[i];
                channels[i].latestUpdateAt = new moment();
            }

            function update(rows) {
                if (rows && rows.length > 0) {
                    var currentUpdateTime = new moment();
                    var queryString = "";
                    var itemNumbers = 0;
                    for (var key in rows[0]) {
                        //if (key !== "id" && channelMapper[key] && (currentUpdateTime - channelMapper[key].latestUpdateAt)/1000 > channelMapper[key]["historyInterval"]) {
                        if (key !== "id" && channelMapper[key]) {
                            queryString += 'UPDATE `channel_data` set `value` = ' + rows[0][key] + " where channel_data.channelName = '" + key + "' and channel_data.controllable = 0; ";
                            GLOBAL.eventEmitter.emit("update-channel-" + key, rows[0][key]);
                            channelMapper[key].latestUpdateAt = currentUpdateTime;
                            itemNumbers++;
                        }
                    }
                    /*
                    fs.writeFile(TEMP_FOLDER.CHANNEL_DATA + "/" + new moment(), queryString, function(err) {
                        if (err) {
                            console.log(err);
                        }
                    });
                    */
                }
            }

            setInterval(function() {
                pool.query("SELECT * from realtime limit 0, 1", function(err, rows) {
                    update(rows);
                });
            }, 1000);
        });
    };
} else {
    console.log("It is cluster");
}
