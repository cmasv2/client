module.exports = function enableSocketServer(app) {
    //var server = require('http').Server(app);
    //var io = require('socket.io')(server);
    ////server.listen(app.get('port'), app.get('host'));

    //app.prototype.listen = function (callback) {
    //    console.log("Start");
    //    server.listen(app.get('port'), app.get('host'));

    //    io.on('connection', function (socket) {
    //        socket.emit('hand-shake', { status: 'working' });
    //        socket.on('feed-back', function (data) {
    //            console.log(data);
    //        });
    //    });

    //    callback();
    //};
};
