var fs = require("node-fs");
var path = require('path');
fs.exists(path.resolve(__dirname, '../public'), function(exists) {
    if (!exists) {
        fs.mkdirSync(path.resolve(__dirname, '../public'), "0777", true);
    }

    var EventEmitter = require("events").EventEmitter;
    var colors = require('colors');
    var cluster = require("cluster");
    var http = require("http");
    var loopback = require('loopback');
    var boot = require('loopback-boot');
    var bodyParser = require('body-parser');
    var util = require('./lib/util');


    if (!GLOBAL.eventEmitter) {
        GLOBAL.eventEmitter = new EventEmitter();
        GLOBAL.eventEmitter.setMaxListeners(10000);
    }

    var app = module.exports = loopback();

    // configure view handler
    app.set('view engine', 'ejs');
    app.set('views', path.join(__dirname, 'views'));

    // configure body parser
    app.use(bodyParser.urlencoded({
        extended: true
    }));

    var processArgsSetter = {
        "--init-db": function() {
            app.resetDataBase = true;
        },
        "--socket": function() {
            app.enableSocket = true;
        }
    };

    process.argv.forEach(function(val, index, array) {
        console.log(index + ': ' + val);
        processArgsSetter[val] ? processArgsSetter[val]() : {};
    });

    // Bootstrap the application, configure models, datasources and middleware.
    // Sub-apps like REST API are mounted via boot scripts.
    boot(app, __dirname);

    app.start = function() {
        // This code will be executed only in slave workers
        var server = null;
        server = http.createServer(app);
        var io = require('socket.io').listen(server);
        var Mailer = require('./services/mailer');
        server.listen(app.get("port"), app.get("host"));
        app.set("mailer", new Mailer(app.get("cmas").email));
        io.on('connection', function(socket) {
            socket.eventList = [];

            socket.emit('hand-shake', {
                status: 'working'
            });
            socket.ping = function() {
                var t = Date.now();
                socket.emit('ping');
                socket.once('ping-reply', function(data) {
                    console.log((Date.now() - t) / 2 + "ms");
                });
            }

            socket.ping();

            socket.on('ping', function(data) {
                socket.emit('ping-reply', data);
            });

            socket.on('feed-back', function(data) {
                console.log(data);
            });

            socket.on('listen', function(data) {
                //data: {object:, key:}
                // ex: {object: "channel", key: "CMAS-MSB-DC"}          
                if (socket.eventList['update-' + data.object + "-" + data.key]) {
                    return;
                } else {
                    var handler = function(channelData) {
                        socket.emit('update-' + data.object + "-" + data.key, channelData);
                    };
                    socket.eventList['update-' + data.object + "-" + data.key] = handler;

                    GLOBAL.eventEmitter.on('update-' + data.object + "-" + data.key, handler);
                }
            });

            if (!socket.eventList['update-alarm']) {
                var sendAlarmNotification = function(alarm) {
                    socket.emit('update-alarm', alarm);
                };
                socket.eventList['update-alarm'] = sendAlarmNotification;
                GLOBAL.eventEmitter.on('update-alarm', sendAlarmNotification);
            }
        });
    };

        // -- Mount static files here--
    // All static middleware should be registered at the end, as all requests
    // passing the static middleware are hitting the file system
    // Example:
    app.use(loopback.static(path.resolve(__dirname, '../client')));
    app.use("/file-manager", loopback.static(path.resolve(__dirname, '../file-manager-client')));


    // start the server if `$ node server.js`
    if (require.main === module) {
        app.start();
    }

});
