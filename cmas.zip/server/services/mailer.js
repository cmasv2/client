/**
 * Created by tanvo on 4/26/15.
 */

if (!GLOBAL.eventEmitter) {
    GLOBAL.eventEmitter = new EventEmitter();
}

function Mailer(config) {
    var me = this;
    var mailer = nodemailer = require('nodemailer');

    // Prepare nodemailer transport object
    var transporter = nodemailer.createTransport("SMTP", {
        host: config.host,
        port: config.port,
        /*auth: {
         user: config.user,
         pass: config.password
         }*/
    });

    if (process.env.NODE_ENV === "development") {
        transporter = nodemailer.createTransport("SMTP", {
            service: "Gmail",
            auth: {
                user: process.env.USER_NAME + "@gmail.com",
                pass: process.env.USER_PASS
            }
        });
    }

    function sendMail(destination, subject, content) {
        // setup e-mail data with unicode symbols 
        var mailOptions = {
            from: 'cmas@duytan.com', // sender address
            to: destination, // list of receivers
            subject: subject, // Subject line
            text: content , // plaintext body
            html: content // html body
        };
        console.log(mailOptions);
        // send mail with defined transport object
        transporter.sendMail(mailOptions, function(error, info){
            if(error){
                return console.error(error);
            }

            console.log('Message sent: ' + info.response);
        });
    };

    sendMail(config.user, "[CMAS] Has just stared.EOM", "");

    GLOBAL.eventEmitter.on("mailTo", function(data) {
        if (data && data.destination && data.subject) {
            sendMail(data.destination, data.subject, data.content);
        }
    });

    me.sendMail = sendMail;

    return me;
}

module.exports = Mailer;
