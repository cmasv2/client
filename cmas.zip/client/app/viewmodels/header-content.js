/**
 Create by Huy: codocmm@gmail.com ~ nqhuy2k6@gmail.com
 07/31/2015
 */
define(["durandal/app", "durandal/viewlocator", "knockout", "views/header", "q", "helper/loading"], function (app, viewLocator, ko, Header, Q, loading) {
    return function () {
        var me = this;
        var pageViewModel = this;
        pageViewModel.header = ko.observable();
        pageViewModel.content = ko.observable()
    }
});