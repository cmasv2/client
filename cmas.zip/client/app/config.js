define([], function () {
    return {DateTimeFormat: {GLOBAL: "DD/MM/YYYY HH:mm:ss"}}
});