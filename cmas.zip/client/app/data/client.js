﻿/**
 Create by Huy: codocmm@gmail.com ~ nqhuy2k6@gmail.com
 07/31/2015
 */
define([], function () {
    return {
        "pages": [{"name": "login", "displayName": "", "icon": "glyphicon-home", "active": true}],
        "pageDefinitions": {"dashboard": {}}
    }
});