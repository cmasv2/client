module.exports = function(Channel) {
    Channel.findByName = function (name, cb) {
        Channel.find({ where: { name: { like: name }} }, function (error, channels) {
            cb(channels);
        });
    }

    Channel.remoteMethod(
        'findByName',
        {
            accepts: { arg: 'name', type: 'string' },
            returns: { arg: 'status', type: 'string' }
        }
    );
};
