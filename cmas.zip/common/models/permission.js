module.exports = function(Permission) {

};
