module.exports = function (ChannelHistory) {

    ChannelHistory._findByTimeRange = function (filter, cb) {
        if (ChannelHistory.prototype.findByTimeRange) {
            ChannelHistory.prototype.findByTimeRange.apply(this, arguments);
        }
    };

    ChannelHistory.remoteMethod(
        '_findByTimeRange',
        {
            accepts: [
                {arg: 'id', type: 'number'},
                {arg: 'limit', type: 'number'},
                {arg: 'startDate', type: 'string'},
                {arg: 'endDate', type: 'string'}],
            returns: {arg: 'result', type: 'array'},
            http: {path: '/:id/findByTimeRange', verb: 'get'}
        }
    );

    ChannelHistory._averageByTimeRange = function (filter, cb) {
        if (ChannelHistory.prototype.averageByTimeRange) {
            ChannelHistory.prototype.averageByTimeRange.apply(this, arguments);
        }
    };

    ChannelHistory.remoteMethod(
        '_averageByTimeRange',
        {
            accepts: [
                {arg: 'id', type: 'number'},
                {arg: 'startDate', type: 'string'},
                {arg: 'endDate', type: 'string'}],
            returns: {arg: 'result', type: 'array'},
            http: {path: '/:id/averageByTimeRange', verb: 'get'}
        }
    );

};
