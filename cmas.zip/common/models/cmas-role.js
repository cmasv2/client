module.exports = function(Role) {

};
