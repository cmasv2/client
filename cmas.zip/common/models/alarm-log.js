module.exports = function(AlarmLog) {

};
