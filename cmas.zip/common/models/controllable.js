module.exports = function(Controllable) {
};
