module.exports = function(EscalationProfile) {

	var afterSave = function (ctx, next) {
        var _ctx = ctx.instance;
        var _next = next;
        if (!next) {
            _ctx = this;
            _next = ctx;
        }

        _ctx.alarmWatchers({}, function (err, alarmWatchers){
        	alarmWatchers.forEach(function(alarmWatcher){
        		GLOBAL.eventEmitter.emit("alarm-watcher-updated", alarmWatcher);
        	})
        });
        
        if (_ctx) {
            console.log('Saved %s#%s', "EscalationProfile", _ctx.id);
        }
        //_next();
    };

    if (EscalationProfile.observe) {
        EscalationProfile.observe('after save', afterSave);
    } else {
        EscalationProfile.afterSave = afterSave;
    }
};
