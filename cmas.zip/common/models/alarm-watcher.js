var EventEmitter = require("events").EventEmitter;

if (!GLOBAL.eventEmitter) {
    GLOBAL.eventEmitter = new EventEmitter();
}
module.exports = function (AlarmWatcher) {

    AlarmWatcher.AlarmStatus = {
        INACTIVE: "inactive",
        ACTIVE: "active",
        ACKNOWLEDGE: "acknowledge",
        RESET: "reset"
    };


    AlarmWatcher.validatesInclusionOf('status', {in: [AlarmWatcher.AlarmStatus.INACTIVE, AlarmWatcher.AlarmStatus.ACTIVE, AlarmWatcher.AlarmStatus.ACKNOWLEDGE, AlarmWatcher.AlarmStatus.RESET]});

    AlarmWatcher._acknowledge = function (id, cb) {
        if (AlarmWatcher.prototype.acknowledge) {
            AlarmWatcher.prototype.acknowledge.apply(this, arguments);
        }
    };
    AlarmWatcher._setEnable = function (id, cb) {
        if (AlarmWatcher.prototype.setEnable) {
            AlarmWatcher.prototype.setEnable.apply(this, arguments);
        }
    };
    AlarmWatcher._disable = function (id, cb) {
        if (AlarmWatcher.prototype.disable) {
            AlarmWatcher.prototype.disable.apply(this, arguments);
        }
    };

    AlarmWatcher.remoteMethod(
        '_acknowledge',
        {
            accepts: { arg: 'id', type: 'string' },
            returns: { arg: 'status', type: 'string' },
            http: {path: '/:id/acknowledge', verb: 'post'}
        }
    );

    AlarmWatcher.remoteMethod(
        '_setEnable',
        {
            accepts: { arg: 'id', type: 'string' },
            returns: { arg: 'status', type: 'string' },
            http: {path: '/:id/enable', verb: 'post'}
        }
    );

    AlarmWatcher.remoteMethod(
        '_disable',
        {
            accepts: { arg: 'id', type: 'string' },
            returns: { arg: 'status', type: 'string' },
            http: {path: '/:id/disable', verb: 'post'}
        }
    );

    var afterSave = function (ctx, next) {
        var _ctx = ctx.instance;
        var _next = next;
        if (!next) {
            _ctx = this;
            _next = ctx;
        }

        GLOBAL.eventEmitter.emit("alarm-watcher-updated", _ctx);
        //console.log(ctx);
        if (_ctx) {
            console.log('Saved %s#%s', _ctx, _ctx.id);
        }
        _next();
    };

    if (AlarmWatcher.observe) {
        AlarmWatcher.observe('after save', afterSave);
    } else {
        AlarmWatcher.afterSave = afterSave;
    }

};


