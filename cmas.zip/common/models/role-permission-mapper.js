module.exports = function(RolePermissionMapper) {

};
