module.exports = function(Action) {
    Action.Status = {
        Active: "active",
        Done: "done",
        Pending: "pending"
    }
};
