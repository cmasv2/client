module.exports = function(Job) {
    var afterSave = function (ctx, next) {
        var _ctx = ctx.instance;
        var _next = next;
        if (!next) {
            _ctx = this;
            _next = ctx;
        }

        GLOBAL.eventEmitter.emit("job-updated", _ctx);
        //console.log(ctx);
        if (_ctx) {
            console.log('Saved %s#%s', _ctx, _ctx.id);
        }
        _next();
    };

    if (Job.observe) {
        Job.observe('after save', afterSave);
    } else {
        Job.afterSave = afterSave;
    }
};
