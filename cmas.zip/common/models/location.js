module.exports = function(Location) {

    Location._getAlarmLogs = function (filter, cb) {
        if (Location.prototype.getAlarmLogs) {
            Location.prototype.getAlarmLogs.apply(this, arguments);
        }
    };

    Location.remoteMethod(
        '_getAlarmLogs',
        {
            accepts: [
                {arg: 'id', type: 'number'},
                {arg: 'startDate', type: 'string'},
                {arg: 'endDate', type: 'string'}],
            returns: {arg: 'result', type: 'array'},
            http: {path: '/:id/getAlarmLogs', verb: 'get'}
        }
    );

    Location._countAlarmLogs= function (filter, cb) {
        if (Location.prototype.countAlarmLogs) {
            Location.prototype.countAlarmLogs.apply(this, arguments);
        }
    };

    Location.remoteMethod(
        '_countAlarmLogs',
        {
            accepts: [
                {arg: 'id', type: 'number'},
                {arg: 'startDate', type: 'string'},
                {arg: 'endDate', type: 'string'}],
            returns: {arg: 'result', type: 'array'},
            http: {path: '/:id/countAlarmLogs', verb: 'get'}
        }
    );
};
