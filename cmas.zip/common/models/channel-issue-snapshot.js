module.exports = function(ChannelIssueSnapshot) {

};
