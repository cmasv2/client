module.exports = function(AccessControlLog) {

};
