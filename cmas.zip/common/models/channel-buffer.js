module.exports = function(ChannelBuffer) {

};
